package olympus.sparta.requests;

import com.google.common.base.Preconditions;
import olympus.common.executors.KeyedExecutor;
import olympus.common.executors.TrackingExecutor;
import olympus.sparta.agent.controller.requests.ClientHBUpdateRequest;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RequestHandler {
    private static final Logger log = LoggerFactory.getLogger(RequestHandler.class);
    private static final int REQUEST_HANDLER_THREAD_COUNT = PropertyHandler.getInstance().getIntValue("request.handler.thread.count");
    private final KeyedExecutor executor;
    private final RequestFactory requestFactory;

    public RequestHandler(RequestFactory factory) {
        this(new KeyedExecutor(REQUEST_HANDLER_THREAD_COUNT, "request-handler-tp"), factory);
    }

    public RequestHandler(KeyedExecutor executor, RequestFactory factory) {
        Preconditions.checkNotNull(executor);
        Preconditions.checkNotNull(factory);
        this.executor = executor; this.requestFactory = factory;
    }

    public void handleRequest(final ClientSession clientSession, final String msg) {
        handleRequest(clientSession, requestFactory.produce(msg));
    }

    public void handleRequest(final ClientSession clientSession, final Request request) {
        TrackingExecutor trackingExecutor = executor.getExecutor(clientSession.executorKey());

        if (request instanceof ClientHBUpdateRequest) {
            ((ClientHBUpdateRequest) request).updateClientHbInMemory(clientSession);
        }

        trackingExecutor.submit(() -> {
            try {
                request.handleRequest(clientSession);
            } catch (Exception e) {
                log.error(String.format("Error while processing the request: %s  ", request), e);
            }
        });
    }

    public RequestFactory getRequestFactory() {
        return requestFactory;
    }

    public void onConnected(ClientSession clientSession) {
        // figure out: if this is a reconnection or a fresh connection
    }
}
