package in.zeta.oms.alice;

public class Constants {

}
