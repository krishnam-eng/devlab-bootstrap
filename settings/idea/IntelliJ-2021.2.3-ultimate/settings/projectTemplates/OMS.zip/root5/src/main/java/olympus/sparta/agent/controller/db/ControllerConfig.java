package olympus.sparta.agent.controller.db;

import olympus.sparta.base.PropertyHandler;

public class ControllerConfig {
  public static final String CONFIG_UNREGISTER_DISABLED = "sparta.agent.controller.register.disabled";
  public static final String CONFIG_REGISTER_DISABLED = "sparta.agent.controller.unRegister.disabled";
  public static final String CONFIG_DB_SANITY_DISABLED = "sparta.agent.controller.dbSanityChecker.disabled";
  private final PropertyHandler propertyHandler = PropertyHandler.getInstance();

  public boolean isDBSanityCheckDisabled() {
    return propertyHandler.getBooleanValue(CONFIG_DB_SANITY_DISABLED);
  }

  public boolean isRegistrationDisabled() {
    return propertyHandler.getBooleanValue(CONFIG_REGISTER_DISABLED);
  }

  public boolean isUnRegistrationDisabled() {
    return propertyHandler.getBooleanValue(CONFIG_UNREGISTER_DISABLED);
  }
}
