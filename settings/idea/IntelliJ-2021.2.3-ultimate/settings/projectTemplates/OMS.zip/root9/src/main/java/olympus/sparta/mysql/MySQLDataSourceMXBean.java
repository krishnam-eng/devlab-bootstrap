package olympus.sparta.mysql;

import javax.management.MXBean;

@MXBean
public interface MySQLDataSourceMXBean {
    String getConnectionString();

    /**
     * Primarily for remote admin use-case via JMX
     * All subsequent connection requests will be from the new data source
     * @param newConnectionString
     */
    void setConnectionString(String newConnectionString);
}
