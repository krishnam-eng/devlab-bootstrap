package olympus.sparta.allocator.requests;

import com.google.common.base.Preconditions;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.PingQuery;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import olympus.trace.OlympusSpectra;

import static olympus.sparta.base.session.Request.RequestType.PING;

public class PingRequest extends Request<AllocatorModule> {
  private static SpectraLogger log = OlympusSpectra.getLogger(PingRequest.class);

  public class Response extends olympus.sparta.base.session.Response {
    private final String response;

    Response(PingQuery.Result result) {
      super(PingRequest.this.getRequestId());
      response = result.response;
    }

    @Override
    public String toString() {
      return String.format("%s/%s: %s", PING, requestId, toJson());
    }

    @Override
    public String toJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      JsonObject body = new JsonObject();
      body.addProperty("response", response);
      obj.add("body", body);
      return obj.toString();
    }
  }

  private transient DBAdapter<AllocationDBConnection> db;

  public PingRequest(String requestId) {
    super(PING);
    this.requestId = requestId;
  }

  @Override
  public PingRequest afterDeserialization(AllocatorModule module) {
    this.db = module.getDb();
    return this;
  }

  @Override
  public void handleRequest(ClientSession clientSession) {
    Preconditions.checkNotNull(db);
    try {
      clientSession.decorateMarker(log.trace(PING.toString())).log();
      PingQuery query = new PingQuery(db);
      PingQuery.Result result = query.ping();
      clientSession.send(new Response(result));
    } catch (Throwable t) {
      clientSession.send(errorResponse(ErrorResponse.ErrorCode.UNKNOWN_ERROR));
      clientSession.close();
    }
  }

  @Override
  public String toString() {
    return String.format("%s/%s", PING, requestId);
  }
}


