package functional.olympus.sparta.utils;

import olympus.sparta.DBProvider;
import olympus.sparta.mysql.MySQLDBProvider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DatabaseUtils {
  public static final String DEFAULT_CONNECTION_STRING = "jdbc:mysql://localhost:3306/sparta_db?user=root&connectionTimeout=2000&socketTimeout=15000";
  private static DBProvider provider;
  private String connectionString;


  public DatabaseUtils(String connectionString) {
    this.connectionString = connectionString;
  }

  public DatabaseUtils() {
    this(DEFAULT_CONNECTION_STRING);
  }

  public void truncateDB() {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      Connection conn = DriverManager.getConnection(connectionString);
      PreparedStatement statement = conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 0");
      statement.execute();
      statement = conn.prepareStatement("truncate table serviceInstances");
      statement.execute();
      statement = conn.prepareStatement("truncate table events");
      statement.execute();
      statement = conn.prepareStatement("truncate table registered_instances");
      statement.execute();
      statement = conn.prepareStatement("truncate table allocation_history");
      statement.execute();
      statement = conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 1");
      statement.execute();
    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }

  public synchronized DBProvider getProvider() {
    try {
      if (null == provider) {
        provider = new MySQLDBProvider(connectionString);
      }
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    return provider;
  }

}
