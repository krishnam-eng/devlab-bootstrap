package olympus.sparta.allocator.requests;

import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import in.zeta.commons.concurrency.CompletableFutures;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.allocator.util.InstanceCache;
import olympus.sparta.base.db.model.ServiceData;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import olympus.sparta.base.session.SessionAgnosticRequest;
import olympus.trace.OlympusSpectra;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletionStage;

import static olympus.sparta.base.session.Request.RequestType.FETCH_SERVICES;

public class FetchServicesRequest extends Request<AllocatorModule> implements SessionAgnosticRequest {
  private static SpectraLogger log = OlympusSpectra.getLogger(FetchServicesRequest.class);
  private static Gson gson = new Gson();

  public class Response extends olympus.sparta.base.session.Response {
    public final List<ServiceData> services;
    public final long snapshotTime;

    Response(List<ServiceData> input, long snapshotTime) {
      super(FetchServicesRequest.this.getRequestId());
      this.services = input;
      this.snapshotTime = snapshotTime;
    }

    @Override
    public String toString() {
      return String.format("%s/%s: %s", FETCH_SERVICES, requestId, toJson());
    }

    @Override
    public String toJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      JsonObject body = new JsonObject();
      JsonArray array = new JsonArray();
      for (ServiceData data : services) {
        array.add(gson.toJsonTree(data));
      }
      body.add("services", array);
      body.addProperty("snapshotTime", snapshotTime);
      obj.add("body", body);
      return obj.toString();
    }
  }

  private transient InstanceCache cache;

  private final Set<String> subscribedToTopics;

  public FetchServicesRequest(String requestId, Set<String> subscribedToTopics) {
    super(FETCH_SERVICES);
    this.subscribedToTopics = subscribedToTopics;
    this.requestId = requestId;
  }

  @Override
  public FetchServicesRequest afterDeserialization(AllocatorModule module) {
    this.cache = module.getInstanceCache();
    return this;
  }

  @Override
  public void handleRequest(ClientSession clientSession) {
    Preconditions.checkNotNull(cache);
    try {
      clientSession.decorateMarker(log.info(FETCH_SERVICES.toString()))
          .attr("requestId", requestId)
          .attr("subscribedTopics", subscribedToTopics.toString())
          .log();
      clientSession.send(new Response(cache.fetchServices(subscribedToTopics).get(), cache.getLastUpdateTime()));
    } catch (Throwable t) {
      clientSession.send(errorResponse(ErrorResponse.ErrorCode.UNKNOWN_ERROR));
    }
  }

  @Override
  public CompletionStage<? extends olympus.sparta.base.session.Response> complete() {
    return CompletableFutures.toCompletionStage(cache.fetchServices(subscribedToTopics))
        .thenApply(list -> new Response(list, cache.getLastUpdateTime()));
  }


  @Override
  public String toString() {
    return String.format("%s/%s", FETCH_SERVICES, requestId);
  }
}

