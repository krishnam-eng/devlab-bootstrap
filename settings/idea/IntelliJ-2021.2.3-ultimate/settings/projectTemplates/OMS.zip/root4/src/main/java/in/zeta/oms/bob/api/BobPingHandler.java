package in.zeta.oms.bob.api;

import static java.util.concurrent.CompletableFuture.completedFuture;

import in.zeta.commons.eagersingleton.EagerSingleton;
import in.zeta.commons.zms.service.ZetaHostMessagingService;
import in.zeta.oms.bob.request.PingPayload;
import in.zeta.oms.bob.response.PongPayload;
import in.zeta.spectra.capture.SpectraLogger;
import javax.inject.Inject;
import olympus.message.types.Request;
import olympus.trace.OlympusSpectra;

@EagerSingleton
public class BobPingHandler extends BobRequestHandler {
  public static final SpectraLogger log = OlympusSpectra.getLogger(
      BobPingHandler.class);

  @Inject
  public BobPingHandler(
      ZetaHostMessagingService zetaHostMessagingService) {
    super(zetaHostMessagingService);
    zetaHostMessagingService.addRequestHandler(this);
  }

  public void on(
      PingPayload payload,
      Request<PingPayload> request) {
    super.on(payload, request);
    completedFuture(null)
        .thenAccept(__ -> sendResponse(request, PongPayload.builder().build()))
        .exceptionally(t -> sendError(request, t));
  }
}
