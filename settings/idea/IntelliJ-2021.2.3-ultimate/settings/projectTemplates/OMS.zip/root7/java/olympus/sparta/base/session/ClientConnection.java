package olympus.sparta.base.session;

import olympus.sparta.base.session.ClientSession;

import java.net.InetSocketAddress;

/***
 * Represents a connection as exposed by one of the supported transport libraries.
 * A {@link ClientSession} is associated with a connection. All interactions within the Sparta service use ClientSession.
 * This ClientConnection object serves as a bridge between transport library and the Sparta ClientSession.
 */
public interface ClientConnection {
  void send(String msg);

  /***
   * To close underlying transport connection with the client.
   * It is safe to call this on an already closed connection.
   */
  void close();

  InetSocketAddress getRemoteSocketAddress();

  ClientSession getClientSession();

  Object getBaseConnection();

}
