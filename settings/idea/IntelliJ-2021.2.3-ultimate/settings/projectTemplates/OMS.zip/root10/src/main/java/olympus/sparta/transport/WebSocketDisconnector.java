package olympus.sparta.transport;

import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.RemoteServiceInstance;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.management.*;
import java.lang.management.ManagementFactory;
import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

public class WebSocketDisconnector implements WebSocketDisconnectorMXBean {

    private static final Logger log = LoggerFactory.getLogger(WebSocketDisconnector.class);

    private final ClientSession clientSession;
    private final AllocatorModule allocatorModule;

    private int instanceId;
    private String serviceType;
    private int registrationEvent;
    private int unRegistrationEvent;
    private ObjectName mxBeanName = null;

    public WebSocketDisconnector(ClientSessionImpl clientSession, AllocatorModule allocatorModule) {
        this.clientSession = clientSession;
        this.allocatorModule = allocatorModule;
    }

    public void registerInJMX() {
        if (this.mxBeanName != null) {
            log.info("Redundant registration of JMX bean. Existing bean can be used to disconnect the web socket of all the remote service instances affiliated to this session.");
            return;
        }
        //We register one bean per client session
        RemoteServiceInstance primaryServiceInstance = this.clientSession.getPrimaryServiceInstance();
        if (primaryServiceInstance == null) {
            log.info("Registration of JMX bean failed for client session. No primary service instance found.");
            return;
        }
        this.serviceType = primaryServiceInstance.getServiceType();
        this.instanceId = primaryServiceInstance.getInstanceId();
        this.registrationEvent = primaryServiceInstance.getRegistrationEvent();
        this.unRegistrationEvent = primaryServiceInstance.getUnRegistrationEvent();
        String name = getBeanName();
        try {
            MBeanServer server = ManagementFactory.getPlatformMBeanServer();
            this.mxBeanName = new ObjectName(name);
            server.registerMBean(this, this.mxBeanName);
        } catch (MalformedObjectNameException | MBeanRegistrationException | NotCompliantMBeanException ex) {
            throw new RuntimeException(ex);
        } catch (InstanceAlreadyExistsException ex) {
            //Ignore
        }
    }

    //NOTE: As soon as an instance is registered, we do not have access to complete instance data, as cache updates are scheduled to a later time.
    // Using the future to get the information is not time consuming due to 2 reasons:
    // 1. Result of the future comes from the cache most of the time
    // 2. We only fetch incremental changes from the db
    // 3. We re-use information from primary service instance as much as possible
    @NotNull
    private Optional<CompleteInstanceData> getInstanceData() {
        try {
            return allocatorModule.getInstanceCache()
                    .fetchInstances()
                    .get()
                    .stream()
                    .filter(instance -> instance.instanceId == this.instanceId)
                    .findFirst();
        } catch (InterruptedException | ExecutionException e) {
            return Optional.empty();
        }
    }

    @NotNull
    private String getBeanName() {
        return "olympus.sparta.transport:WebsocketDisconnector=WebsocketConnection-" + this.serviceType + "-" + this.instanceId;
    }

    public void unregisterInJMX() {
        if (this.mxBeanName == null) {
            return;
        }
        MBeanServer server = ManagementFactory.getPlatformMBeanServer();
        try {
            server.unregisterMBean(this.mxBeanName);
        } catch (InstanceNotFoundException ex) {
            //Ignore
        } catch (MBeanRegistrationException ex) {
            throw new RuntimeException(ex);
        } finally {
            this.mxBeanName = null;
        }
    }

    @Override
    public void disconnect() {
        this.clientSession.disconnect();
    }

    @Override
    public String getAddress() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.address).orElse(null);
    }

    @Override
    public int getInstanceId() {
        return this.instanceId;
    }

    @Override
    public String getServiceType() {
        return this.serviceType;
    }

    @Override
    public String getInfoJson() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.infoJson).orElse(null);
    }

    @Override
    public int getRegistrationEvent() {
        return this.registrationEvent;
    }

    @Override
    public int getUnRegistrationEvent() {
        return this.unRegistrationEvent;
    }

    @Override
    public long getLastHbInTime() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.lastHbInTime).orElse(-1L);
    }

    @Override
    public int getClientAckedVersion() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.clientAckedVersion).orElse(-1);
    }

    @Override
    public int getAllocationEvent() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.allocationEvent).orElse(-1);
    }

    @Override
    public String getSessionId() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.sessionId).orElse(null);
    }

    @Override
    public String getSpartaId() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.spartaId).orElse(null);
    }

    @Override
    public String getAllocatedBuckets() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> Arrays.toString(completeInstanceData.allocatedBuckets)).orElse(null);
    }

    @Override
    public long getRegistrationTime() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.registrationTime).orElse(-1L);
    }

    @Override
    public long getAllocationTime() {
        Optional<CompleteInstanceData> instanceData = getInstanceData();
        return instanceData.map(completeInstanceData -> completeInstanceData.allocationTime).orElse(-1L);
    }

}
