package olympus.sparta.base.session;

import com.google.gson.Gson;

public class Response {
    private static final String UNSOLICITED = "undefined";
    private static final Gson gson = new Gson();

    protected String requestId;

    protected String type;

    public Response(String requestId) {
        this(requestId, "response");
    }

    public Response(String requestId, String type) {
        this.requestId = requestId == null ? UNSOLICITED : requestId;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String toJson() {
        return gson.toJson(this);
    }

    @Override
    public String toString() {
        if (UNSOLICITED.equals(requestId)) {
            return String.format("%s: %s", type, toJson());
        } else {
            return String.format("%s/%s: %s", type, requestId, toJson());
        }
    }

    public static boolean isUnsolicited(String requestId) {
        return requestId == null || requestId.equals(UNSOLICITED);
    }

    public String getRequestId() {
        return requestId;
    }
}
