package olympus.sparta.mysql.mixins;

import olympus.sparta.agent.controller.db.model.SessionHBData;
import olympus.sparta.base.db.mysql.MySQLConstants;
import olympus.sparta.mysql.MySQLAgentDBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class HeartBeatMixin {
  private final MySQLAgentDBConnection mySQLConnection;

  public HeartBeatMixin(MySQLAgentDBConnection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }

  public int[] batchUpdateHB(String spartaId, List<SessionHBData> sessions) throws SQLException {
    String SQL_UPDATE_HEARTBEAT = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES +
        " SET lastHbInTime = FROM_UNIXTIME(TRUNCATE(?, -3) / 1000), clientAckedVersion = ? " +
        "WHERE sessionId = ? AND spartaId = ? AND unRegistrationEvent IS NULL";
    PreparedStatement heartbeatStatement = mySQLConnection.prepareStatement(SQL_UPDATE_HEARTBEAT);
    for (SessionHBData session : sessions) {
      heartbeatStatement.setLong(1, session.getLastHbInTime());
      heartbeatStatement.setInt(2, session.getAckedHBVersion());
      heartbeatStatement.setString(3, session.getSessionId());
      heartbeatStatement.setString(4, spartaId);
      heartbeatStatement.addBatch();
    }
    return heartbeatStatement.executeBatch();
  }

  public ResultSet selectStaleHBInstances(long staleHbInterval) throws SQLException {
    String sql = "" +
        "SELECT ri.instanceId instanceId " +
        "FROM registered_instances ri " +
        "JOIN serviceInstances si ON ri.instanceId = si.instanceId " +
        "WHERE si.lastHbInTime < TIMESTAMPADD(MICROSECOND, - (?)*1000 , CURRENT_TIMESTAMP)";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setLong(1, staleHbInterval);
    return stmt.executeQuery();
  }

  public int updateSpartaIdAndClientHb(String spartaId, long hbInTime, int clientAckedVersion, String sessionId) throws SQLException {
    String SQL_UPDATE_SPARTA_ID_AND_HB = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES + " SET " +
        " spartaId = ?, lastHbInTime = FROM_UNIXTIME(TRUNCATE(?, -3) / 1000), clientAckedVersion = ? " +
        " WHERE unRegistrationEvent IS NULL AND sessionId = ?";
    PreparedStatement statement = mySQLConnection.prepareStatement(SQL_UPDATE_SPARTA_ID_AND_HB);
    statement.setString(1, spartaId);
    statement.setLong(2, hbInTime);
    statement.setInt(3, clientAckedVersion);
    statement.setString(4, sessionId);
    statement.execute();
    return statement.getUpdateCount();
  }
}