package olympus.sparta.base.db.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ServiceData {
  private String serviceType;
  private HashSet<String> subscribedTopics = new HashSet<>();

  public ServiceData(String serviceType) {
    this.serviceType = serviceType;
  }

  public void addSubscribedTopic(String topic) {
    subscribedTopics.add(topic);
  }

  /***
   *
   * @param topic a specific topic or a wildcard character "*" to match any topic
   * @return true if subscribed to specified topic. If topic is "*", returns true always.
   */
  public boolean isSubscribedTo(String topic) {
    if (topic.equals("*")) {
      return true;
    }
    return subscribedTopics.contains(topic);
  }

  public String getServiceType() {
    return serviceType;
  }

  public Set<String> getSubscribedTopics() {
    return Collections.unmodifiableSet(subscribedTopics);
  }
}
