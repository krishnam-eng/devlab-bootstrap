package in.zeta.oms.alice.request;

import static com.google.common.base.Preconditions.checkArgument;

import com.google.common.base.Strings;
import in.zeta.commons.zms.api.ZetaPayload;
import in.zeta.commons.zms.api.ZetaRequestBuilder;
import in.zeta.oms.alice.AliceConstants;
import lombok.Builder;
import lombok.Getter;
import olympus.message.types.Request;

@Getter
@Builder(builderClassName = "Builder")
public class PingPayload extends ZetaPayload {
  private String nodeID;

  public PingPayload(PingPayload.Builder builder) {
    this.nodeID = builder.nodeID;
  }

  public static class Builder extends ZetaRequestBuilder<PingPayload, Builder> {
    public Builder() {

    }

    @Override
    public Request<PingPayload> build() {
      PingPayload request = new PingPayload(this);
      payload(request);
      validate(request);
      to(AliceConstants.getRoutingJID(nodeID));
      return super.build();
    }

    private void validate(PingPayload request) {
      checkArgument(!Strings.isNullOrEmpty(request.getNodeID()),
          "nodeID should be present & valid");
    }
  }
}
