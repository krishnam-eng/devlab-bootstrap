package olympus.sparta.transport.jetty.servlets;

import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.base.session.ClientSessionStore;
import org.eclipse.jetty.websocket.api.WebSocketPolicy;
import org.eclipse.jetty.websocket.servlet.*;

public class WebSocketServlet extends org.eclipse.jetty.websocket.servlet.WebSocketServlet {
  public static long TIMEOUT = 60 * 1000;
  public static int MAX_SIZE = 2 * 1024 * 1024;

  private final RequestHandler spartaRequestHandler;
  private final ClientSessionStore clientSessionStore;
  private final Controller agentController;
  private final AllocatorModule allocatorModule;

  public WebSocketServlet(RequestHandler spartaRequestHandler,
                          ClientSessionStore clientSessionStore,
                          Controller agentController,
                          AllocatorModule allocatorModule) {
    this.spartaRequestHandler = spartaRequestHandler;
    this.clientSessionStore = clientSessionStore;
    this.agentController = agentController;
    this.allocatorModule = allocatorModule;
  }

  @Override
  public void configure(WebSocketServletFactory factory) {
    WebSocketPolicy policy = factory.getPolicy();
    policy.setAsyncWriteTimeout(TIMEOUT);
    policy.setIdleTimeout(TIMEOUT);
    policy.setMaxTextMessageSize(MAX_SIZE);
    factory.setCreator((req, resp) -> new JettyWSClientConnection(spartaRequestHandler, clientSessionStore, agentController, allocatorModule));
    //factory.register(JettyWSClientConnection.class);
  }
}
