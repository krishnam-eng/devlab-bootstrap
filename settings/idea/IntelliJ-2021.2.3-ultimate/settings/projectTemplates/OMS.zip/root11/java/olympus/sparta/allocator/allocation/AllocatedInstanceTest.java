package olympus.sparta.allocator.allocation;


import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static olympus.sparta.allocator.allocation.AllocatedInstance.toBucketRanges;

public class AllocatedInstanceTest {
  ArrayList<Integer> buckets_1 = new ArrayList<>(Arrays.asList(1));
  ArrayList<Integer> buckets_2 = new ArrayList<>(Arrays.asList(1,2));
  ArrayList<Integer> buckets_3 = new ArrayList<>(Arrays.asList(1,3));
  ArrayList<Integer> buckets_4 = new ArrayList<>(Arrays.asList(1,2,3));
  ArrayList<Integer> buckets_5 = new ArrayList<>(Arrays.asList(1,2,3,4,7,8));
  ArrayList<Integer> buckets_6 = new ArrayList<>(Arrays.asList(1,2,3,4,7,8,9,10));
  ArrayList<Integer> buckets_7 = new ArrayList<>(Arrays.asList(1,2,3,4,7,8,9,11));
  ArrayList<Integer> buckets_8 = new ArrayList<>(Arrays.asList(1,2,3,4,7,9,11,12,13));
  ArrayList<Integer> buckets_9 = new ArrayList<>(Arrays.asList(1,3,7,9,11,13));
  ArrayList<Integer> buckets_10 = new ArrayList<>();

  int[][] expected_1 = new int[][]{{1,1}};
  int[][] expected_2 = new int[][]{{1,2}};
  int[][] expected_3 = new int[][]{{1,1},{3,3}};
  int[][] expected_4 = new int[][]{{1,3}};
  int[][] expected_5 = new int[][]{{1,4},{7,8}};
  int[][] expected_6 = new int[][]{{1,4},{7,10}};
  int[][] expected_7 = new int[][]{{1,4},{7,9}, {11,11}};
  int[][] expected_8 = new int[][]{{1,4},{7,7},{9,9},{11,13}};
  int[][] expected_9 = new int[][]{{1,1},{3,3}, {7,7},{9,9},{11,11},{13,13}};
  int[][] expected_10 = new int[][]{};


  @Test
  public void testBucketRanges() {
    Assert.assertArrayEquals(expected_1, toBucketRanges(buckets_1));
    Assert.assertArrayEquals(expected_2, toBucketRanges(buckets_2));
    Assert.assertArrayEquals(expected_3, toBucketRanges(buckets_3));
    Assert.assertArrayEquals(expected_4, toBucketRanges(buckets_4));
    Assert.assertArrayEquals(expected_5, toBucketRanges(buckets_5));
    Assert.assertArrayEquals(expected_6, toBucketRanges(buckets_6));
    Assert.assertArrayEquals(expected_7, toBucketRanges(buckets_7));
    Assert.assertArrayEquals(expected_8, toBucketRanges(buckets_8));
    Assert.assertArrayEquals(expected_9, toBucketRanges(buckets_9));
    Assert.assertArrayEquals(expected_10, toBucketRanges(buckets_10));
  }
}