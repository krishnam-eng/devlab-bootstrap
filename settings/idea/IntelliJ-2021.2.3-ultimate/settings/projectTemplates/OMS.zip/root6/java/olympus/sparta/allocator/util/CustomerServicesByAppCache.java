package olympus.sparta.allocator.util;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.CustomerServicesQuery;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static java.util.concurrent.TimeUnit.HOURS;

/***
 * Caches customer services by app to avoid load on MySQL by fetching on every request.
 * <p>
 * Cache is updated every {@link \#CACHE_ITEM_VALIDITY_IN_HOURS} hours (currently 24 hours).
 */
public class CustomerServicesByAppCache {
  private static final Logger log = LoggerFactory.getLogger(CustomerServicesByAppCache.class);
  private static final long CACHE_ITEM_VALIDITY_IN_HOURS = 24;
  private final CustomerServicesQuery customerServicesQuery;

  public CustomerServicesByAppCache(DBAdapter<AllocationDBConnection> db) {
    customerServicesQuery = new CustomerServicesQuery(db);
  }

  private LoadingCache<String, List<String>> customerServicesByAppCache = CacheBuilder
      .newBuilder()
      .expireAfterWrite(CACHE_ITEM_VALIDITY_IN_HOURS, HOURS)
      .build(new CacheLoader<String, List<String>>() {
        @Override
        public List<String> load(String app) {
          return customerServicesQuery.getCustomerServicesByApp(app);
        }
      });

  public List<String> getCustomerServices(String app) {
    return customerServicesByAppCache.getUnchecked(app);
  }
}
