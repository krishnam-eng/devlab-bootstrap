package olympus.sparta.allocator.allocation;

import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/*
* Objective:
* 1. All service instances should have nearly equal number of buckets (fairness)
* 2. On reallocation, minimum number of buckets should be shuffled (minimal change)
* */
public class EqualLoadAllocationStrategy implements AllocationStrategy {
    private static final Logger log = LoggerFactory.getLogger(EqualLoadAllocationStrategy.class);

    @Override
    public void reAllocate(Allocation currentAllocation) {
        List<AllocatedInstance> instances = currentAllocation.getInstances();
        if (instances.size() == 0) {
            log.warn("No active instances available for {}", currentAllocation.getServiceType());
            return;
        }
        int maxBuckets = maxAllocationsPerInstance(instances);
        shrinkOverloaded(instances, maxBuckets);
        distributeBuckets(instances, unAllocatedBuckets(instances), maxBuckets);
    }

    List<AllocatedInstance> shrinkOverloaded(List<AllocatedInstance> allocatedInstances, int maxBucketsPerInstance) {
        for (AllocatedInstance instance : allocatedInstances) {
            int count = instance.getBucketCount();
            if (count > maxBucketsPerInstance) {
                List<Integer> buckets = instance.getBuckets(); // getBuckets returns a copy of bucket list
                buckets.subList(maxBucketsPerInstance, count).clear();
                instance.setBuckets(buckets);
            }
        }
        return allocatedInstances;
    }

    List<Integer> unAllocatedBuckets(List<AllocatedInstance> instances) {
        HashSet<Integer> unAllocatedSet = new HashSet<Integer>(Allocator.BUCKET_COUNT);
        for (int bucket = 0; bucket < Allocator.BUCKET_COUNT; bucket++) {
            unAllocatedSet.add(bucket);
        }
        for (AllocatedInstance instance : instances) {
            for (int bucket : instance.getBuckets()) {
                unAllocatedSet.remove(bucket);
            }
        }
        return Lists.newArrayList(unAllocatedSet);
    }

    protected void distributeBuckets(List<AllocatedInstance> instances, List<Integer> buckets, int maxBuckets) {
        Collections.sort(instances);
        Collections.sort(buckets);
        Iterator<Integer> bucketItr = buckets.iterator();
        Iterator<AllocatedInstance> instanceItr = instances.iterator();
        AllocatedInstance instance = instanceItr.next();
        while (bucketItr.hasNext()) {
            if (instance.getBucketCount() < maxBuckets) {
                instance.addBucket(bucketItr.next());
            } else {
                instance = instanceItr.next();
            }
        }
    }

    private int maxAllocationsPerInstance(List<AllocatedInstance> list) {
        return (int) Math.ceil((double) Allocator.BUCKET_COUNT / list.size());
    }
}
