package olympus.sparta.agent.controller.hearbeat;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.model.SessionHBData;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.agent.controller.db.queries.ClientHBUpdateQuery;
import olympus.sparta.base.session.ErrorNotification;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.trace.OlympusSpectra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static olympus.sparta.base.session.ErrorResponse.ErrorCode.OUT_OF_SYNC_ERROR;

public class ClientHBDBUpdater {
    private static SpectraLogger log = OlympusSpectra.getLogger(ClientHBDBUpdater.class);

    private final DBAdapter<AgentDBConnection> db;
    private final ClientSessionStore clientSessionStore;
    private final ConcurrentHashMap<String, Long> lastUpdate = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> outOfSync = new ConcurrentHashMap<>();

    private final ExecutorService outOfSyncExecutorService = Executors.newSingleThreadExecutor(
        new ThreadFactoryBuilder().setDaemon(true).setNameFormat("client_hb_updater_out_of_sync_detection").build());

    private final ScheduledExecutorService hbUpdater = new ScheduledThreadPoolExecutor(1,
        new ThreadFactoryBuilder().setDaemon(true).setNameFormat("client_hb_db_updater").build());

    public ClientHBDBUpdater(DBAdapter<AgentDBConnection> db, ClientSessionStore clientSessionStore) {
        this.db = db;
        this.clientSessionStore = clientSessionStore;
        //Write updates to DB once per second.
        hbUpdater.scheduleAtFixedRate(() -> {
            try {
                update();
            } catch (Throwable e) {
                log.error("Unexpected error", e);
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    public void notifyUpdate() {
        //no-op
    }

    private void update() {
        List<SessionHBData> sessions = getSessionsToUpdate();
        if(0 == sessions.size()) {
            return;
        }

        try {
            ClientHBUpdateQuery query = new ClientHBUpdateQuery(db);
            final Map<String, Integer> updatedInstanceCount = query.updateClientHb(sessions);
            // No. of instance records updated could be different from the instances known to
            // be registered in the in memory structure for reasons like:
            // 1. Row is committed to DB, but corresponding entry is not yet made in memory
            // 2. Another Sparta instance could be handling the session
            // So out of sync state is not an error always.
            identifyOutOfSyncSessions(sessions, updatedInstanceCount);

            sessions.forEach(s -> lastUpdate.put(s.getSessionId(), s.getLastHbInTime()));
        } catch (Throwable t) {
            log.error("Failed to update client HB for sessions")
                .attr("sessions", sessions)
                .attr("throwable", t)
                .log();
        }
    }

    private List<SessionHBData> getSessionsToUpdate() {
        return clientSessionStore.getAllClientSessions().stream()
                .filter(s ->
                    !(s.getSessionId() == null ||
                        s.getRegisteredInstanceCount() == 0 ||
                        lastDBUpdate(s.getSessionId()) >= s.getLastHbInTime()))
                .map(SessionHBData::new)
                .collect(Collectors.toList());
    }

    private void identifyOutOfSyncSessions(List<SessionHBData> sessions, Map<String, Integer> updatedInstanceCount) {
        CompletableFuture.runAsync(() -> {
            for (SessionHBData s : sessions) {
                int updatedInstances = updatedInstanceCount.get(s.getSessionId());
                if (updatedInstances != s.getInstanceCount()) {
                    log.warn("Session out of sync")
                        .attr("sessionId", s.getSessionId())
                        .attr("registered instance count in-mem", s.getInstanceCount())
                        .attr("registered instance count in-db", updatedInstances)
                        .log();
                    markOutOfSync(s.getSessionId());
                } else {
                    markInSync(s.getSessionId());
                }
            }
        }, outOfSyncExecutorService);
    }

    private long lastDBUpdate(String id) {
        if (!lastUpdate.containsKey(id)) {
            lastUpdate.put(id, 0l);
        }
        return lastUpdate.get(id);
    }

    private void markOutOfSync(String sid) {
        int count = outOfSync.computeIfAbsent(sid, s -> 0);
        outOfSync.put(sid, ++count);
        if (count > 2) {
            final int current = count;
          clientSessionStore.getClientSession(sid)
              .ifPresent(session -> {
                log.error("consistently OUT-OF-SYNC with DB. Sending error to client")
                    .attr("sessionId", sid)
                    .attr("cuurentCount", current)
                    .log();
                session.send(new ErrorNotification(OUT_OF_SYNC_ERROR));
                session.close();
              });
        }
    }

    private void markInSync(String sid) {
        //Can be concurrently updated by client_hb_updater thread and out_of_sync_detection thread.
        if (outOfSync.containsKey(sid)) {
            log.trace("session is IN-SYNC with DB")
                .attr("sessionId", sid)
                .log();
            outOfSync.remove(sid);
        }
    }
}
