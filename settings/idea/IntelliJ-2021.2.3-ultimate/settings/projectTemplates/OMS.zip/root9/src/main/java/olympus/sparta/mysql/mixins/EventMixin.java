package olympus.sparta.mysql.mixins;

import com.google.common.base.Preconditions;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.base.db.Host;
import olympus.sparta.base.db.mysql.MySQLConstants;
import olympus.sparta.mysql.MySQLAgentDBConnection;

import java.sql.*;

public class EventMixin {
  private final Connection mySQLConnection;

  public EventMixin(Connection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }

  public Statement insertIntoEvents() throws SQLException {
    String SQL_INSERT_INTO_EVENTS = "INSERT INTO " + MySQLConstants.TABLE_EVENTS + "(createdAt) VALUES (CURRENT_TIMESTAMP)";
    PreparedStatement insertStmt = mySQLConnection.prepareStatement(SQL_INSERT_INTO_EVENTS);
    insertStmt.execute();
    return insertStmt;
  }


  public Statement updateEvent(AgentDBConnection.EventType eventType, int eventId, int instanceId) throws SQLException {
    String SQL_UPDATE_EVENT = "UPDATE " + MySQLConstants.TABLE_EVENTS + " SET " +
        " eventType = ?, instanceId = ?" +
        " WHERE eventId = ?";
    PreparedStatement statement = mySQLConnection.prepareStatement(SQL_UPDATE_EVENT);
    statement.setInt(1, eventType == AgentDBConnection.EventType.REGISTER ? 1 : 2);
    statement.setLong(2, instanceId);
    statement.setLong(3, eventId);
    statement.execute();
    Preconditions.checkState(statement.getUpdateCount() == 1, "Shouldn't have updated more than one row");
    return statement;
  }


  public int insertAndGetEventId() throws SQLException {
    insertIntoEvents();
    ResultSet resultSet = getLastInsertId();
    resultSet.next();
    return resultSet.getInt("eventId");
  }

  public ResultSet selectMaxEventId() throws SQLException {
    String SQL_MAX_EVENT_ID = "SELECT IFNULL(max(eventId),0) AS eventId FROM " + MySQLConstants.TABLE_EVENTS;
    PreparedStatement stmt = mySQLConnection.prepareStatement(SQL_MAX_EVENT_ID);
    return stmt.executeQuery();
  }

  private ResultSet getLastInsertId() throws SQLException {
    String sql = "SELECT LAST_INSERT_ID() eventId";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    return stmt.executeQuery();
  }

}
