package olympus.sparta.transport.jetty.servlets;

import com.google.gson.JsonObject;

import javax.inject.Singleton;
import java.util.HashMap;
import java.util.Map;

@Singleton
public class QueryStringParser {

  /**
   * This parsing strategy creates a hierarchy of object for every parameter which has a '.' in its name.
   * Any parameters without a '.' are considered to be top-level names.
   *
   *
   * Ex: ?foo=bar&amp;ham.arg1=alice&amp;ham.arg2=bob will result in the following map:
   *
   * {
   *     foo : bar,
   *     ham : {
   *         arg1 : alice,
   *         arg2 : bob
   *     }
   * }
   *
   * @param qp
   * @return
   */
  public Map<String, Object> parse(Map<String, String[]> qp) {

    Map<String, Object> args = new HashMap<>();

    for (Map.Entry<String, String[]> entry : qp.entrySet()) {
      String param = entry.getKey();
      String value = entry.getValue()[0];
      int idx = param.indexOf('.');
      if (idx > 0) {
        // complex parameter
        String parent = param.substring(0, idx);
        String child = param.substring(idx+1);
        if (!args.containsKey(parent)) {
          args.put(parent, new HashMap<String, Object>());
        }
        Map<String, String> inner = (Map<String, String>) args.get(parent);
        inner.put(child, value);
      } else {
        // simple parameter
        args.put(param, value);
      }
    }
    return args;
  }

  public JsonObject parseAsJson(Map<String, String[]> qp) {

//        Map<String, Object> args = new HashMap<>();
    JsonObject args = new JsonObject();

    for (Map.Entry<String, String[]> entry : qp.entrySet()) {
      String param = entry.getKey();
      String value = entry.getValue()[0];
      int idx = param.indexOf('.');
      if (idx > 0) {
        // complex parameter
        String parent = param.substring(0, idx);
        String child = param.substring(idx+1);
        if (!args.has(parent)) {
          args.add(parent, new JsonObject());
        }
        JsonObject inner = args.get(parent).getAsJsonObject();
        inner.addProperty(child, value);
      } else {
        // simple parameter
        args.addProperty(param, value);
      }
    }
    return args;
  }
}