package olympus.sparta.agent.controller.requests;

import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.common.JID;
import olympus.pubsub.model.OperationType;
import olympus.pubsub.model.PubSubEvent;
import olympus.pubsub.model.TopicScope;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.ControllerConfig;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import olympus.sparta.agent.controller.hearbeat.ClientHBDBUpdater;
import olympus.sparta.agent.controller.db.queries.RegisterQuery;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.trace.OlympusSpectra;
import org.apache.http.NameValuePair;

import java.util.ArrayList;

import static com.google.common.base.Preconditions.checkState;
import static olympus.sparta.base.session.Request.RequestType.REGISTER;

public class RegisterRequest extends Request<Controller> {
    private static final SpectraLogger log = OlympusSpectra.getLogger(RegisterRequest.class);
    private final String serviceType;
    private final String address;
    private final String infoJson;

    private transient DBAdapter<AgentDBConnection> db;
    private transient ClientHBDBUpdater clientHBDBUpdater;
    private transient ControllerConfig controllerConfig;
    private transient AtroposPublisher publisher;

    public class Response extends olympus.sparta.base.session.Response {
        private final String jid;
        private final int systemVersion;

        Response(RemoteServiceInstance ri) {
            super(RegisterRequest.this.getRequestId());
            checkState(ri.isRegistered());
            this.jid = ri.getJID();
            this.systemVersion = ri.getRegistrationEvent();
        }

        //region Getter Methods
        public String getJid() {
            return jid;
        }
        //endregion

        @Override
        public String toString() {
            return String.format("REGISTER/%s: %s", requestId, toJson());
        }

        @Override
        public String toJson() {
            JsonObject obj = new JsonObject();
            obj.addProperty("requestId", requestId);
            obj.addProperty("type", type);
            JsonObject body = new JsonObject();
            body.addProperty("jid", jid);
            body.addProperty("systemVersion", systemVersion);
            obj.add("body", body);
            return obj.toString();
        }
    }

    public RegisterRequest(String serviceType, String address, String infoJson, String requestId) {
        super(REGISTER);
        this.serviceType = serviceType;
        this.address = address;
        this.infoJson = infoJson;
        this.requestId = requestId;

    }

    @Override
    public RegisterRequest afterDeserialization(Controller controller) {
        this.db = controller.getDb();
        this.clientHBDBUpdater = controller.getClientHBDBUpdater();
        this.controllerConfig = controller.getConfig();
        this.publisher = controller.getAtroposPublisher();
        return this;
    }

    @Override
    public void handleRequest(ClientSession clientSession) {
        Preconditions.checkNotNull(clientHBDBUpdater);
        Preconditions.checkNotNull(db);
        Preconditions.checkNotNull(controllerConfig);
        Preconditions.checkState(!controllerConfig.isRegistrationDisabled(), "REGISTRATION is DISABLED");

        clientSession.decorateMarker(log.info(REGISTER.toString()))
            .attr("address", address)
            .attr("requestId", requestId)
            .attr("serviceName", serviceType)
            .log();

        if (isInvalid(clientSession)) {
            clientSession.send(errorResponse(ErrorResponse.ErrorCode.SESSION_NOT_ESTABLISHED));
            return;
        }

        // Check if the session already contains the instance
        RemoteServiceInstance existingInstance = clientSession.getRegisteredServiceInstance(serviceType, address);
        if (existingInstance != null) {
            clientSession.send(new Response(existingInstance));
            clientHBDBUpdater.notifyUpdate();
            return;
        }

        RemoteServiceInstance remoteServiceInstance = clientSession.create();

        try {
            RegisterQuery query = new RegisterQuery(db, controllerConfig,this, clientSession.getSessionId());
            RegisterQuery.Result result = query.register();
            remoteServiceInstance.setRegistered(result.getInstanceId(), getServiceType(), getAddress(), result.getRegistrationEvent(), result.getInfoJson());
            clientSession.decorateMarker(log.info(REGISTER.toString() + " SUCCESS"))
                .attr("address", address)
                .attr("requestId", requestId)
                .attr("serviceName", serviceType)
                .attr("instanceJID", JID.serviceInstanceJID(serviceType, Integer.toString(result.getInstanceId())))
                .log();

            clientSession.send(new Response(remoteServiceInstance));
            clientHBDBUpdater.notifyUpdate();
            clientSession.onRegistered();
            publisher.publish(new PubSubEvent.Builder()
                    .topicScope(TopicScope.SYSTEM)
                    .tenant("0")
                    .objectType("serviceInstance")
                    .objectID(remoteServiceInstance.getJID())
                    .sourceObjectType("cluster")
                    .data(gson.toJsonTree(remoteServiceInstance))
                    .operationType(OperationType.CREATED)
                    .stateMachineState(REGISTER.name())
                    .tags(new ArrayList<>()));
        } catch (Throwable t) {
            clientSession.decorateMarker(log.warn(REGISTER.toString() + " FAILED", t))
                .attr("address", address)
                .attr("requestId", requestId)
                .attr("serviceName", serviceType)
                .log();
            clientSession.send(errorResponse(ErrorResponse.ErrorCode.DB_REGISTRATION_ERROR));
        }
    }

    private boolean isInvalid(ClientSession clientSession) {
        return clientSession.getSessionId() == null || "".equals(clientSession.getSessionId());
    }

    //region Getter Methods
    public String getAddress() {
        return address;
    }

    public String getInfoJson() {
        return infoJson;
    }

    public String getServiceType() {
        return serviceType;
    }
    //endregion

    @Override
    public String toString() {
        return String.format("%s/%s/%s", REGISTER, serviceType, requestId);
    }
}
