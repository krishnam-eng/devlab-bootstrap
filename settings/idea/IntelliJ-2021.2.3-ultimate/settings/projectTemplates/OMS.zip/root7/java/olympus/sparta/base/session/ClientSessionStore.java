package olympus.sparta.base.session;

import olympus.metrics.Counter;
import olympus.metrics.Gauge;
import olympus.metrics.MetricLogger;

import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import olympus.metrics.base.SummaryType;

public class ClientSessionStore {
  private static final MetricLogger metricLogger = MetricLogger.getLogger(ClientSessionStore.class);
  private static final Gauge sessionCountGauge = metricLogger.gauge("sparta.clientSessionCount");

  //total session count does not indicate correct trend about disconnection and connection
  private static final Counter addClientSessionCounter = metricLogger.counter("sparta.clientSessionCount.add");
  private static final Counter removeClientSessionCounter = metricLogger.counter("sparta.clientSessionCount.remove");
  private final Set<ClientSession> sessions = ConcurrentHashMap.newKeySet();

  public ClientSessionStore() {

  }

  public void add(ClientSession clientSession) {
    synchronized (sessions) {
      sessions.add(clientSession);
      sessionCountGauge.set(sessions.size());
    }
    clientSession.setOnCloseListener(() -> remove(clientSession));
    clientSession.onConnected();
    addClientSessionCounter.increment();
  }

  public void remove(ClientSession clientSession) {
    synchronized (sessions) {
      boolean isRemoved = sessions.remove(clientSession);
      if (isRemoved) {
        sessionCountGauge.set(sessions.size());
        removeClientSessionCounter.increment();
      }
    }
  }

  public Collection<ClientSession> getAllClientSessions() {
    return sessions;
  }

  public Optional<ClientSession> getClientSession(String sessionId) {
    return sessions.stream()
        .filter(x -> sessionId.equals(x.getSessionId()))
        .findFirst();
  }
}
