package olympus.sparta.transport.jetty.servlets;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.io.CharStreams;
import com.google.common.reflect.TypeToken;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.GetProxyAllocationsQuery;
import olympus.sparta.allocator.db.queries.PutProxyAllocationQuery;
import olympus.sparta.allocator.proxy.ProxyRemoteInstance;
import olympus.sparta.allocator.requests.GetProxiesResponse;
import olympus.sparta.base.db.DBAdapter;
import olympus.trace.OlympusSpectra;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

public class ProxyAllocationServlet extends BaseServlet {

    private static final SpectraLogger logger = OlympusSpectra.getLogger(ProxyAllocationServlet.class);
    private final DBAdapter<AllocationDBConnection> db;

    public ProxyAllocationServlet(DBAdapter<AllocationDBConnection> db) {
        this.db = db;
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("RECEIVED_PUT_PROXIES_REQUEST").log();
        String body = CharStreams.toString(req.getReader());

        List<ProxyRemoteInstance> proxies = gson.fromJson(body, (new TypeToken<List<ProxyRemoteInstance>>() {
        }).getType());
        logger.info("PROXIES_INFO")
                .attr("size", proxies.size())
                .log();
        try {
            validate(proxies);
        } catch (Exception e) {
            logger.error("BAD_REQUEST", e).log();
            completeExceptionally(req, resp, e);
            return;
        }
        CompletionStage<Boolean> result = CompletableFuture.supplyAsync(() -> {
            PutProxyAllocationQuery query = new PutProxyAllocationQuery(db);
            return query.putProxyAllocations(proxies);
        });
        complete(req, resp, result);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("RECEIVED_GET_PROXIES_REQUEST").log();
        CompletionStage<GetProxiesResponse> result = CompletableFuture.supplyAsync(() -> {
            GetProxyAllocationsQuery query = new GetProxyAllocationsQuery(db);
            return query.getLatestProxyAllocations();
        });
        complete(req, resp, result);
    }

    private void validate(List<ProxyRemoteInstance> proxies) {
        Map<String, List<ProxyRemoteInstance>> map = new HashMap<>();
        for (ProxyRemoteInstance proxyRemoteInstance : proxies) {
            Preconditions.checkArgument(!Strings.isNullOrEmpty(proxyRemoteInstance.getSource()), "source cannot be null");
            Preconditions.checkArgument(!Strings.isNullOrEmpty(proxyRemoteInstance.getDestination()), "destination cannot be null");
            Preconditions.checkArgument(!Strings.isNullOrEmpty(proxyRemoteInstance.getProxy()), "proxy cannot be null");

            String key = proxyRemoteInstance.getSource() + "_" + proxyRemoteInstance.getDestination();

            if (!map.containsKey(key)) {
                map.put(key, new ArrayList<>());
            }
            map.get(key).add(proxyRemoteInstance);
        }

        List<String> badProxies = new ArrayList<>();

        for (String key : map.keySet()) {
            if (map.get(key).size() > 1)
                badProxies.add(key);
        }

        if (!badProxies.isEmpty())
            throw new IllegalArgumentException("Found duplicate proxies for the following(source_destination) :: " + gson.toJson(badProxies));
    }
}
