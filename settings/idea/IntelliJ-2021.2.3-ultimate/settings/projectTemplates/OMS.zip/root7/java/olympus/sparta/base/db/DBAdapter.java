package olympus.sparta.base.db;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Function;
import olympus.metrics.Counter;
import olympus.metrics.MetricLogger;
import olympus.metrics.TimeKeeper;
import olympus.sparta.base.PropertyHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Supplier;

/***
 * DBAdapter handles the typical connection management concerns - transaction isolation, commit, and close
 * for every interaction with db.
 * It expects a connection factory
 * @param <T>
 */
public class DBAdapter<T extends Connection> {
  private static final Logger log = LoggerFactory.getLogger(DBAdapter.class);
  private static final MetricLogger metricLogger = MetricLogger.getLogger(DBAdapter.class);
  private static final TimeKeeper transactionTimeKeeper = metricLogger.timeKeeper("sparta.db.transaction");
  private static final TimeKeeper queryTimeKeeper = metricLogger.timeKeeper("sparta.db.query");
  private static final Counter queryFailureCount = metricLogger.counter("sparta.db.queryFailure");
  private static final Counter transactionFailureCount = metricLogger.counter("sparta.db.transactionFailure");

  private final Supplier<T> supplier;

  public DBAdapter(Supplier<T> connectionFactory) {
    this.supplier = connectionFactory;
  }

  public <R> R executeTransaction(Function<T, R> f) {
    int remainingTries = PropertyHandler.getInstance().getIntValue("sparta.db.deadlock.retryCount", 5);
    R result = null;

    while (remainingTries-- > 0) {
      try {
        result = executeTransactionOnce(f);
        return result;
      } catch (DBException e) {
        if (!isDeadlock(e)) {
          throw new DBException("Non-retriable error", e);
        }

        if (remainingTries == 0) {
          throw new DBException("Exhausted retries on deadlock", e);
        } else {
          try {
            Thread.sleep(100);
          } catch (InterruptedException interruptedException) {
            throw new RuntimeException(interruptedException);
          }
        }
      }
    }
    return result;
  }

  @VisibleForTesting
  static boolean isDeadlock(Throwable e) {
    // This is quite fragile. Alternative would be checking for com.mysql.jdbc.exceptions.DeadlockTimeoutRollbackMarker
    // but sparta-base doesn't take mysql dependency
    while (e != null &&
            (e.getMessage() == null || e.getMessage() != null && !e.getMessage().toLowerCase().contains("deadlock"))) {
      e = e.getCause();
    }
    return e != null;
  }

    public <R> R executeTransactionOnce(Function<T, R> f) {
    T conn = null;
    R result = null;
    TimeKeeper.Event timerEvent = transactionTimeKeeper.start();
    try {
      conn = getConnection();
      conn.setAutoCommit(false);
      conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
      result = f.apply(conn);
      conn.commit();
    } catch (Exception e) {
      transactionFailureCount.increment();
      throw new DBException(e);
    } finally {
      rollback(conn);
      timerEvent.end();
    }
    return result;
  }

  public void rollback(T conn) {
    if (conn != null) {
      try {
        conn.rollback();
        conn.setAutoCommit(true);
        conn.close();
      } catch (Throwable e) {
        log.error("Exception in rollback: ", e);
        try {
          conn.close();
        } catch (SQLException ex) {
          log.error("CRITICAL: error while closing connection, it may not have returned to the pool", ex);
        }
      }
    }
  }

  public <R> R select(Function<T, R> f) {
    T conn = null;
    R result = null;
    TimeKeeper.Event timerEvent = queryTimeKeeper.start();
    try {
      conn = getConnection();
      conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
      result = f.apply(conn);
    } catch (Exception e) {
      queryFailureCount.increment();
      throw new DBException(e);
    } finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (Exception e) {
          log.error("Exception in select: ", e);
        }
      }
      timerEvent.end();
    }
    return result;
  }

  @Nonnull
  public T getConnection() {
    return supplier.get();
  }

  public static class DBException extends RuntimeException {
    public DBException(String message, Throwable cause) {
      super(message, cause);
    }

    public DBException(Throwable cause) {
      super(cause.getMessage(), cause);
    }
  }

}
