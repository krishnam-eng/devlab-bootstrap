package olympus.sparta;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;

public interface DBProvider {
  DBAdapter<AgentDBConnection> getAgentDB();

  DBAdapter<AllocationDBConnection> getAllocationDB();
}
