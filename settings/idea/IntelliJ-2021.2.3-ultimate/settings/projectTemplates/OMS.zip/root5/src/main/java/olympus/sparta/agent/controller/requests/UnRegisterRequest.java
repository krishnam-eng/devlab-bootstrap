package olympus.sparta.agent.controller.requests;

import com.google.common.base.Preconditions;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.pubsub.model.OperationType;
import olympus.pubsub.model.PubSubEvent;
import olympus.pubsub.model.TopicScope;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.ControllerConfig;
import olympus.sparta.agent.controller.db.queries.UnRegisterQuery;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.sparta.base.session.Request;
import olympus.trace.OlympusSpectra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

import static com.google.common.base.Preconditions.checkState;
import static olympus.sparta.base.session.ErrorResponse.ErrorCode.DB_UN_REGISTRATION_ERROR;
import static olympus.sparta.base.session.ErrorResponse.ErrorCode.UN_REGISTRATION_ERROR;
import static olympus.sparta.base.session.Request.RequestType.UN_REGISTER;

public class UnRegisterRequest extends Request<Controller> {
    private static final SpectraLogger log = OlympusSpectra.getLogger(UnRegisterRequest.class);

    private final String jid;
    private transient DBAdapter<AgentDBConnection> db;
    private transient ControllerConfig controllerConfig;
    private transient AtroposPublisher publisher;

    public class Response extends olympus.sparta.base.session.Response {
        private final int instanceId;
        private final int systemVersion;

        Response(RemoteServiceInstance ri) {
            super(UnRegisterRequest.this.getRequestId());
            checkState(!ri.isRegistered());
            this.instanceId = ri.getInstanceId();
            this.systemVersion = ri.getUnRegistrationEvent();
        }

        @Override
        public String toString() {
            return String.format("UN-REGISTER/%s: %s", requestId, toJson());
        }

        @Override
        public String toJson() {
            JsonObject obj = new JsonObject();
            obj.addProperty("requestId", requestId);
            obj.addProperty("type", type);
            JsonObject body = new JsonObject();
            body.addProperty("instanceId", instanceId);
            body.addProperty("systemVersion", systemVersion);
            obj.add("body", body);
            return obj.toString();
        }
    }

    public UnRegisterRequest(String jid) {
        super(UN_REGISTER);
        this.jid = jid;
    }

    public UnRegisterRequest(String jid, Controller agentController) {
        this(jid);
        afterDeserialization(agentController);
    }


    @Override
    public UnRegisterRequest afterDeserialization(Controller controller) {
        this.db = controller.getDb();
        this.controllerConfig = controller.getConfig();
        this.publisher = controller.getAtroposPublisher();
        return this;
    }

    @Override
    public void handleRequest(ClientSession clientSession) {
        handleRequest(clientSession, false);
    }

    public void handleRequest(ClientSession clientSession, boolean ignoreErrors) {
        Preconditions.checkNotNull(db);
        Preconditions.checkNotNull(controllerConfig);
        Preconditions.checkState(!controllerConfig.isUnRegistrationDisabled(), "UN-REGISTRATION is DISABLED");
        RemoteServiceInstance remoteServiceInstance = null;
        try {
            UnRegisterQuery query = new UnRegisterQuery(db, this);
            UnRegisterQuery.Result result = query.unRegister();
            remoteServiceInstance = clientSession.getServiceInstance(getInstanceId());
            if (result != null && remoteServiceInstance != null) {
                log.info("UN_REGISTER")
                    .attr("jid", this.jid)
                    .attr("clientSession", clientSession)
                    .attr("serviceName", remoteServiceInstance.getServiceType())
                    .log();
                remoteServiceInstance.setUnRegistered(result.getUnRegistrationEvent());
                clientSession.remove(remoteServiceInstance);
                clientSession.send(new Response(remoteServiceInstance));
                publisher.publish(new PubSubEvent.Builder()
                        .topicScope(TopicScope.SYSTEM)
                        .tenant("0")
                        .objectType("serviceInstance")
                        .objectID(remoteServiceInstance.getJID())
                        .sourceObjectType("cluster")
                        .data(gson.toJsonTree(remoteServiceInstance))
                        .operationType(OperationType.DELETED)
                        .stateMachineState(UN_REGISTER.name())
                        .tags(new ArrayList<>()));
            } else {
                clientSession.send(errorResponse(UN_REGISTRATION_ERROR));
            }
        } catch (Throwable t) {
            if(ignoreErrors) {
                log.info("Did not unRegister; The instance may belong to another session")
                    .attr("jid", this.jid)
                    .attr("clientSession", clientSession)
                    .attr("serviceName", remoteServiceInstance.getServiceType())
                    .log();
                return;
            }
            log.error("Error while trying to unRegister")
                .attr("jid", this.jid)
                .attr("clientSession", clientSession)
                .attr("serviceName", remoteServiceInstance.getServiceType())
                .log();
            clientSession.send(errorResponse(DB_UN_REGISTRATION_ERROR));
        }
    }

    public String getJid() {
        return jid;
    }

    public int getInstanceId() {
        return Integer.parseInt(jid.substring(0, jid.indexOf("@")));
    }

    @Override
    public String toString() {
        return String.format("%s/%s/%s", UN_REGISTER, jid, requestId);
    }
}
