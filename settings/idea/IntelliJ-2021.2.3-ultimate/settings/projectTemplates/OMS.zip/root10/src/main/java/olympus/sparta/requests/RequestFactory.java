package olympus.sparta.requests;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import olympus.metrics.MetricLogger;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.agent.controller.requests.ClientHBUpdateRequest;
import olympus.sparta.agent.controller.requests.ReConnectionRequest;
import olympus.sparta.agent.controller.requests.RegisterRequest;
import olympus.sparta.agent.controller.requests.UnRegisterRequest;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.allocator.requests.*;
import olympus.sparta.base.session.Request;

public class RequestFactory {

  private static final MetricLogger metricLogger = MetricLogger.getLogger(RequestFactory.class);
  private final Gson gson = new Gson();

  private final Controller agentController;
  private final AllocatorModule allocatorModule;

  public RequestFactory(Controller agentController, AllocatorModule allocatorModule) {
    this.agentController = agentController;
    this.allocatorModule = allocatorModule;
  }

  /**
   * JSON: {type: '', body: {}}
   *
   * @param incomingJson The JSON request provided by the client
   * @return the request corresponding to the incoming JSON
   */
  public Request produce(String incomingJson) {
    JsonParser parser = new JsonParser();
    JsonObject json = parser.parse(incomingJson).getAsJsonObject();
    return produce(json);
  }

  public Request produce(JsonObject json) {
    String type = json.get("type").getAsString();
    JsonElement bodyElement = json.get("body");
    JsonObject body = bodyElement != null ? json.get("body").getAsJsonObject() : emptyObject();
    metricLogger.counter("sparta.request." + type).increment();
    try {
      switch (Request.RequestType.valueOf(type)) {
        case RE_CONNECTION:
          return gson.fromJson(body, ReConnectionRequest.class).afterDeserialization(agentController);
        case REGISTER:
          return gson.fromJson(body, RegisterRequest.class).afterDeserialization(agentController);
        case UN_REGISTER:
          return gson.fromJson(body, UnRegisterRequest.class).afterDeserialization(agentController);
        case HEARTBEAT:
          return gson.fromJson(body, ClientHBUpdateRequest.class).afterDeserialization(agentController);
        case LOOKUP:
          return gson.fromJson(body, LookupRequest.class).afterDeserialization(allocatorModule);
        case FETCH_ALL_REGISTERED:
          return gson.fromJson(body, FetchAllRegisteredRequest.class).afterDeserialization(allocatorModule);
        case FETCH_SERVICES:
          return gson.fromJson(body, FetchServicesRequest.class).afterDeserialization(allocatorModule);
        case FETCH_CUSTOMER_SERVICES_BY_APP:
          return gson.fromJson(body, FetchCustomerServicesByAppRequest.class).afterDeserialization(allocatorModule);
        case PING:
          return gson.fromJson(body, PingRequest.class).afterDeserialization(allocatorModule);
        default:
          return new UnknownRequest(type).afterDeserialization(null);
      }
    } catch (IllegalArgumentException e) {
      return new UnknownRequest(type);
    }
  }

  private JsonObject emptyObject() {
    return new JsonObject();
  }
}
