package olympus.sparta.agent.controller.db.queries;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.requests.UnRegisterRequest;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.google.common.base.Preconditions.checkState;

public class UnRegisterQuery {
  private static final Logger log = LoggerFactory.getLogger(UnRegisterQuery.class);

  public static class Result {
    private final String jid;
    private final int unRegistrationEvent;

    private Result(String jid, int ts) {
      this.jid = jid;
      this.unRegistrationEvent = ts;
    }

    public int getUnRegistrationEvent() {
      return unRegistrationEvent;
    }
  }

  private final DBAdapter<AgentDBConnection> db;
  private final UnRegisterRequest unRegisterRequest;

  public UnRegisterQuery(DBAdapter<AgentDBConnection> db, UnRegisterRequest unRegisterRequest) {
    this.db = db;
    this.unRegisterRequest = unRegisterRequest;
  }

  public Result unRegister() {
    return db.executeTransaction(conn -> {
      Result r;
      try {
        int instanceId = unRegisterRequest.getInstanceId();
        log.info("Un-registering instance with instanceId: {}", instanceId);
        int updateCount = conn.unRegisterIfLocal(instanceId);
        if (updateCount != 1) {
          throw new RuntimeException("Could not un-register instance: " + instanceId + ", updateCount = " + updateCount + " != 1");
        }
        r = prepareResult(conn);
        conn.updateEvent(AgentDBConnection.EventType.UNREGISTER,
            r.unRegistrationEvent, instanceId);

      } catch (SQLException ex) {
        log.error("Failed to unRegister", ex);
        throw new RuntimeException(ex);
      }
      return r;
    });
  }

  //region Private Methods
  private Result prepareResult(AgentDBConnection conn) throws SQLException {
    ResultSet rs = conn.selectByInstanceId(unRegisterRequest.getInstanceId());
    int unRegistrationEvent = 0;
    if (rs.next()) {
      unRegistrationEvent = rs.getInt("unRegistrationEvent");
    }
    checkState(unRegistrationEvent != 0, "UnRegistration event is not updated.");

    log.info("UnRegistration complete for {}", unRegisterRequest);
    return new Result(unRegisterRequest.getJid(), unRegistrationEvent);
  }


  //endregion
}
