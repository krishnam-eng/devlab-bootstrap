\#! /bin/sh

echo "copying #[[\$]]#app.jar to tenants-dir volume"
cp /tmp/#[[\$]]#app.jar /tenants-clients
echo "sha1sum" #[[\$]]#(sha1sum /tenants-clients/#[[\$]]#app.jar)

