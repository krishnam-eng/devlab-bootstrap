package in.zeta.oms.alice;

import com.google.gson.Gson;
import com.google.inject.Provides;
import com.google.inject.Singleton;
import in.zeta.commons.annotations.TimeLogger;
import in.zeta.commons.gson.ZetaGsonBuilder;
import in.zeta.commons.interceptors.TimeLoggerInterceptor;
import in.zeta.commons.settings.SettingsModule;
import in.zeta.commons.zms.service.ZetaHostMessagingService;
import in.zeta.oms.bob.BobClient;
import in.zeta.oms.certstore.client.CertStoreClient;

import static com.google.inject.matcher.Matchers.annotatedWith;
import static com.google.inject.matcher.Matchers.any;

public class AliceModule extends SettingsModule {

  @Override
  protected void configure() {
    super.configure();
    bind(Gson.class).toInstance(new ZetaGsonBuilder().build());
    bindInterceptor(any(), annotatedWith(TimeLogger.class), new TimeLoggerInterceptor());
  }

  @Provides
  @Singleton
  BobClient createBobClient(ZetaHostMessagingService zhms) {
    return new BobClient(zhms);
  }
}
