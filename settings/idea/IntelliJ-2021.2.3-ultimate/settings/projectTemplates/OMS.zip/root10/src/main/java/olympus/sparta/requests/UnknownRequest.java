package olympus.sparta.requests;

import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UnknownRequest extends Request<Object> {
    private static final Logger log = LoggerFactory.getLogger(UnknownRequest.class);
    private String clientReqType;

    public UnknownRequest(String clientReqType) {
        super(Request.RequestType.UNKNOWN);
        this.clientReqType = clientReqType;
    }

    @Override
    public UnknownRequest afterDeserialization(Object o) {
        return this;
    }

    @Override
    public void handleRequest(ClientSession clientSession) {
        log.warn("Unknown Request: {} from {}", clientReqType, clientSession);
        clientSession.send(new ErrorResponse(ErrorResponse.ErrorCode.UNKNOWN_REQUEST_TYPE, this));
    }

    public String toString() {
        return "UnknownRequest{" +
                "requestId='" + requestId + '\'' +
                '}';
    }
}
