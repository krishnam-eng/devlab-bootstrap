package olympus.sparta.allocator.allocation;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Allocation {
    private final int systemVersion;
    private final String serviceType;
    private final List<AllocatedInstance> instances;

    Allocation(String serviceType, int systemVersion, List<AllocatedInstance> instances) {
        this.serviceType = serviceType;
        this.systemVersion = systemVersion;
        this.instances = instances;
    }

    public String getServiceType() {
        return serviceType;
    }

    public int getSystemVersion() {
        return systemVersion;
    }

    public List<AllocatedInstance> getInstances() {
        return instances;
    }

    /**
     * Every bucket should be allocated.
     * Every bucket should be allocated to exactly one instance.
     * Every instance should have at least one allocation.
     *
     * @return
     */
    boolean isValid() {
        boolean[] allocated = new boolean[Allocator.BUCKET_COUNT];
        int allocationCount = 0;
        for (AllocatedInstance instance : getInstances()) {
            if (instance.getBuckets().size() == 0) return false;
            for (int bucket : instance.getBuckets()) {
                if (allocated[bucket]) { // if bucket has already been allocated to different instance
                    return false;
                }
                allocated[bucket] = true;
                allocationCount++;
            }
        }
        for (int i = 0; i < allocated.length; i++) {
            if (!allocated[i]) return false;
        }
        return allocationCount == Allocator.BUCKET_COUNT;
    }

    @Override
    public int hashCode() {
        return (int) systemVersion;
    }

    /**
     * System version of allocation should be same.
     * Both allocations should be valid.
     * Every bucket in both allocations should map to the same instance.
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Allocation)) return false;
        Allocation that = (Allocation) o;
        if (systemVersion != that.systemVersion) return false;
        if (!isValid() || !that.isValid()) return false;
        Map<Integer, AllocatedInstance> thisMap = bucketToInstance();
        Map<Integer, AllocatedInstance> thatMap = that.bucketToInstance();
        for (int i = 0; i < Allocator.BUCKET_COUNT; i++) {
            AllocatedInstance thisInstance = thisMap.get(i);
            AllocatedInstance thatInstance = thatMap.get(i);
            if (thisInstance == null || thatInstance == null || !thisInstance.equals(thatInstance)) {
                return false;
            }
        }
        return true;
    }

    private Map<Integer, AllocatedInstance> bucketToInstance() {
        HashMap<Integer, AllocatedInstance> map = new HashMap<Integer, AllocatedInstance>();
        for (AllocatedInstance instance : instances) {
            for (int bucket : instance.getBuckets()) {
                map.put(bucket, instance);
            }
        }
        return map;
    }

    @Override
    public String toString() {
        return "Allocation{" +
                "systemVersion=" + systemVersion +
                ", serviceType='" + serviceType + '\'' +
                ", instances=" + instances +
                '}';
    }

    public JsonObject toJson() {
        return toJson(false);
    }

    public JsonObject toBucketRangesJson() {
        return toJson(true);
    }

    private JsonObject toJson(boolean withBucketRanges) {
        JsonObject json = new JsonObject();
        json.addProperty("serviceType", serviceType);
        json.addProperty("systemVersion", systemVersion);
        JsonArray arr = new JsonArray();
        for (AllocatedInstance instance : instances) {
            arr.add(withBucketRanges ? instance.toBucketRangesJson() : instance.toJson());
        }
        json.add("instances", arr);
        return json;
    }

}
