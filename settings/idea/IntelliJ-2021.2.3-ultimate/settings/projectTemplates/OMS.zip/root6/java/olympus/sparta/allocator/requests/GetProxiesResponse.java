package olympus.sparta.allocator.requests;

import olympus.sparta.allocator.proxy.ProxyRemoteInstance;

import java.util.List;

public class GetProxiesResponse {
    private final List<ProxyRemoteInstance> proxyRemoteInstances;
    private final int version;

    public GetProxiesResponse(List<ProxyRemoteInstance> proxyRemoteInstances, int version) {
        this.proxyRemoteInstances = proxyRemoteInstances;
        this.version = version;
    }

    public List<ProxyRemoteInstance> getProxyRemoteInstances() {
        return proxyRemoteInstances;
    }

    public int getVersion() {
        return version;
    }
}
