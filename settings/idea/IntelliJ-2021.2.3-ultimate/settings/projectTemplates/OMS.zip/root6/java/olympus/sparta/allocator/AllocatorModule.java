package olympus.sparta.allocator;

import olympus.sparta.allocator.allocation.Allocator;
import olympus.sparta.allocator.allocation.FairAllocator;
import olympus.sparta.allocator.allocation.ProxyAwareAllocatorDecorator;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.util.CustomerServicesByAppCache;
import olympus.sparta.allocator.util.InstanceCache;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.ClientSessionStore;

public class AllocatorModule {
  private final ServerHBSender serverHBSender;
  private final Allocator allocator;
  private final DBAdapter<AllocationDBConnection> db;
  private final InstanceCache instanceCache;
  private final CustomerServicesByAppCache customerServicesByAppCache;

  public AllocatorModule(DBAdapter<AllocationDBConnection> db,
                         ClientSessionStore clientSessionStore,
                         AtroposPublisher atroposPublisher) {
    this.db = db;
    ProxyAwareAllocatorDecorator proxyAwareAllocatorDecorator = new ProxyAwareAllocatorDecorator(new FairAllocator(db, atroposPublisher), db);
    this.allocator = proxyAwareAllocatorDecorator;
    this.serverHBSender = new ServerHBSender(clientSessionStore, db, proxyAwareAllocatorDecorator);
    instanceCache = new InstanceCache(db);
    customerServicesByAppCache = new CustomerServicesByAppCache(db);
  }

  public ServerHBSender getServerHBSender() {
    return serverHBSender;
  }

  public Allocator getAllocator() {
    return allocator;
  }

  public DBAdapter<AllocationDBConnection> getDb() {
    return db;
  }

  public InstanceCache getInstanceCache() {
    return instanceCache;
  }

  public CustomerServicesByAppCache getCustomerServicesByAppCache() {
    return customerServicesByAppCache;
  }
}
