package olympus.sparta.allocator.requests;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.allocator.allocation.Allocator;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.Request;
import olympus.sparta.base.session.SessionAgnosticRequest;
import olympus.trace.OlympusSpectra;

import javax.annotation.Nonnull;
import java.util.concurrent.CompletionStage;

import static in.zeta.commons.concurrency.CompletableFutures.toCompletionStage;
import static olympus.sparta.base.session.ErrorResponse.ErrorCode.UNKNOWN_ERROR;
import static olympus.sparta.base.session.Request.RequestType.LOOKUP;

public class LookupRequest extends Request<AllocatorModule> implements SessionAgnosticRequest {
    private static final SpectraLogger log = OlympusSpectra.getLogger(LookupRequest.class);
    private static final int DEFAULT_VERSION = 0;

    private transient Allocator allocator;
    private String serviceType;
    private int systemVersion;
    private boolean withBucketRanges = false;
    private int retryCount = 0;

    public class Response extends olympus.sparta.base.session.Response {
        private final Allocation allocation;

        public Response(Allocation allocation) {
            super(LookupRequest.this.getRequestId());
            this.allocation = allocation;
        }

        @Override
        public String toString() {
            return String.format("LOOKUP %s (reqId:%s, reqVersion: %d): (responseVersion: %d)",
              serviceType, requestId, systemVersion, allocation.getSystemVersion());
        }

        @Override
        public String toJson() {
            JsonObject obj = new JsonObject();
            obj.addProperty("requestId", requestId);
            obj.addProperty("type", type);
            obj.add("body", withBucketRanges ? allocation.toBucketRangesJson() : allocation.toJson());
            return obj.toString();
        }
    }


    public LookupRequest(String serviceType, int systemVersion, boolean withBucketRanges) {
        super(LOOKUP);
        this.serviceType = serviceType;
        this.systemVersion = systemVersion;
        this.withBucketRanges = withBucketRanges;
    }

    @Override
    public LookupRequest afterDeserialization(AllocatorModule module) {
        this.allocator = module.getAllocator();
        return this;
    }

    public void handleRequest(final ClientSession clientSession) {
        Preconditions.checkNotNull(allocator);
        Preconditions.checkArgument(!Strings.isNullOrEmpty(serviceType));
        clientSession.decorateMarker(log.debug(LOOKUP.toString()))
                .attr("serviceName", getServiceType())
                .attr("systemVersion", getSystemVersion())
                .attr("bucketRanges", withBucketRanges)
                .attr("retryCount", retryCount)
                .log();
        ListenableFuture<Allocation> future = allocator.getAllocation(
                getServiceType(),
                retryCount > 0 ? DEFAULT_VERSION : getSystemVersion(),
                clientSession.getPrimaryServiceInstance());
        Futures.addCallback(future, new FutureCallback<Allocation>() {
            @Override
            public void onSuccess(@Nonnull Allocation allocation) {
                if(!isAcceptableAllocation(clientSession, allocation)) {
                    retryCount++;
                    int retryLimit = 2;
                    if (retryCount > retryLimit) {
                        return;
                    }
                    handleRequest(clientSession);
                    return;
                }
                Response response = new Response(allocation);
                clientSession.decorateMarker(log.debug("LOOKUP Response"))
                        .attr("requestedVersion", systemVersion)
                        .attr("responseVersion", allocation.getSystemVersion())
                        .attr("serviceName", getServiceType())
                        .attr("size", allocation.getInstances().size())
                        .attr("address", allocation.getInstances().size() > 0 ? allocation.getInstances().get(0).getAddress() : null)
                        .log();
                clientSession.send(response);
            }

            @Override
            public void onFailure(Throwable t) {
                clientSession.decorateMarker(log.warn(LOOKUP.toString() + " failed", t))
                    .attr("request", this)
                    .log();
                clientSession.send(errorResponse(UNKNOWN_ERROR));
            }
        });
    }

    @Override
    public CompletionStage<Response> complete() {
        return toCompletionStage(allocator.getAllocation(getServiceType(), getSystemVersion()))
            .thenApply(Response::new);
    }


    //region Getter Methods
    public String getServiceType() {
        return serviceType;
    }

    public int getSystemVersion() {
        return systemVersion;
    }
    //endregion


    @Override
    public String toString() {
        return String.format("%s/%s (systemVersion: %d, requestId: %s)", LOOKUP, serviceType, systemVersion, requestId);
    }


    private boolean isAcceptableAllocation(ClientSession clientSession, Allocation allocation){
        if(getSystemVersion() > allocation.getSystemVersion()) {
            clientSession.decorateMarker(log.warn("CRITICAL: RETRIEVED stale allocation version from Allocator"))
                .attr("requestedVersion", systemVersion)
                .attr("responseVersion", allocation.getSystemVersion())
                .attr("serviceName", getServiceType())
                .attr("retryCount", retryCount)
                .log();
            return false;
        }
        return true;
    }
}
