package olympus.sparta.allocator.util;

import com.google.common.base.Function;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import olympus.metrics.Counter;
import olympus.metrics.MetricLogger;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.AllocationQuery;
import olympus.sparta.allocator.db.queries.EventsQuery;
import olympus.sparta.allocator.db.queries.HearBeatUpdatesQuery;
import olympus.sparta.allocator.db.queries.ServiceInstanceQuery;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.db.model.ServiceData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;

/***
 * Caches all registered instances to avoid load on MySQL by fetching all registered instances
 * on every request.
 * <p>
 * Cache is fully flushed and updated whenever there is an allocation change in the system. Instance's
 * heart-beat times are updated every {@link \#UPDATE_INTERVAL_MS} milliseconds (currently 3 sec). Every
 * request to {@link \#fetchInstances()} returns last updated snapshot of all instances.
 */
public class InstanceCache {
  private static final Logger log = LoggerFactory.getLogger(InstanceCache.class);
  private static final MetricLogger metricLogger = MetricLogger.getLogger(InstanceCache.class);
  private static final Counter cacheRefreshCounter = metricLogger.counter("sparta.instanceCache.refresh");
  private static final long UPDATE_INTERVAL_MS = 3000;

  private final Timer timer = new Timer("instance-cache-tracker", true);
  private final ConcurrentHashMap<Integer, CompleteInstanceData> allInstances = new ConcurrentHashMap<>();
  private long lastUpdateTime = System.currentTimeMillis();
  private final DBAdapter<AllocationDBConnection> db;

  private SettableFuture<List<CompleteInstanceData>> nextUpdateFuture = null;

  public InstanceCache(DBAdapter<AllocationDBConnection> db) {
    this.db = db;
    timer.schedule(new UpdateTracker(), 200, UPDATE_INTERVAL_MS);
  }

  private void onUpdateCycleEnd() {
    List<CompleteInstanceData> instances = allInstances.values().stream()
        .sorted(comparing(i -> i.serviceType))
        .collect(toList());
    nextUpdateFuture.set(instances);
    lastUpdateTime = System.currentTimeMillis();
  }

  private void onUpdateCycleStart() {
    nextUpdateFuture = SettableFuture.create();
  }

  public ListenableFuture<List<CompleteInstanceData>> fetchInstances() {
    if (null == nextUpdateFuture) {
      //This should happen if and only if fetchInstances() is called
      //before the updateTacker was not initiated
      return Futures.immediateFuture(Collections.emptyList());
    }
    return nextUpdateFuture;
  }

  public ListenableFuture<List<ServiceData>> fetchServices(Set<String> subscribedToTopics) {
    if (null == subscribedToTopics || subscribedToTopics.isEmpty()) {
      return Futures.immediateFuture(Collections.emptyList());
    }
    return Futures.transform(fetchInstances(), (Function<List<CompleteInstanceData>, List<ServiceData>>) serviceInstanceRowViews -> {
      if (null == serviceInstanceRowViews) {
        return Collections.emptyList();
      }
      ArrayList<ServiceData> result = new ArrayList<>();
      for (ServiceData s : buildServiceDataFromInstanceData(serviceInstanceRowViews)) {
        if (subscribedToTopics.stream().anyMatch(s::isSubscribedTo)) {
          result.add(s);
        }
      }
      return result;
    });
  }

  private Collection<ServiceData> buildServiceDataFromInstanceData(List<CompleteInstanceData> instances) {
    HashMap<String, ServiceData> services = new HashMap<>();
    for (CompleteInstanceData v : instances) {
      ServiceData d = services.computeIfAbsent(v.serviceType, k -> new ServiceData(v.serviceType));
      for (String topic : v.getSubscribedTopics()) {
        d.addSubscribedTopic(topic);
      }
    }
    return services.values();
  }

  public long getLastUpdateTime() {
    return lastUpdateTime;
  }

  private class UpdateTracker extends TimerTask {
    private int lastKnownEvent = -1;
    private int lastKnownMinSurvivingInstanceId = -1;
    private int lastKnownMaxSurvivingInstanceId = -1;
    private final EventsQuery eventsQuery = new EventsQuery(db);
    private final AllocationQuery allocationQuery = new AllocationQuery(db);
    private final HearBeatUpdatesQuery hbUpdatesQuery = new HearBeatUpdatesQuery(db);
    private final ServiceInstanceQuery allRegisteredQuery = new ServiceInstanceQuery(db);

    @Override
    public void run() {
      try {
        onUpdateCycleStart();
        if (allInstances.isEmpty()) {
          fetchAll();
        } else {
          trackConfigChanges();
          trackHBChanges();
        }
      } catch (Exception ex) {
        log.error("Unable to update the instance cache", ex);
      }
      onUpdateCycleEnd();
    }

    private void trackConfigChanges() {
      if (dbHasNewEvent() || dbHasNewAllocation()) {
        fetchAll();
      }
    }

    private void trackHBChanges() {
      hbUpdatesQuery.getHBUpdates(knownInstanceIds()).forEach(update -> {
        CompleteInstanceData r = allInstances.get(update.instanceId);
        r.lastHbInTime = update.lastHbInTime;
        r.clientAckedVersion = update.clientAckedVersion;
        r.spartaId = update.spartaId;
        r.sessionId = update.sessionId;
      });
    }

    private void fetchAll() {
      // We don't have an index on UnRegisteredEvent column in DB
      // Adding index on the column causes deadlocks at MySQL.
      // So a query to fetch all unRegistered instances causes a complete table scan.
      // By adding the min instanceId that we expect to be surviving as a condition on the
      // query, we eliminate the need for full scan.
      log.trace("Refreshing instance cache");
      cacheRefreshCounter.increment();
      createOrUpdateInstances(allRegisteredQuery
          .fetchRegisteredInstancesGreaterThan(lastKnownMinSurvivingInstanceId - 1));
      updateNextFetchMarker();
    }

    private void createOrUpdateInstances(List<CompleteInstanceData> instances) {
      allInstances.clear();
      instances.forEach(i -> allInstances.put(i.instanceId, i));
    }

    private void updateNextFetchMarker() {
      // Min and Max surviving instanceId represent the range of instanceIds that
      // are currently registered, although with some holes in between.
      // We track max so that, if there is a situation where all the instances
      // get unRegistered we can move the min to previously known max. The next
      // instanceId will always be greater than previously known max.
      //
      // However, we should ensure that we don't lose the min boundary erroneously
      // as this will cause loss in reporting of registered instances.
      if (allInstances.size() == 0) {
        lastKnownMinSurvivingInstanceId = lastKnownMaxSurvivingInstanceId;
        return;
      }
      List<Integer> sorted = knownInstanceIds();
      sorted.sort(Comparator.<Integer>naturalOrder());
      int min = sorted.get(0);
      int max = sorted.get(sorted.size() - 1);
      if (lastKnownMinSurvivingInstanceId < min) {
        lastKnownMinSurvivingInstanceId = min;
      }
      if (lastKnownMaxSurvivingInstanceId < max) {
        lastKnownMaxSurvivingInstanceId = max;
      }
    }

    private List<Integer> knownInstanceIds() {
      return allInstances.entrySet().stream().map(Map.Entry::getKey).collect(toList());
    }

    private boolean dbHasNewEvent() {
      int dbEventId = eventsQuery.getMaxEventId();
      if (dbEventId > lastKnownEvent) {
        lastKnownEvent = dbEventId;
        log.debug("Identified new event in DB: {}", dbEventId);
        return true;
      }
      return false;
    }

    private boolean dbHasNewAllocation() {
      int latestInDB = allocationQuery.getLatestAllocation();
      boolean cacheContainsLatest = allInstances.values().stream().map(a -> a.allocationEvent)
          .distinct()
          .anyMatch(event -> event == latestInDB);
      if (!cacheContainsLatest) {
        log.debug("Identified new allocation in DB: {}", latestInDB);
      }
      return !cacheContainsLatest;
    }
  }

}
