package olympus.sparta.base.db.mysql;

public class MySQLConstants {
  public static final String TABLE_SERVICE_INSTANCES = "serviceInstances";
  public static final String TABLE_EVENTS = "events";
  public static final String TABLE_ALLOCATION_HISTORY = "allocation_history";
  public static final String TABLE_REGISTERED_INSTANCES = "registered_instances";
  public static final String TABLE_CUSTOMER_SERVICE_BY_APP = "customer_service_by_app";
  public static final String TABLE_PROXY_ALLOCATIONS = "proxy_allocations";
}
