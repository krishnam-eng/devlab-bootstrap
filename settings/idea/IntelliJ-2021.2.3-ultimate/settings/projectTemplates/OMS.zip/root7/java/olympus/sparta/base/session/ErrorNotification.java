package olympus.sparta.base.session;

import olympus.sparta.base.session.Response;

public class ErrorNotification extends Response {
    int errorCode;
    String description;

    public ErrorNotification(ErrorResponse.ErrorCode err) {
        super(null, "error");
        errorCode = err.code;
        description = err.desc;
    }
}
