package olympus.sparta.agent.controller.db.queries;

import com.google.common.base.Function;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.model.SessionHBData;
import olympus.sparta.base.db.model.SimpleInstanceData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nullable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;
import static olympus.sparta.base.db.DBAdapter.DBException;
import static olympus.sparta.base.db.Host.getHostName;

public class ClientHBUpdateQuery {
    private static final Logger log = LoggerFactory.getLogger(ClientHBUpdateQuery.class);
    private final DBAdapter<AgentDBConnection> db;

    public ClientHBUpdateQuery(DBAdapter<AgentDBConnection> db) {
        this.db = db;
    }

    public Map<String, Integer> updateClientHb(final List<SessionHBData> sessions) {
        return db.executeTransaction(new Function<AgentDBConnection, Map<String, Integer>>() {
            @Override
            @Nullable
            public Map<String, Integer> apply(AgentDBConnection conn) {
                try {
                    int[] updatedBatchRows = conn.batchUpdateHB(getHostName(), sessions);
                    return getUpdateCounts(updatedBatchRows, sessions);
                } catch (SQLException ex) {
                    log.error("Failed to update heartbeat", ex);
                    throw new DBException(ex);
                }
            }
        });
    }

    private static Map<String, Integer> getUpdateCounts(int[] updatedBatchRows, List<SessionHBData> sessions) {
        Map<String, Integer> updates = new HashMap<>();
        for (int i = 0; i < sessions.size(); i++) {
            updates.put(sessions.get(i).getSessionId(), updatedBatchRows[i]);
        }
        return Collections.unmodifiableMap(updates);
    }

    public Map<String, List<SimpleInstanceData>> getAllInstancesBySessionId(List<String> sessionIds) {
        return db.select(connection -> {
            try {
                checkNotNull(connection);
                ResultSet rs = connection.selectAllInstances(sessionIds);
                return prepareResult(rs);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private Map<String, List<SimpleInstanceData>> prepareResult(final ResultSet rs) throws SQLException {
        Map<String, List<SimpleInstanceData>> map = new HashMap<>();
        while (rs.next()) {
            SimpleInstanceData data = new SimpleInstanceData(rs);
            String rowSessionId = data.getSessionId();

            List<SimpleInstanceData> results = map.computeIfAbsent(rowSessionId, s -> new ArrayList<>());
            results.add(data);
        }
        return map;
    }

}
