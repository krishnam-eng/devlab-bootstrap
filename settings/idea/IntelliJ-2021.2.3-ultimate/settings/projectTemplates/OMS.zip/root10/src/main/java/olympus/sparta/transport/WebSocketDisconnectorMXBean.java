package olympus.sparta.transport;

import javax.management.MXBean;

@MXBean
public interface WebSocketDisconnectorMXBean {

    String getAddress();

    int getInstanceId();

    void disconnect();

    String getServiceType();

    String getInfoJson();

    int getRegistrationEvent();

    int getUnRegistrationEvent();

    long getLastHbInTime();

    int getClientAckedVersion();

    int getAllocationEvent();

    String getSessionId();

    String getSpartaId();

    String getAllocatedBuckets();

    long getRegistrationTime();

    long getAllocationTime();
}
