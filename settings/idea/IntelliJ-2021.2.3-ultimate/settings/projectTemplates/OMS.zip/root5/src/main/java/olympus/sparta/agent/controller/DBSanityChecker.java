package olympus.sparta.agent.controller;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.ControllerConfig;
import olympus.sparta.agent.controller.db.queries.DBSanityQuery;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Timer;
import java.util.TimerTask;

public class DBSanityChecker {
  private static final Logger log = LoggerFactory.getLogger(DBSanityChecker.class);
  private static final long INITIAL_DELAY = 0;
  private static final long DB_SANITY_CHECKING_INTERVAL = 10 * 1000;
  private static final int WARN_FREQUENCY = 6; //so many times the sanity check interval
  private final Timer dbSanityTimer = new Timer("db_sanity_timer");
  private final DBSanityQuery query;
  private final ControllerConfig controllerConfig;
  private TimerTask currentTask;
  private int skippedIntervalCount = 0;

  public DBSanityChecker(DBAdapter<AgentDBConnection> db, ControllerConfig config) {
    this.controllerConfig = config;
    query = new DBSanityQuery(db);
    initTimerTask();
    dbSanityTimer.schedule(currentTask, INITIAL_DELAY, DB_SANITY_CHECKING_INTERVAL);
  }

  private void initTimerTask() {
    currentTask = new TimerTask() {
      @Override
      public void run() {
        try {
          log.trace("Running DB Sanity Checker");
          if (controllerConfig.isDBSanityCheckDisabled() || controllerConfig.isUnRegistrationDisabled()) {
            skippedIntervalCount++;
            warn();
            return;
          }
          query.cleanDb();
        } catch (Exception ex) {
          log.error("Error occurred while running DB Sanity Checker.", ex);
        }
      }
    };
  }

  private void warn() {
    if (0 == (skippedIntervalCount % WARN_FREQUENCY)) {
      if(controllerConfig.isUnRegistrationDisabled()) {
        log.warn("UN-REGISTRATION is DISABLED");
      } else {
        log.warn("DBSanityChecker is DISABLED");
      }
    }
  }
}
