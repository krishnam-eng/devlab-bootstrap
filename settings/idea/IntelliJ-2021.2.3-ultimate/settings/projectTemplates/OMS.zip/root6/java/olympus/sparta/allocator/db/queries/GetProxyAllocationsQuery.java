package olympus.sparta.allocator.db.queries;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.proxy.ProxyRemoteInstance;
import olympus.sparta.allocator.requests.GetProxiesResponse;
import olympus.sparta.base.db.DBAdapter;
import olympus.trace.OlympusSpectra;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetProxyAllocationsQuery {

    private static final SpectraLogger log = OlympusSpectra.getLogger(PutProxyAllocationQuery.class);
    private final DBAdapter<AllocationDBConnection> db;
    private final Gson gson = new Gson();

    public GetProxyAllocationsQuery(DBAdapter<AllocationDBConnection> db) {
        this.db = db;
    }

    public GetProxiesResponse getLatestProxyAllocations() {
        return db.select(connection -> {
            try {
                ResultSet rs = connection.getLatestProxies();
                if(rs.next()) {
                    String proxiesStr = rs.getString(1);
                    int version = rs.getInt(2);
                    List<ProxyRemoteInstance> proxies = gson.fromJson(proxiesStr, (new TypeToken<List<ProxyRemoteInstance>>() {
                    }).getType());
                    return new GetProxiesResponse(proxies, version);
                }
                return new GetProxiesResponse(new ArrayList<>(), 0);
            } catch (SQLException e) {
                log.error("Failed to get proxies", e).log();
                throw new RuntimeException(e);
            }
        });
    }

}
