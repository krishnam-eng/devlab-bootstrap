package functional.olympus.sparta;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import olympus.sparta.base.session.Response;
import olympus.sparta.transport.oldws.OldWSTransport;
import org.java_websocket.WebSocket;
import org.java_websocket.drafts.Draft;
import org.java_websocket.framing.Framedata;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.NotYetConnectedException;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class WebSocketStub implements WebSocket {
    private CopyOnWriteArrayList<String> responseList = new CopyOnWriteArrayList<>();
    private OldWSTransport transport;
    private boolean isClosed = false;

    public WebSocketStub(OldWSTransport transport) {
        this.transport = transport;
    }

    public JsonObject getResponse(int requestId) {
        JsonParser parser = new JsonParser();
        for (String response : responseList) {
            JsonObject json = parser.parse(response).getAsJsonObject();
            if (!Response.isUnsolicited(json.get("requestId").getAsString()) && json.get("requestId").getAsInt() == requestId) {
                return json;
            }
        }
        return null;
    }

    public void assertSent(String response) {
        System.out.println("Current responseList: " + responseList.toString());
        for (String r : responseList) {
            try {
                assertEquals(response, r);
                return;
            } catch (Throwable t) {

            }
        }
        fail("Response not sent: " + response);
    }

    public void assertSent(JsonElement element) {
        System.out.println("Current responseList: " + responseList.toString());
        JsonParser parser = new JsonParser();
        for (String r : responseList) {
            try {
                JsonElement sent = parser.parse(r);
                assertEquals(element, sent);
                return;
            } catch (Throwable t) {

            }
        }
        fail("Response not sent: " + element);
    }

    @Override
    public void close(int code, String message) {
        transport.onClose(this, code, message, true);
        isClosed = true;
    }

    @Override
    public void close(int code) {
        transport.onClose(this, code, "dontKnowThis", true);
        isClosed = true;
    }

    @Override
    public void close() {
        transport.onClose(this, 0, "dontKnowThis", true);
        isClosed = true;
    }

    @Override
    public void closeConnection(int code, String message) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void send(String text) throws NotYetConnectedException {
        System.out.println("CLIENT RECIEVED:::::::: " + text);
        responseList.add(text);
    }

    @Override
    public void send(ByteBuffer bytes) throws IllegalArgumentException, NotYetConnectedException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void send(byte[] bytes) throws IllegalArgumentException, NotYetConnectedException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void sendFrame(Framedata framedata) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean hasBufferedData() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public InetSocketAddress getRemoteSocketAddress() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public InetSocketAddress getLocalSocketAddress() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isConnecting() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isOpen() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isClosing() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isFlushAndClose() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isClosed() {
        return isClosed;
    }

    @Override
    public Draft getDraft() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public READYSTATE getReadyState() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
