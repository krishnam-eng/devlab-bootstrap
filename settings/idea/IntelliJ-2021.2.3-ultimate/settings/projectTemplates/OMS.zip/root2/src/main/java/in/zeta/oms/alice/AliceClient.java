package in.zeta.oms.alice;

import in.zeta.commons.zms.client.ZetaServiceClient;
import in.zeta.oms.alice.request.PingComputeInfraOpsPayload;
import in.zeta.oms.alice.request.PingPayload;
import in.zeta.oms.alice.response.PongPayload;
import java.util.concurrent.CompletionStage;
import olympus.annotations.Anonymous;
import olympus.annotations.GatewayTenant;
import olympus.annotations.Proteus;
import olympus.message.processor.MessagingService;
import olympus.message.types.EmptyPayload;
import olympus.message.types.Message;
import olympus.spartan.ImmutableMessage;

@GatewayTenant(AliceConstants.SERVICE_NAME)
public class AliceClient extends ZetaServiceClient {

  public AliceClient(MessagingService hostService) {
    super(AliceConstants.SERVICE_NAME, hostService);
    hostService.addClient(this);
  }

  @Override
  protected boolean isMeantForClient(ImmutableMessage message) {
    return false;
  }

  @Override
  protected void onMessageFromService(Message message) {}

  @Anonymous
  @Proteus("POST")
  public CompletionStage<PongPayload> ping(PingPayload.Builder builder) {
    return send(builder, PongPayload.class);
  }

  @Anonymous
  @Proteus("POST")
  public CompletionStage<EmptyPayload> pingComputeInfraOps(PingComputeInfraOpsPayload.Builder builder) {
    return send(builder, EmptyPayload.class);
  }
}
