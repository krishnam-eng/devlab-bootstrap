package olympus.sparta.agent.controller.db.queries;

import com.google.common.base.Function;
import olympus.sparta.agent.controller.hearbeat.ClientHBTracker;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkState;

public class DBSanityQuery {
    private static final Logger log = LoggerFactory.getLogger(DBSanityQuery.class);
    private static final long STALE_HB_INTERVAL = 4 * ClientHBTracker.CLIENT_HEART_BEAT_INTERVAL;

    private final DBAdapter<AgentDBConnection> db;

    public DBSanityQuery(DBAdapter<AgentDBConnection> db) {
        this.db = db;
    }

    public void cleanDb() {
        List<Integer> instances = getStaleInstances();
        unRegisterEach(instances);
    }

    private void unRegisterEach(List<Integer> instances) {
        for (final Integer instanceId : instances) {
            db.executeTransaction(connection -> {
                try {
                    log.info("Un-registering stale instance with instanceId: {}", instanceId);
                    int updateCount = connection.unRegisterIfStale(instanceId, STALE_HB_INTERVAL);
                    if (updateCount == 0) {
                        log.info("Rollbacking un-registration for instanceId {} ", instanceId);
                        connection.rollback();
                    }
                } catch (Exception e) {
                    log.error(String.format("Unable to unRegister instanceId: %s, Error: ", instanceId), e);
                }
                return null;
            });
        }
    }

    private List<Integer> getStaleInstances() {
        return db.executeTransaction(connection -> {
            try {
                ResultSet resultSet = connection.selectStaleHBInstances(STALE_HB_INTERVAL);
                List<Integer> instances = new ArrayList<>();
                while (resultSet.next()) {
                    instances.add(resultSet.getInt("instanceId"));
                }
                return instances;
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
    }


}
