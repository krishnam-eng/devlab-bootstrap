package olympus.sparta.mysql;

import com.google.common.base.Preconditions;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.db.model.CompleteInstanceData.InstanceView;
import olympus.sparta.mysql.mixins.ProxyMixin;
import olympus.sparta.mysql.mixins.ServiceInstanceMixin;
import olympus.sparta.mysql.mixins.AllocationMixin;
import olympus.sparta.base.db.mysql.MySQLConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.stream.Collectors;

import static olympus.sparta.base.db.mysql.MySQLConstants.TABLE_ALLOCATION_HISTORY;
import static olympus.sparta.base.db.mysql.MySQLConstants.TABLE_CUSTOMER_SERVICE_BY_APP;
import static olympus.sparta.base.db.mysql.MySQLConstants.TABLE_SERVICE_INSTANCES;

public class MySQLAllocationDBConnection extends AllocationDBConnection {

  private AllocationMixin allocationMixin;
  private ServiceInstanceMixin instanceMixin;
  private final ProxyMixin proxyMixin;

  public MySQLAllocationDBConnection(Connection conn) {
    super(conn);
    allocationMixin = new AllocationMixin(this);
    instanceMixin = new ServiceInstanceMixin(this);
    proxyMixin = new ProxyMixin(this);
  }

    @Override
  public int[] batchUpdateAllocation(Allocation allocation) throws SQLException {
      return time("update_allocations", () ->
              allocationMixin.batchUpdateAllocation(allocation));
  }

  @Override
  public int updateAllocationHistory(int systemVersion) throws SQLException {
    return time("update_alocation_history", () ->
            allocationMixin.updateAllocationHistory(systemVersion));
  }


  @Override
  public ResultSet getLatestAllocation() throws SQLException {
    return time("get_allocation", () -> {
      String sql = "SELECT allocationEvent FROM " + MySQLConstants.TABLE_ALLOCATION_HISTORY +
              " WHERE seq_num = (SELECT MAX(seq_num) seq_num FROM " + MySQLConstants.TABLE_ALLOCATION_HISTORY + ")";
      PreparedStatement statement = connection.prepareStatement(sql);
      return statement.executeQuery();
    });
  }

  @Override
  public ResultSet selectLatestVersion(String serviceType) throws SQLException {
    return time("get_latest_version", () -> {
      String SQL_LATEST_VERSION = String.format("SELECT GREATEST(IFNULL(max(registrationEvent),0),IFNULL(max(unRegistrationEvent),0)) FROM %s WHERE serviceType = ?", MySQLConstants.TABLE_SERVICE_INSTANCES);
      PreparedStatement stmt = connection.prepareStatement(SQL_LATEST_VERSION);
      stmt.setString(1, serviceType);
      return stmt.executeQuery();
    });
  }


  @Override
  public ResultSet selectHBStatus(List<Integer> instances) throws SQLException {
    Preconditions.checkState(instances != null && instances.size() > 0);
    return time("get_hb_status", () -> {
      String instanceIds = instances.stream().map(Object::toString).collect(Collectors.joining(","));

      String sql = "SELECT " +
              " instanceId, spartaId, sessionId, clientAckedVersion, " +
              ServiceInstanceMixin.selectUnixTimeInMillis("lastHbInTime", "lastHbInTime") +
              " FROM " + MySQLConstants.TABLE_SERVICE_INSTANCES +
              " WHERE instanceId IN (" + instanceIds + ")";

      PreparedStatement stmt = connection.prepareStatement(sql);
      return stmt.executeQuery();
    });
  }

  @Override
  public ResultSet selectRegistered(String serviceType, InstanceView view) throws SQLException {
    return time("get_registered", () ->
            instanceMixin.selectRegistered(serviceType, view));
  }

  @Override
  public ResultSet fetchRegisteredInstancesGreaterThan(int leastInstanceId, InstanceView view) throws SQLException {
    return time("get_registered_after", () ->
            instanceMixin.fetchRegisteredInstancesGreaterThan(leastInstanceId, view));
  }


  @Override
  public ResultSet getRegisteredOrUnRegisteredAfter(int eventId) throws SQLException {
    return time("get_registered_unregistered_after", () ->
            instanceMixin.getRegisteredOrUnRegisteredAfter(eventId));
  }


  @Override
  public ResultSet getCustomerServicesByApp(String app) throws SQLException {
    return time("get_customer_services", () -> {
      String query = "SELECT customer_service from "+ MySQLConstants.TABLE_CUSTOMER_SERVICE_BY_APP +" WHERE app = ?";
      PreparedStatement stmt = connection.prepareStatement(query);
      stmt.setString(1, app);
      return stmt.executeQuery();
    });
  }

  @Override
  public ResultSet selectMaxEventId() throws SQLException {
    return time("get_max_event", () -> {
      String SQL_MAX_EVENT_ID = "SELECT IFNULL(max(eventId),0) AS eventId FROM " + MySQLConstants.TABLE_EVENTS;
      PreparedStatement stmt = connection.prepareStatement(SQL_MAX_EVENT_ID);
      return stmt.executeQuery();
    });
  }

  @Override
  public void ping() throws SQLException {
    time("ping", () -> {
      String SQL_VALIDATION_QUERY = "SELECT 1";
      PreparedStatement statement = connection.prepareStatement(SQL_VALIDATION_QUERY);
      statement.execute();
      return null;
    });
  }

  @Override
  public int insertProxies(String proxies) throws SQLException {
    return time("put_proxies", () ->
            proxyMixin.insertProxy(proxies));
  }

  @Override
  public ResultSet getLatestProxies() throws SQLException {
    return time("get_proxies", () ->
            proxyMixin.getLatestVersion());
  }
}
