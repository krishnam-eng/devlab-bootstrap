package olympus.sparta.agent.controller.requests;

import olympus.sparta.agent.controller.Controller;
import olympus.sparta.base.session.Request;
import olympus.sparta.agent.controller.hearbeat.ClientHBDBUpdater;
import olympus.sparta.base.session.ClientSession;

import static java.lang.System.currentTimeMillis;

public class ClientHBUpdateRequest extends Request<Controller> {
    private final int clientVersion;
    private transient ClientHBDBUpdater clientHBDBUpdater;

    public ClientHBUpdateRequest(int clientVersion) {
        super(Request.RequestType.HEARTBEAT);
        this.clientVersion = clientVersion;
    }

    @Override
    public ClientHBUpdateRequest afterDeserialization(Controller controller) {
        this.clientHBDBUpdater = controller.getClientHBDBUpdater();
        return this;
    }

    @Override
    public void handleRequest(ClientSession clientSession) {
    }

    public void updateClientHbInMemory(ClientSession clientSession) {
        clientSession.setLastHbInTime(currentTimeMillis());
        clientSession.setClientAckedVersion(this.clientVersion);
        clientHBDBUpdater.notifyUpdate();
    }

    public int getClientVersion() {
        return clientVersion;
    }

    @Override
    public String toString() {
        return "ClientHBUpdateRequest{" +
                "clientVersion=" + clientVersion +
                '}';
    }
}
