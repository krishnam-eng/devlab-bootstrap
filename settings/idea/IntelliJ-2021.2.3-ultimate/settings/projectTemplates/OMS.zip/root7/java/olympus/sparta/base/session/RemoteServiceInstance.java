package olympus.sparta.base.session;

import static com.google.common.base.Preconditions.checkState;

public class RemoteServiceInstance {
    private int instanceId;
    private String serviceType;
    private String address;
    private boolean registered;
    private int registrationEvent;
    private int unRegistrationEvent;
    private String infoJson;

    public RemoteServiceInstance() {
    }

    public void setRegistered(int instanceId, String serviceType, String address, int registrationEvent, String infoJson) {
        this.instanceId = instanceId;
        this.serviceType = serviceType;
        this.address = address;
        this.registrationEvent = registrationEvent;
        this.infoJson = infoJson;
        registered = true;
    }

    public void setUnRegistered(int unRegistrationEvent) {
        checkState(registered, "Cannot un-register an instance which is not registered.");
        registered = false;
        this.unRegistrationEvent = unRegistrationEvent;
    }

    public int getInstanceId() {
        return instanceId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public String getAddress() {
        return address;
    }

    public boolean isRegistered() {
        return registered;
    }

    public String getJID() {
        return registered ? instanceId + "@" + serviceType + ".services.olympus" : "not-registered";
    }

    public int getRegistrationEvent() {
        return registrationEvent;
    }

    public int getUnRegistrationEvent() {
        return unRegistrationEvent;
    }

    @Override
    public String toString() {
        return "[jid:" + getJID() + "]";
    }

    public String getInfoJson() {
        return infoJson;
    }
}
