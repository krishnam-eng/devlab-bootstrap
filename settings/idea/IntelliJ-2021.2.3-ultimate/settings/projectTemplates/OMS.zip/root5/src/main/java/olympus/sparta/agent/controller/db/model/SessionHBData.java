package olympus.sparta.agent.controller.db.model;

import olympus.sparta.base.session.ClientSession;

public class SessionHBData {
  private int instanceCount;
  private String sessionId;
  private int ackedHBVersion;
  private long lastHbInTime;

  public SessionHBData(ClientSession session) {
    ackedHBVersion = session.getClientAckedVersion();
    instanceCount = session.getRegisteredInstanceCount();
    sessionId = session.getSessionId();
    lastHbInTime = session.getLastHbInTime();
  }

  public int getInstanceCount() {
    return instanceCount;
  }

  public String getSessionId() {
    return sessionId;
  }

  public int getAckedHBVersion() {
    return ackedHBVersion;
  }

  public long getLastHbInTime() {
    return lastHbInTime;
  }

  @Override
  public String toString() {
    return getSessionId();
  }
}
