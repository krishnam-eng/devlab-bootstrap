package olympus.sparta.agent.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import in.zeta.commons.crypto.ZetaKeyPair;
import in.zeta.commons.gson.ZetaGsonBuilder;
import in.zeta.commons.zms.api.SignablePayload;
import olympus.common.JID;
import olympus.sparta.base.PropertyHandler;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Created by vivekyadav on 1/22/16.
 */
public class PublicKeyCertIssuer {
    private static final JID caJID = Optional.ofNullable(PropertyHandler.getInstance().getStringValue("clusterName"))
            .map(clusterName -> new JID("sparta-" + clusterName + ".services.olympus"))
            .orElse(new JID("sparta.services.olympus"));
    private static final ZetaKeyPair zetaKeyPair = makeZetaKeyPair();
    private static final Gson gson = new ZetaGsonBuilder().build();

    public static String makeServiceInstancePublicKeyCertificate(String serviceType, String infoJson, int instanceId) throws IOException {
        if (serviceType.equals("certstore")) return null;
        JsonObject json = new JsonParser().parse(infoJson).getAsJsonObject();
        if (!json.has("instancePublicKey")) return null;
        String base64EncodedPublicKey = json.get("instancePublicKey").getAsString();

        String certificate = makeCertificate(base64EncodedPublicKey,
          JID.serviceInstanceJID(serviceType, Integer.toString(instanceId)));
        return Base64.getEncoder().encodeToString(certificate.getBytes());
    }

    private static String makeCertificate(String base64EncodedPublicKey, JID subjectJID) {
        Map<String, Map<String,String>> purposeWithAttributes =new HashMap<>();
        purposeWithAttributes.put("serviceSignature", new HashMap<String, String>());

        PublicKeyCertificate certificate = new PublicKeyCertificate.Builder()
        .certID(String.join("_", caJID.toString(), subjectJID.toString(),
          String.valueOf(System.currentTimeMillis())))
        .type("PUBLIC_KEY")
        .issuerJID(caJID)
        .subjectJID(subjectJID)
        .issuedOn(System.currentTimeMillis())
        .validTill(Long.MAX_VALUE)
        .isRevoked(false)
        .base64EncodedPublicKey(base64EncodedPublicKey)
        .certificateAttributes(new HashMap<String, String>())
        .purposeWithAttributes(purposeWithAttributes)
        .build();

        zetaKeyPair.sign(certificate, caJID);
        return gson.toJson(certificate, PublicKeyCertificate.class);
    }


    private static ZetaKeyPair makeZetaKeyPair() {
        String privateKeyProperty = System.getProperty("environmentName", "local") + ".ca.privateKey";
        String publicKeyProperty = System.getProperty("environmentName", "local") + ".ca.publicKey";
        return new ZetaKeyPair(PropertyHandler.getInstance().getStringValue(privateKeyProperty),
          PropertyHandler.getInstance().getStringValue(publicKeyProperty));
    }


    public static class PublicKeyCertificate extends SignablePayload {
        public final String certID;
        public final String type;
        public final JID issuerJID;
        public final JID subjectJID;
        public final long issuedOn;
        public final long validTill;
        public final boolean isRevoked;
        public final String base64EncodedPublicKey;
        public final Map<String, Map<String, String>> purposeWithAttributes;
        public final Map<String, String> certificateAttributes;

        public PublicKeyCertificate(Builder builder) {
            this.certID = builder.certID;
            this.type = builder.type;
            this.issuerJID = builder.issuerJID;
            this.subjectJID = builder.subjectJID;
            this.issuedOn = builder.issuedOn;
            this.validTill = builder.validTill;
            this.isRevoked = builder.isRevoked;
            this.base64EncodedPublicKey = builder.base64EncodedPublicKey;
            this.purposeWithAttributes = builder.purposeWithAttributes;
            this.certificateAttributes = builder.certificateAttributes;
        }

        public static class Builder {
            public String certID;
            public String type;
            public JID issuerJID;
            public JID subjectJID;
            public long issuedOn;
            public long validTill;
            public boolean isRevoked;
            public String base64EncodedPublicKey;
            public Map<String, Map<String, String>> purposeWithAttributes;
            public Map<String, String> certificateAttributes;

            public Builder certID(String certID) {
                this.certID = certID;
                return this;
            }

            public Builder type(String type) {
                this.type = type;
                return this;
            }

            public Builder issuerJID(JID issuerJID) {
                this.issuerJID = issuerJID;
                return this;
            }

            public Builder subjectJID(JID subjectJID) {
                this.subjectJID = subjectJID;
                return this;
            }

            public Builder issuedOn(long issuedOn) {
                this.issuedOn = issuedOn;
                return this;
            }

            public Builder validTill(long validTill) {
                this.validTill = validTill;
                return this;
            }

            public Builder isRevoked(boolean isRevoked) {
                this.isRevoked = isRevoked;
                return this;
            }

            public Builder base64EncodedPublicKey(String base64EncodedPublicKey) {
                this.base64EncodedPublicKey = base64EncodedPublicKey;
                return this;
            }

            public Builder purposeWithAttributes(Map<String, Map<String, String>> purposeWithAttributes) {
                this.purposeWithAttributes = purposeWithAttributes;
                return this;
            }

            public Builder certificateAttributes(Map<String, String> certificateAttributes) {
                this.certificateAttributes = certificateAttributes;
                return this;
            }

            public PublicKeyCertificate build(){
                return new PublicKeyCertificate(this);
            }
        }
    }
}