package olympus.sparta.agent.controller.db.queries;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.SimpleInstanceData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nullable;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Lists.newArrayList;

public class ReConnectionQuery {
  private static final Logger log = LoggerFactory.getLogger(ReConnectionQuery.class);
  private static final List<SimpleInstanceData> emptyList = Collections.unmodifiableList(Lists.newArrayList());
  private final DBAdapter<AgentDBConnection> db;
  private final String sessionId;
  private final ClientHBUpdateQuery hbQuery;

  public ReConnectionQuery(DBAdapter<AgentDBConnection> db, String sessionId) {
    this.db = db;
    this.sessionId = sessionId;
    hbQuery = new ClientHBUpdateQuery(db);
  }

  public List<SimpleInstanceData> getAllInstancesForCurrentSession() {
    Map<String, List<SimpleInstanceData>> data = hbQuery.getAllInstancesBySessionId(newArrayList(sessionId));
    return data.getOrDefault(sessionId, emptyList);
  }

  public Integer updateSpartaIdAndClientHb(final long hbInTime, final int clientAckedVersion) {
    return db.executeTransaction(connection -> {
      try {
        Preconditions.checkArgument(connection != null, "connection is null");
        return connection.updateSpartaIdAndClientHb(hbInTime,
            clientAckedVersion, sessionId);
      } catch (SQLException e) {
        log.error("Failed to update spartaId for sessionId {}", sessionId, e);
        throw new RuntimeException(e);
      }
    });
  }

}


