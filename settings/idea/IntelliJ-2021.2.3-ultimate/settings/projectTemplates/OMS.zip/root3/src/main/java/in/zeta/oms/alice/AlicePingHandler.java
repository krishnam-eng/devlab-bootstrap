package in.zeta.oms.alice;

import static java.util.concurrent.CompletableFuture.completedFuture;

import in.zeta.commons.eagersingleton.EagerSingleton;
import in.zeta.commons.zms.service.ZetaHostMessagingService;
import in.zeta.oms.alice.request.PingPayload;
import in.zeta.oms.alice.response.PongPayload;
import in.zeta.spectra.capture.SpectraLogger;
import javax.inject.Inject;
import olympus.message.types.Request;
import olympus.trace.OlympusSpectra;

@EagerSingleton
public class AlicePingHandler extends AliceRequestHandler {
  public static final SpectraLogger log = OlympusSpectra.getLogger(
      AlicePingHandler.class);

  private final PingService pingService;

  @Inject
  public AlicePingHandler(
      ZetaHostMessagingService zetaHostMessagingService, PingService pingService) {
    super(zetaHostMessagingService);
    this.pingService = pingService;
    zetaHostMessagingService.addRequestHandler(this);
  }

  public void on(
      PingPayload payload,
      Request<PingPayload> request) {
    super.on(payload, request);
    completedFuture(null)
        .thenCompose(__ -> pingService.pingBob(payload.getNodeID()))
        .thenAccept(__ -> sendResponse(request, PongPayload.builder().build()))
        .exceptionally(t -> sendError(request, t));
  }
}
