package olympus.sparta.allocator.db;

import olympus.metrics.MetricLogger;
import olympus.metrics.TimeKeeper;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.base.db.ConnectionDelegate;
import olympus.sparta.base.db.model.CompleteInstanceData;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.Callable;

public abstract class AllocationDBConnection extends ConnectionDelegate {

  private static final MetricLogger metricLogger = MetricLogger.getLogger(AllocationDBConnection.class);
  protected static final String METRIC_PREFIX = "sparta.db.allocation.statement.";

  public abstract void ping() throws SQLException;

  public AllocationDBConnection(Connection conn) {
    super(conn);
  }

  public ResultSet selectRegistered(String serviceType) throws SQLException {
    return selectRegistered(serviceType, CompleteInstanceData.InstanceView.FULL);
  }
  public abstract ResultSet fetchRegisteredInstancesGreaterThan(int leastInstanceId, CompleteInstanceData.InstanceView view) throws SQLException;


  public abstract ResultSet selectHBStatus(List<Integer> instances) throws SQLException;

  public abstract ResultSet selectRegistered(String serviceType, CompleteInstanceData.InstanceView view) throws SQLException;

  /**
    Updates allocations in a batch instead of a single transaction to let us yield the locks between updates
    for each instance, thus, reducing possibility of deadlock at DB.
   */
  public abstract int[] batchUpdateAllocation(Allocation allocation) throws SQLException;

  public abstract int updateAllocationHistory(int systemVersion) throws SQLException;

  public abstract ResultSet getLatestAllocation() throws SQLException;

  public abstract ResultSet selectLatestVersion(String serviceType) throws SQLException;

  public abstract ResultSet getRegisteredOrUnRegisteredAfter(int eventId) throws SQLException;

  public abstract ResultSet getCustomerServicesByApp(String app) throws SQLException;

  public abstract ResultSet selectMaxEventId() throws SQLException;

  public abstract int insertProxies(String proxies) throws SQLException;

  public abstract ResultSet getLatestProxies() throws SQLException;

  protected <T> T time(String metric, Callable<T> callable) throws SQLException {
    try (TimeKeeper.Event timer = metricLogger.timeKeeper(METRIC_PREFIX + metric).start()) {
      return callable.call();
    } catch (SQLException sqlException) {
      metricLogger.counter(METRIC_PREFIX + metric + ".failure").increment();
      throw sqlException;
    } catch (Exception e) {
      metricLogger.counter(METRIC_PREFIX + metric + ".failure").increment();
      throw new RuntimeException(e);
    }
  }
}
