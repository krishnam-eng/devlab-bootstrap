package in.zeta.oms.alice;

import com.google.inject.Inject;
import in.zeta.oms.bob.BobClient;
import in.zeta.oms.bob.request.PingPayload;
import in.zeta.oms.bob.response.PongPayload;
import java.util.concurrent.CompletionStage;
import javax.inject.Singleton;

@Singleton
public class PingService {
  private final BobClient bobClient;

  @Inject
  public PingService(BobClient bobClient) {
    this.bobClient = bobClient;
  }

  public CompletionStage<PongPayload> pingBob(String nodeID) {
    return bobClient.ping(PingPayload.builder().nodeID(nodeID));
  }
}
