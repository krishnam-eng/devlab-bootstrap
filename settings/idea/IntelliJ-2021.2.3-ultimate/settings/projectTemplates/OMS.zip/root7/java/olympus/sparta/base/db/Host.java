package olympus.sparta.base.db;

import java.net.UnknownHostException;

import static java.net.InetAddress.getLocalHost;

public class Host {
    private static final String HOSTNAME;

    static {
        String host = "localhost";
        try {
            host = getLocalHost().getHostName();
        } catch (UnknownHostException e) {
        }
        HOSTNAME = host;
    }

    public static String getHostName() {
        return HOSTNAME;
    }
}
