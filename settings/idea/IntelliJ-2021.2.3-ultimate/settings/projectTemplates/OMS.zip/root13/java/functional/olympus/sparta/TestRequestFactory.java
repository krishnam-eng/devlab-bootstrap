package functional.olympus.sparta;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class TestRequestFactory {

    public String createReConnectRequest(int requestId, String sessionId) {
        JsonObject body = new JsonObject();
        body.addProperty("requestId", requestId);
        body.addProperty("sessionId", sessionId);
        JsonObject request = new JsonObject();
        request.addProperty("type", "RE_CONNECTION");
        request.add("body", body);
        return new Gson().toJson(request);
    }

    public String createRegisterRequest(int requestId) {
        return createRegisterRequest(requestId, "tcp://192.168.55.1:8040");
    }

    public String createRegisterRequest(int requestId, String listeningAddress) {
        JsonObject infoJson = new JsonObject();
        infoJson.addProperty("key", "value");
        JsonObject body = new JsonObject();
        body.addProperty("requestId", requestId);
        body.addProperty("serviceType", "test");
        body.addProperty("address", listeningAddress);
        body.addProperty("infoJson", new Gson().toJson(infoJson));
        JsonObject request = new JsonObject();
        request.addProperty("type", "REGISTER");
        request.add("body", body);
        return new Gson().toJson(request);
    }


    public String createUnRegisterRequest(int requestId, String jid) {
        JsonObject body = new JsonObject();
        body.addProperty("requestId", requestId);
        body.addProperty("jid", jid);
        JsonObject request = new JsonObject();
        request.addProperty("type", "UN_REGISTER");
        request.add("body", body);
        return new Gson().toJson(request);
    }
}
