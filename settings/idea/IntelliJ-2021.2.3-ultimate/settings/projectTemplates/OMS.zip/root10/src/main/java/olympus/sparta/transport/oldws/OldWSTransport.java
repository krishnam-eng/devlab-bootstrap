package olympus.sparta.transport.oldws;

import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.base.session.ClientConnection;
import olympus.sparta.base.session.ClientSessionStore;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.util.concurrent.ConcurrentHashMap;

public class OldWSTransport extends WebSocketServer {
  private static final Logger log = LoggerFactory.getLogger(OldWSTransport.class);
  private final RequestHandler requestHandler;
  private final ClientSessionStore clientSessionStore;
  private final Controller agentController;
  private final AllocatorModule allocatorModule;
  private final ConcurrentHashMap<WebSocket, ClientConnection> socketToClientConnection = new ConcurrentHashMap<>();

  public OldWSTransport(int port,
                        RequestHandler req,
                        ClientSessionStore clientSessionStore,
                        Controller agentController,
                        AllocatorModule allocatorModule) {
    super(new InetSocketAddress(port));
    this.requestHandler = req;
    this.clientSessionStore = clientSessionStore;
    this.agentController = agentController;
    this.allocatorModule = allocatorModule;
  }

  @Override
  public void start() {
    log.info("Starting transport at address: {}", this.getAddress());
    super.start();
  }

  @Override
  public void onOpen(WebSocket webSocket, ClientHandshake clientHandshake) {
    OldWSClientConnection connection = new OldWSClientConnection(webSocket, requestHandler, agentController, allocatorModule);
    socketToClientConnection.put(webSocket, connection);
    clientSessionStore.add(connection.getClientSession());
  }

  @Override
  public void onClose(WebSocket webSocket, int code, String reason, boolean closedByRemote) {
    log.info("Client socket {} closed. by_remote: {}, reason: {}",
        webSocket.getRemoteSocketAddress(),
        closedByRemote,
        reason);
    socketToClientConnection.remove(webSocket).getClientSession().disconnect();
  }

  @Override
  public void onMessage(WebSocket webSocket, String msg) {
    socketToClientConnection.get(webSocket).getClientSession().onClientMessage(msg);
  }

  @Override
  public void onError(WebSocket webSocket, Exception e) {
    if (null == webSocket) {
      log.error("WebSocketServer failed", e);
      System.exit(5);
    } else {
      log.warn("Client Socket error: {}", webSocket.getRemoteSocketAddress(), e);
    }
  }

}
