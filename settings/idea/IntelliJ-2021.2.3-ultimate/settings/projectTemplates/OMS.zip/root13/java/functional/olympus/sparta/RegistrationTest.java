package functional.olympus.sparta;

import org.junit.Test;

public class RegistrationTest extends FunctionalTest {
    final String sessionId = "eruiojsdf";

    @Test
    public void testRegister() {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        assertClientReceived("{\"requestId\":\"2\",\"type\":\"response\",\"body\":{\"jid\":\"1@test.services.olympus\"," +
                "\"systemVersion\":1}}");
        sendRequest(testRequestFactory.createUnRegisterRequest(3, "1@test.services.olympus"));
    }

    @Test
    public void testIdempotentReRegisters() {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));

        sendRequest(testRequestFactory.createRegisterRequest(2));
        assertClientReceived("{\"requestId\":\"2\",\"type\":\"response\",\"body\":{\"jid\":\"1@test.services.olympus\"," +
                "\"systemVersion\":1}}");

        sendRequest(testRequestFactory.createRegisterRequest(3));
        assertClientReceived("{\"requestId\":\"3\",\"type\":\"response\",\"body\":{\"jid\":\"1@test.services.olympus\"," +
                "\"systemVersion\":1}}");


        sendRequest(testRequestFactory.createUnRegisterRequest(4, "1@test.services.olympus"));
    }
}
