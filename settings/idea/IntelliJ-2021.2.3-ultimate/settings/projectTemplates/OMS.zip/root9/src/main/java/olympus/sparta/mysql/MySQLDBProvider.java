package olympus.sparta.mysql;

import olympus.sparta.DBProvider;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;

public class MySQLDBProvider implements DBProvider {

  private final MySQLDataSource dataSource;
  private final DBAdapter<AgentDBConnection> agentDB;
  private final DBAdapter<AllocationDBConnection> allocationDB;

  public MySQLDBProvider(String connectionString) throws Exception {
    this.dataSource = new MySQLDataSource(connectionString);
    agentDB = new DBAdapter<>(() -> new MySQLAgentDBConnection(dataSource.get()));
    allocationDB = new DBAdapter<>(() -> new MySQLAllocationDBConnection(dataSource.get()));
  }

  @Override
  public DBAdapter<AgentDBConnection> getAgentDB() {
    return agentDB;
  }

  @Override
  public DBAdapter<AllocationDBConnection> getAllocationDB() {
    return allocationDB;
  }
}
