package olympus.sparta.allocator.allocation;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.RemoteServiceInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class FairAllocator implements Allocator {
    private static final Logger log = LoggerFactory.getLogger(FairAllocator.class);
    private static final int DEFAULT_VERSION = 0;
    private final Map<String, SettableFuture<Allocation>> futureAllocations =
            Collections.synchronizedMap(new HashMap<>());
    private final Set<String> servicesInterested = Collections.synchronizedSet(new HashSet<>());
    private final AllocationWorker worker;
    private final Map<String, Integer> requiredAllocationVersion = new ConcurrentHashMap<>();
    private volatile boolean shutdown = false;

    public FairAllocator(DBAdapter<AllocationDBConnection> db, AtroposPublisher atroposPublisher) {
        worker = new AllocationWorker(db, this, atroposPublisher);
        worker.start();
    }

    @Override
    public ListenableFuture<Allocation> getAllocation(String serviceType, int version) {
        return getAllocation(serviceType, version, null);
    }

    @Override
    public ListenableFuture<Allocation> getAllocation(String serviceType, int version, RemoteServiceInstance primaryServiceInstance) {
        ListenableFuture<Allocation> future = futureAllocations.get(serviceType);
        Allocation allocation = null;
        try {
            allocation = future == null || !future.isDone() ? null : future.get();
        } catch (Exception e) {
            log.error("Exception : ", e);
        }
        boolean requiresRefresh = allocation == null || allocation.getSystemVersion() < version || version == DEFAULT_VERSION;
        if (requiresRefresh) {
            log.trace("Requires refreshing allocations of {}", serviceType);
            return refreshAllocation(serviceType, version);
        }
        log.trace("Returning allocation from cache for {} version {}", serviceType, version);
        return future;
    }

    @Override
    public ListenableFuture<Allocation> refreshAllocation(String serviceType, int requiredSystemVersion) {
        // Force-refreshes an allocation
        if (shutdown) throw new RuntimeException("Shutdown");
        ListenableFuture<Allocation> f;
        synchronized (futureAllocations) {
            SettableFuture<Allocation> allocation = futureAllocations.get(serviceType);
            if (allocation == null || allocation.isDone()) {
                allocation = SettableFuture.create();
                futureAllocations.put(serviceType, allocation);
                servicesInterested.add(serviceType);
            }
            if (!requiredAllocationVersion.containsKey(serviceType) ||
                    requiredSystemVersion > requiredAllocationVersion.get(serviceType)) {
                requiredAllocationVersion.put(serviceType, requiredSystemVersion);
            }
            f = allocation;
        }
        worker.refreshAllocation(serviceType);
        return f;
    }

    @Override
    public Set<String> getServicesInterested() {
        return servicesInterested;
    }

    @Override
    public void updateAllocation(Allocation allocation) {
        synchronized (futureAllocations) {
            if (!canAcceptAllocation(allocation)) {
                refreshAllocation(allocation.getServiceType(), getRequiredVersion(allocation.getServiceType()));
                return;
            }
            SettableFuture<Allocation> future = futureAllocations.get(allocation.getServiceType());
            if (!future.set(allocation)) {
                future = SettableFuture.create();
                future.set(allocation);
                futureAllocations.put(allocation.getServiceType(), future);
            }
            if (allocation instanceof NullAllocation) {
                //Don't bother about services which don't have any active instances
                //until a client requests for allocation with a later version.
                servicesInterested.remove(allocation.getServiceType());
            }
        }
    }

    private int getRequiredVersion(String serviceType) {
        synchronized (futureAllocations) {
            Integer val = requiredAllocationVersion.get(serviceType);
            if (null == val) {
                return 0;
            }
            return val;
        }
    }

    private boolean canAcceptAllocation(Allocation allocation) {
        int requiredVersion = getRequiredVersion(allocation.getServiceType());
        if (allocation.getSystemVersion() < requiredVersion) {
            log.trace("Clients are waiting for version {} of {}; So ignoring allocation version: {}",
                    requiredVersion, allocation.getServiceType(), allocation.getSystemVersion());
            return false;
        }
        return true;
    }

    @Override
    public void shutdown() {
        worker.shutdown();
    }
}
