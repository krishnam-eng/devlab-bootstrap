package olympus.sparta.transport.jetty.servlets;

import com.google.common.io.CharStreams;
import com.google.common.net.MediaType;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import olympus.sparta.base.session.Request;
import olympus.sparta.requests.RequestFactory;
import olympus.sparta.base.session.SessionAgnosticRequest;
import olympus.sparta.requests.RequestHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.google.common.net.MediaType.JSON_UTF_8;
import static in.zeta.commons.concurrency.CompletableFutures.exceptionallyCompletedFuture;

/***
 * Provides a mechanism to process all non-session bound requests through a HTTP Socket
 */
public class GenericRequestServlet extends BaseServlet {
  private static Logger log = LoggerFactory.getLogger(GenericRequestServlet.class);

  private static final SessionAgnosticRequest failedRequest = () -> exceptionallyCompletedFuture(new RuntimeException("Unknown Request"));
  private final RequestFactory factory;
  private final QueryStringParser qsParser = new QueryStringParser();

  public GenericRequestServlet(RequestFactory factory) {
    this.factory = factory;
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    JsonObject reqJson = jsonFromQueryString(req);
    complete(req, resp, getRequest(reqJson).complete());
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    JsonObject bodyJson = parseBody(req);
    complete(req, resp, getRequest(bodyJson).complete());
  }

  private SessionAgnosticRequest getRequest(JsonObject reqJson) {
    try {
      Request spartaRequest = factory.produce(reqJson);
      return (spartaRequest instanceof SessionAgnosticRequest) ? (SessionAgnosticRequest) spartaRequest : failedRequest;
    } catch (Exception e) {
      log.warn("Failed to  process request", e);
      return failedRequest;
    }
  }

  private JsonObject jsonFromQueryString(HttpServletRequest req) {
    return qsParser.parseAsJson(req.getParameterMap());
  }

  private JsonObject parseBody(HttpServletRequest req) throws IOException {
    JsonObject postJson = null;
    String contentType = req.getContentType();
    if (!isNullOrEmpty(contentType)) {
      MediaType mediaType = MediaType.parse(contentType);
      if (JSON_UTF_8.is(mediaType)) {
        postJson = getJSONData(req);
      }
    }
    return postJson;
  }

  private JsonObject getJSONData(HttpServletRequest req) throws IOException {
    String body = CharStreams.toString(req.getReader());
    if (!isNullOrEmpty(body)) {
      JsonObject bodyJson = new JsonParser().parse(body).getAsJsonObject();
      log.debug("READ BODY {} from {}:{}", bodyJson, req.getRemoteHost(), req.getRemotePort());
      return bodyJson;
    }
    return null;
  }

}
