package olympus.sparta.base.db.model;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;

public class Util {
  public static final String PUBSUB_SUBSCRIPTIONS = "pubsub_subscriptions";
  private static Gson gson = new Gson();

  static ArrayList<String> parseSubscribedTopics(String infoJson) {
    ArrayList<String> subscribedTopics = new ArrayList<>();
    if(null == infoJson) {
      return subscribedTopics;
    }
    HashMap<String, String> info;
    info = gson.fromJson(infoJson, new TypeToken<HashMap<String, String>>(){}.getType());
    String subscriptionStr = info.get(PUBSUB_SUBSCRIPTIONS);
    if(null != subscriptionStr) {
      JsonArray arr = new JsonParser().parse(subscriptionStr).getAsJsonArray();
      for(JsonElement e : arr) {
        JsonObject obj = e.getAsJsonObject();
        String topic = obj.get("topic").getAsString();
        subscribedTopics.add(topic);
      }
    }
    return subscribedTopics;
  }


}
