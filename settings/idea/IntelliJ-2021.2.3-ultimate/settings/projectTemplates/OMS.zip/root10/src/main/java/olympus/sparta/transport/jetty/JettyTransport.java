package olympus.sparta.transport.jetty;

import olympus.sparta.DBProvider;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.transport.jetty.servlets.FetchAllocationServlet;
import olympus.sparta.transport.jetty.servlets.GenericRequestServlet;
import olympus.sparta.transport.jetty.servlets.HealthCheckServlet;
import olympus.sparta.transport.jetty.servlets.ProxyAllocationServlet;
import olympus.sparta.transport.jetty.servlets.WebSocketServlet;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.HttpConnectionFactory;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class JettyTransport {
  private static Logger log = LoggerFactory.getLogger(JettyTransport.class);
  private Server httpServer;
  private final RequestHandler spartaRequestHandler;
  private final ClientSessionStore clientSessionStore;
  private final Controller agentController;
  private final AllocatorModule allocatorModule;
  private final DBProvider dbProvider;

  public JettyTransport(RequestHandler spartaRequestHandler,
                        ClientSessionStore clientSessionStore,
                        Controller agentController,
                        AllocatorModule allocatorModule,
                        DBProvider dbProvider) {
    this.spartaRequestHandler = spartaRequestHandler;
    this.clientSessionStore = clientSessionStore;
    this.agentController = agentController;
    this.allocatorModule = allocatorModule;
    this.dbProvider = dbProvider;
  }

  public void start(int port) throws Exception {
    prepareServer(port);
    httpServer.start();
  }

  private void prepareServer(int port) {
    PropertyHandler propertyHandler = PropertyHandler.getInstance();
    int maxThreadCount = propertyHandler.getIntValue("sparta.jetty.maxThreads", 200);
    int minThreadCount = propertyHandler.getIntValue("sparta.jetty.minThreads", 10);
    QueuedThreadPool threadPool = new QueuedThreadPool(maxThreadCount, minThreadCount);
    threadPool.setName("jetty-request-thread");
    threadPool.setDetailedDump(false);
    httpServer = new Server(threadPool);
    ServerConnector http = new ServerConnector(httpServer, new HttpConnectionFactory());
    http.setPort(port);
    http.setIdleTimeout(30000);
    httpServer.setConnectors(new Connector[]{http});

    ServletContextHandler servletContext = new ServletContextHandler();
    servletContext.setContextPath("/");
    servletContext.addServlet(new ServletHolder(new WebSocketServlet(spartaRequestHandler, clientSessionStore, agentController, allocatorModule)), "/ws");
    servletContext.addServlet(new ServletHolder(new FetchAllocationServlet(allocatorModule.getAllocator())), "/allocation");
    servletContext.addServlet(new ServletHolder(new GenericRequestServlet(spartaRequestHandler.getRequestFactory())), "/sparta");
    servletContext.addServlet(new ServletHolder(new HealthCheckServlet()), "/health");
    servletContext.addServlet(new ServletHolder(new ProxyAllocationServlet(dbProvider.getAllocationDB())), "/proxies");
    httpServer.setHandler(servletContext);

    httpServer.setRequestLog((request, response) -> {
      log.info("REQUEST {}:{} {} {} || RESPONSE {}",
          request.getRemoteAddr(),
          request.getRemotePort(),
          request.getRequestURL(),
          Optional.ofNullable(request.getQueryString()).orElse(""),
          response.getStatus()
      );
    });
  }

  public void stop() {
    try {
      httpServer.stop();
    } catch (Exception e) {
      log.error("Failed to stop jetty server", e);
    }
  }
}
