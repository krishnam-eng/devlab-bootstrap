package olympus.sparta.allocator.db.queries;

import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.HBUpdateInfo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HearBeatUpdatesQuery {
  private final DBAdapter<AllocationDBConnection> db;

  public HearBeatUpdatesQuery(DBAdapter<AllocationDBConnection> db) {
    this.db = db;
  }

  public List<HBUpdateInfo> getHBUpdates(List<Integer> instances) {
    if (instances.size() == 0) {
      return Collections.emptyList();
    }
    return db.select(connection -> {
      try {
        ArrayList<HBUpdateInfo> result = new ArrayList<HBUpdateInfo>();
        ResultSet rs = connection.selectHBStatus(instances);
        while (rs.next()) {
          result.add(new HBUpdateInfo(rs));
        }
        return result;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }
}
