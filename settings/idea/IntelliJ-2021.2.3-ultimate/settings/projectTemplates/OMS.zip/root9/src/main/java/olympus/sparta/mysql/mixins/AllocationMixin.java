package olympus.sparta.mysql.mixins;

import olympus.sparta.allocator.allocation.AllocatedInstance;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.mysql.MySQLAllocationDBConnection;
import olympus.sparta.base.db.mysql.MySQLConstants;
import org.apache.commons.lang3.StringUtils;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class AllocationMixin {
  private final MySQLAllocationDBConnection mySQLConnection;

  public AllocationMixin(MySQLAllocationDBConnection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }


  public int[] batchUpdateAllocation(Allocation allocation) throws SQLException {
    String SQL_UPDATE_ALLOCATION = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES + " SET " +
        " allocatedBuckets = ? , allocationEvent = ? WHERE instanceId = ? AND IFNULL(allocationEvent,0) < ?";
    PreparedStatement statement = mySQLConnection.prepareStatement(SQL_UPDATE_ALLOCATION);
    List<AllocatedInstance> instances = allocation.getInstances();
    for (AllocatedInstance instance : instances) {
      statement.setString(1, StringUtils.join(instance.getBuckets(), ","));
      statement.setInt(2, allocation.getSystemVersion());
      statement.setInt(3, instance.getInstanceId());
      statement.setInt(4, allocation.getSystemVersion());
      statement.addBatch();
    }
    return statement.executeBatch();
  }

  public int updateAllocationHistory(int systemVersion) throws SQLException {
    PreparedStatement statement = mySQLConnection.prepareStatement("INSERT INTO " + MySQLConstants.TABLE_ALLOCATION_HISTORY + " (allocationEvent) " +
        " VALUES (?)");
    statement.setInt(1, systemVersion);
    return statement.executeUpdate();
  }

}