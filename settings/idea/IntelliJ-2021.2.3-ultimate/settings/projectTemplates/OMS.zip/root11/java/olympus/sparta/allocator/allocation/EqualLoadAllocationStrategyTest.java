package olympus.sparta.allocator.allocation;

import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.db.model.CompleteInstanceData;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.stream.IntStream;

public class EqualLoadAllocationStrategyTest {

    @Test
    public void reAllocate() throws Exception {
        PropertyHandler.getInstance().load(EqualLoadAllocationStrategyTest.class.getResourceAsStream("/sparta.properties"));
        EqualLoadAllocationStrategy allocationStrategy = new EqualLoadAllocationStrategy();

        int[] allBuckets = IntStream.range(0, 1000).toArray();
        
        AllocatedInstance firstInstance = new AllocatedInstance(new CompleteInstanceData(1, "test-service",
                "address:port", "{}", System.currentTimeMillis(), System.currentTimeMillis(), allBuckets));
        AllocatedInstance secondInstance = new AllocatedInstance(new CompleteInstanceData(2, "test-service",
                "address2:port2", "{}", System.currentTimeMillis(), System.currentTimeMillis(), new int[0]));

        Allocation currentAllocation = new Allocation("test-service", 1, Arrays.asList(firstInstance, secondInstance));
        allocationStrategy.reAllocate(currentAllocation);

        Assert.assertEquals(500, firstInstance.getBucketCount());
        Assert.assertEquals(500, secondInstance.getBucketCount());
    }
}