package olympus.sparta.transport;


import in.zeta.spectra.capture.SpectraLogger;
import olympus.metrics.Adder;
import olympus.metrics.MetricLogger;
import olympus.metrics.base.SummaryType;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.agent.controller.requests.UnRegisterRequest;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.allocator.ServerHBSender;
import olympus.sparta.allocator.requests.FetchAllRegisteredRequest;
import olympus.sparta.base.session.ClientConnection;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.sparta.base.session.Response;
import olympus.sparta.requests.RequestHandler;
import olympus.trace.OlympusSpectra;
import org.java_websocket.exceptions.WebsocketNotConnectedException;

import javax.annotation.Nullable;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.lang.System.currentTimeMillis;

/***
 *
 */
public class ClientSessionImpl implements ClientSession {
  private static final SpectraLogger log = OlympusSpectra.getLogger(ClientSessionImpl.class);
  private static final MetricLogger metrics = MetricLogger.getLogger(ClientSessionImpl.class);
  private static final Adder responseSizeAdder = metrics.adder("sparta.response.sizeInChars");

  static {
    responseSizeAdder.includeSummary(SummaryType.COUNT);
    responseSizeAdder.includeSummary(SummaryType.MEDIAN);
  }


  private static AtomicInteger sessionCounter = new AtomicInteger(0);
  private final int serverGeneratedId = sessionCounter.incrementAndGet();
  private final ClientConnection connection;
  private final List<RemoteServiceInstance> instances = new Vector<>();
  private final InetSocketAddress remoteAddress;
  private final RequestHandler requestHandler;
  private final Controller agentController;
  private final WebSocketDisconnector websocketDisconnector;
  private final Map<String, String> attributes = new ConcurrentHashMap<>();
  private volatile String sessionId;
  private volatile long lastHbInTime;
  private volatile int clientAckedVersion;
  private volatile boolean disconnected = false;
  private volatile int reclaimedSessionServerId = -1;
  private Runnable onCloseRunnable;


  public ClientSessionImpl(ClientConnection connection, RequestHandler requestHandler, Controller agentController, AllocatorModule allocatorModule) {
    this.connection = connection;
    this.lastHbInTime = currentTimeMillis();
    this.remoteAddress = connection.getRemoteSocketAddress();
    this.requestHandler = requestHandler;
    this.agentController = agentController;
    this.websocketDisconnector = new WebSocketDisconnector(this, allocatorModule);
  }

  @Override
  public synchronized RemoteServiceInstance create() {
    RemoteServiceInstance remoteServiceInstance = new RemoteServiceInstance();
    instances.add(remoteServiceInstance);
    return remoteServiceInstance;
  }

  @Override
  public synchronized RemoteServiceInstance createOrGet(int instanceId) {
    for (RemoteServiceInstance instance : instances) {
      if (instance.getInstanceId() == instanceId) {
        return instance;
      }
    }
    return create();
  }

  @Override
  public void send(Response response) {
    if (disconnected) {
      decorateMarker(log.info("DROPPED")).attr("message", response.toJson());
      return;
    }
    log(response);
    try {
      String json = response.toJson();
      responseSizeAdder.add(json.length());
      connection.send(json);
    } catch (WebsocketNotConnectedException ex) {
      disconnect();
      decorateMarker(log.warn("WRITE ERROR: " + ex.getMessage(), ex)).attr("body", response).log();
    } catch (Exception e) {
      decorateMarker(log.warn("WRITE ERROR (General): " + e.getMessage(), e)).attr("body", response).log();
    }
  }

  private void log(Response response) {
    SpectraLogger.Marker m;
    if (response instanceof ServerHBSender.Response) {
      m = log.trace("Sending Server HB");
    } else if (response instanceof FetchAllRegisteredRequest.Response) {
      m = log.trace("Response: " + response.getType());
    } else if (response instanceof ErrorResponse) {
      ErrorResponse e = (ErrorResponse) response;
      m = log.warn("Error Response")
          .attr("description", e.getDescription())
          .attr("code", e.getErrorCode());
    } else {
      m = log.debug("Response: " + response.getType());
    }
    decorateMarker(m).attr("body", response.toJson()).log();
  }

  @Override
  @Nullable
  public RemoteServiceInstance getServiceInstance(int instanceId) {
    for (RemoteServiceInstance remoteServiceInstance : instances) {
      if (remoteServiceInstance.getInstanceId() == instanceId)
        return remoteServiceInstance;
    }
    return null;
  }

  @Override
  public RemoteServiceInstance getRegisteredServiceInstance(String serviceType, String address) {
    for (RemoteServiceInstance instance : instances) {
      if (Objects.equals(instance.getServiceType(), serviceType) &&
              Objects.equals(instance.getAddress(), address)
              && instance.isRegistered()) {
        return instance;
      }
    }
    return null;
  }

  @Override
  public synchronized List<RemoteServiceInstance> getInstances() {
    return Collections.unmodifiableList(new ArrayList<>(instances));
  }

  @Override
  public RemoteServiceInstance getPrimaryServiceInstance() {
    return instances.stream()
        .filter(RemoteServiceInstance::isRegistered)
        .findFirst()
        .orElseGet(() -> {
          if (!instances.isEmpty())
            return instances.get(0);
          return null;
        });
  }

  @Override
  public int getRegisteredInstanceCount() {
    int count = 0;
    for (RemoteServiceInstance ri : getInstances()) {
      if (ri.isRegistered()) count++;
    }
    return count;
  }

  @Override
  public void close() {
    if (!isReclaimedLocally()) {
      unRegisterIfOwnedByThisSparta();
    }
    disconnect();
    websocketDisconnector.unregisterInJMX();
    if (null != onCloseRunnable) {
      onCloseRunnable.run();
    }
  }

  @Override
  public void onClientDisconnect() {
    disconnected = true;
    decorateMarker(log.info("CLIENT DISCONNECTED")).log();
  }

  @Override
  public void setOnCloseListener(Runnable r) {
    onCloseRunnable = r;
  }

  @Override
  public void onClientMessage(String msg) {
    decorateMarker(log.trace("Received message").attr("msg", msg)).log();
    try {
      requestHandler.handleRequest(this, msg);
    } catch (Exception e) {
      decorateMarker(log.error("Cannot handle request", e)).log();
    }
  }

  @Override
  public void onConnected() {
    decorateMarker(log.info("CONNECTED")).log();
    requestHandler.onConnected(this);
  }

  public void disconnect() {
    connection.close();
    onClientDisconnect();
  }

  @Override
  public int getServerGeneratedId() {
    return serverGeneratedId;
  }

  @Override
  public SpectraLogger.Marker decorateMarker(SpectraLogger.Marker m) {
    return m
        .attr("serverGeneratedID", this.getServerGeneratedId())
        .attr("sessionID", this.getSessionId())
        .attr("remoteAddress", this.getRemoteAddress())
        .attr("disconnected", this.disconnected)
        .attr("instances", this.getInstances())
        .fill(attributes)
        ;
  }

  private boolean isReclaimedLocally() {
    return reclaimedSessionServerId != -1;
  }

  @Override
  public long getLastHbInTime() {
    return lastHbInTime;
  }

  @Override
  public void setLastHbInTime(long lastHbInTime) {
    this.lastHbInTime = lastHbInTime;
    agentController.getClientHBDBUpdater().notifyUpdate();
  }

  @Override
  public int getClientAckedVersion() {
    return clientAckedVersion;
  }

  @Override
  public void setClientAckedVersion(int clientAckedVersion) {
    this.clientAckedVersion = clientAckedVersion;
  }

  @Override
  public void remove(RemoteServiceInstance remoteServiceInstance) {
    instances.remove(remoteServiceInstance);
  }

  @Override
  public String toString() {
    return "WebSocketClientSession{" +
        "serverGeneratedId=" + serverGeneratedId +
        ", remoteAddress=" + remoteAddress +
        ", sessionId='" + sessionId + '\'' +
        ", attributes=" + attributes +
        ", instances=" + instances +
        ", clientAckedVersion=" + clientAckedVersion +
        ", disconnected=" + disconnected +
        '}';
  }

  @Override
  public void setSessionId(String sessionId) {
    checkNotNull(sessionId, "sessionId should not be null");
    this.sessionId = sessionId;
  }

  @Override
  public String getSessionId() {
    return sessionId;
  }

  @Override
  public InetSocketAddress getRemoteAddress() {
    return remoteAddress;
  }

  @Override
  public void setReclaimedByOther(ClientSession reclaimingSession) {
    decorateMarker(log.info("RECLAIMED")).attr("otherSession", reclaimingSession).log();
    this.reclaimedSessionServerId = reclaimingSession.getServerGeneratedId();
    close();
  }

  @Override
  public Optional<ClientConnection> getConnection() {
    return Optional.ofNullable(connection);
  }

  @Override
  public boolean hasUnRegisteredInstances() {
    List<RemoteServiceInstance> instanceList = getInstances();
    for (RemoteServiceInstance ri : instanceList) {
      if (!ri.isRegistered()) return true;
    }
    return false;
  }

  private void unRegisterIfOwnedByThisSparta() {
    for (RemoteServiceInstance remoteServiceInstance : getInstances()) {
      if (remoteServiceInstance.isRegistered()) {
        try {
          UnRegisterRequest request = new UnRegisterRequest(remoteServiceInstance.getJID(), agentController);
          request.handleRequest(this, true);
        } catch (Exception e) {
          log.error("Unexpected error", e);
        }
      }
    }
  }

  @Override
  public int executorKey() {
    return connection.hashCode();
  }

  @Override
  public void onRegistered() {
    websocketDisconnector.registerInJMX();
  }

  public void setAttribute(String key, String value) {
    attributes.put(key, value);
  }
}
