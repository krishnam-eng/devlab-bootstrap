package olympus.sparta.allocator.allocation;

import com.google.common.util.concurrent.ListenableFuture;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.session.RemoteServiceInstance;

import java.util.List;
import java.util.Set;

public interface Allocator {
    int BUCKET_COUNT = PropertyHandler.getInstance().getIntValue("bucket.count");

    ListenableFuture<Allocation> getAllocation(String serviceType, int version);

    ListenableFuture<Allocation> getAllocation(String serviceType, int version, RemoteServiceInstance primaryServiceInstance);

    ListenableFuture<Allocation> refreshAllocation(String serviceType, int requiredSystemVersion);

    Set<String> getServicesInterested();

    void updateAllocation(Allocation allocation);

    void shutdown();
}
