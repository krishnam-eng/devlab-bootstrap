package functional.olympus.sparta.utils;

import olympus.common.JID;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.bootstrap.Bootstrap;
import olympus.sparta.DBProvider;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.session.ClientSessionStore;

import static olympus.sparta.base.db.Host.getHostName;

public class Modules {
  private DatabaseUtils db;
  private AllocatorModule allocatorModule;
  private Controller controller;
  private ClientSessionStore clientSessionStore;

  public Modules() {
    // if (Modules.db != null) return;
    try {
      prepareProperties();
      db = new DatabaseUtils();
      clientSessionStore = new ClientSessionStore();
      AtroposPublisher atroposPublisher = new AtroposPublisher(new JID("services.olympus", "sparta", getHostName()));
      allocatorModule = new AllocatorModule(db.getProvider().getAllocationDB(), clientSessionStore, atroposPublisher);
      controller = new Controller(db.getProvider().getAgentDB(), clientSessionStore, atroposPublisher);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private void prepareProperties() throws Exception {
    PropertyHandler p = PropertyHandler.getInstance();
    p.load(Bootstrap.class.getResourceAsStream("/sparta.properties"));
    p.loadFromEnv();
    p.loadFromSystem();
  }

  public DatabaseUtils getDBUtils() {
    return db;
  }

  public DBProvider getDBProvider() {
    return db.getProvider();
  }

  public AllocatorModule getAllocatorModule() {
    return allocatorModule;
  }

  public Controller getAgentController() {
    return controller;
  }

  public ClientSessionStore getClientSessionStore() {
    return clientSessionStore;
  }
}
