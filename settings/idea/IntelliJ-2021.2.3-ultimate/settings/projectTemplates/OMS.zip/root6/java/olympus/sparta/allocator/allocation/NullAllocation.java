package olympus.sparta.allocator.allocation;

import java.util.ArrayList;

public class NullAllocation extends Allocation {
    NullAllocation(String serviceType, int systemVersion) {
        super(serviceType, systemVersion, new ArrayList<AllocatedInstance>());
    }

    @Override
    public boolean isValid() {
        return true;
    }
}
