package in.zeta.oms.alice.response;

import in.zeta.commons.zms.api.ZetaPayload;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PongPayload extends ZetaPayload {
}
