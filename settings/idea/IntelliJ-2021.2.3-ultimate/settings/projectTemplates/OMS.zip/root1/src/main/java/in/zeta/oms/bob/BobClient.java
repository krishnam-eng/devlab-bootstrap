package in.zeta.oms.bob;

import in.zeta.commons.zms.client.ZetaServiceClient;
import in.zeta.oms.bob.request.PingComputeInfraOpsPayload;
import in.zeta.oms.bob.request.PingPayload;
import in.zeta.oms.bob.response.PongPayload;
import java.util.concurrent.CompletionStage;
import olympus.annotations.Anonymous;
import olympus.annotations.GatewayTenant;
import olympus.annotations.Proteus;
import olympus.message.processor.MessagingService;
import olympus.message.types.EmptyPayload;
import olympus.message.types.Message;
import olympus.spartan.ImmutableMessage;

@GatewayTenant(BobConstants.SERVICE_NAME)
public class BobClient extends ZetaServiceClient {

  public BobClient(MessagingService hostService) {
    super(BobConstants.SERVICE_NAME, hostService);
    hostService.addClient(this);
  }

  @Override
  protected boolean isMeantForClient(ImmutableMessage message) {
    return false;
  }

  @Override
  protected void onMessageFromService(Message message) {}

  /**
   * Rate limit is not added to deliverSanityEvent API to avoid throttling for atropos retries
   * @return
   */
  @Anonymous
  @Proteus("POST")
  public CompletionStage<PongPayload> ping(PingPayload.Builder builder) {
    return send(builder, PongPayload.class);
  }

  @Anonymous
  @Proteus("POST")
  public CompletionStage<EmptyPayload> pingComputeInfraOps(PingComputeInfraOpsPayload.Builder builder) {
    return send(builder, EmptyPayload.class);
  }

}
