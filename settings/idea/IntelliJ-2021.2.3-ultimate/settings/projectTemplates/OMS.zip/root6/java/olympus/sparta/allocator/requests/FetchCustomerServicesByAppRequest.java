package olympus.sparta.allocator.requests;

import static java.util.concurrent.CompletableFuture.completedFuture;
import static olympus.sparta.base.session.Request.RequestType.FETCH_CUSTOMER_SERVICES_BY_APP;

import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import java.util.List;
import java.util.concurrent.CompletionStage;

import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import olympus.sparta.base.session.SessionAgnosticRequest;
import olympus.sparta.allocator.util.CustomerServicesByAppCache;
import olympus.trace.OlympusSpectra;


/*
New terminology
app: application running on sparta eg: collections
service: service being provided to customer eg: supertag payment
 */
public class FetchCustomerServicesByAppRequest extends Request<AllocatorModule> implements SessionAgnosticRequest {

  private static SpectraLogger log = OlympusSpectra
      .getLogger(FetchCustomerServicesByAppRequest.class);
  private static Gson gson = new Gson();

  public class Response extends olympus.sparta.base.session.Response {
    public final List<String> services;

    Response(List<String> services) {
      super(FetchCustomerServicesByAppRequest.this.getRequestId());
      this.services = services;
    }

    @Override
    public String toString() {
      return String.format("%s/%s: %s", FETCH_CUSTOMER_SERVICES_BY_APP, requestId, toJson());
    }

    @Override
    public String toJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      JsonObject body = new JsonObject();
      JsonArray array = new JsonArray();
      for (String data : services) {
        array.add(gson.toJsonTree(data));
      }
      body.add("services", array);
      obj.add("body", body);
      return obj.toString();
    }
  }

  private transient CustomerServicesByAppCache cache;
  private final String app;

  public FetchCustomerServicesByAppRequest(String requestId, String app) {
    super(FETCH_CUSTOMER_SERVICES_BY_APP);
    this.app = app;
    this.requestId = requestId;
  }

  @Override
  public FetchCustomerServicesByAppRequest afterDeserialization(AllocatorModule module) {
    this.cache = module.getCustomerServicesByAppCache();
    return this;
  }

  @Override
  public void handleRequest(ClientSession clientSession) {
    Preconditions.checkNotNull(cache);
    try {
      clientSession.decorateMarker(log.info(FETCH_CUSTOMER_SERVICES_BY_APP.toString()))
          .attr("requestId", requestId)
          .attr("app", app)
          .log();
      List<String> customerServices = cache.getCustomerServices(app);
      clientSession.send(new Response(customerServices));
    } catch (Throwable t) {
      log.WARN("Error while fetching customer services for app {}", app, t);
      clientSession.send(errorResponse(ErrorResponse.ErrorCode.UNKNOWN_ERROR));
    }
  }

  @Override
  public CompletionStage<FetchCustomerServicesByAppRequest.Response> complete() {
    return completedFuture(new FetchCustomerServicesByAppRequest.Response(cache.getCustomerServices(app)));
  }

  @Override
  public String toString() {
    return String.format("%s/%s", FETCH_CUSTOMER_SERVICES_BY_APP, requestId);
  }
}

