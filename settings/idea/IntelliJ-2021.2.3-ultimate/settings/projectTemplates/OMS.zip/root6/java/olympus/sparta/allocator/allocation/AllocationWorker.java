package olympus.sparta.allocator.allocation;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.metrics.Counter;
import olympus.metrics.MetricLogger;
import olympus.metrics.TimeKeeper;
import olympus.pubsub.model.OperationType;
import olympus.pubsub.model.PubSubEvent;
import olympus.pubsub.model.TopicScope;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.AllocationQuery;
import olympus.sparta.allocator.db.queries.ServiceInstanceQuery;
import olympus.sparta.allocator.util.BlockingSet;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.trace.OlympusSpectra;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fetches allocation from DB and notifies {@link Allocator} in the following cases:</li>
 * <ul>
 *     <li>on demand (through {@link \#refreshAllocation}</li>
 *     <li>periodic fetch from DB for {@link Allocator\#getServicesInterested()} services</li>
 * </ul>
 */
public class AllocationWorker extends Thread {
    private static final SpectraLogger logger = OlympusSpectra.getLogger(AllocationWorker.class);

    private static final MetricLogger metricLogger = MetricLogger.getLogger(AllocationWorker.class);
    private static final Counter allocationCounter = metricLogger.counter("sparta.allocationCount");
    private static final TimeKeeper oneAllocationTimer = metricLogger.timeKeeper("sparta.allocation.allocate");

    private static final int POLLING_INTERVAL = PropertyHandler.getInstance().getIntValue("allocation.polling.interval.millis", 5000);
    private static final int POLLING_INITIAL_DELAY = PropertyHandler.getInstance().getIntValue("allocation.polling.interval.millis", 500);

    private volatile boolean shutdown;
    private final DBAdapter<AllocationDBConnection> db;
    private final Allocator allocator;
    private final AllocationStrategy strategy = new EqualLoadAllocationStrategy();
    private final Map<String, Allocation> allocations = new ConcurrentHashMap<>();
    private final ExecutorService updateDispatcher = Executors.newSingleThreadExecutor();
    private final BlockingSet<String> allocationRequests = new BlockingSet<>();
    private final Timer dbAllocationWatcherTimer = new Timer("db_allocation_watcher", true);
    private final AtroposPublisher publisher;


    AllocationWorker(DBAdapter<AllocationDBConnection> db, Allocator allocator, AtroposPublisher atroposPublisher) {
        super("allocation");
        this.db = db;
        this.allocator = allocator;
        this.publisher = atroposPublisher;
        dbAllocationWatcherTimer.schedule(new DbAllocationWatcherTask(), POLLING_INITIAL_DELAY, POLLING_INTERVAL);
    }

    void shutdown() {
        if (!shutdown) {
            shutdown = true;
            this.interrupt();
            dbAllocationWatcherTimer.cancel();
        }
    }

    @Override
    public void run() {
        while (!shutdown) {
            try {
                String service = allocationRequests.take();
                logger.trace("Checking for allocation changes").attr("serviceType", service).log();
                try (TimeKeeper.Event timer = oneAllocationTimer.start()) {
                    allocate(service);
                }
            } catch (Exception e) {
                logger.error("Exception received while running allocationWorker", e).log();
            }
        }
    }

    /**
     * Refresh allocation from DB
     * Notify even if we have the latest version cached, required for allocation fetches with DEFAULT_VERSION
     *
     * @param serviceType
     */
    public synchronized void refreshAllocation(String serviceType) {
        // Remove local allocation to trigger notification to Allocator even if allocation in DB happens to be what is already known in memory
        allocations.remove(serviceType);
        try {
            allocationRequests.put(serviceType);
        } catch (InterruptedException e) {
            logger.error("Error queueing allocation", e).attr("serviceType", serviceType).log();
        }
    }

    protected void allocate(String serviceType) {
        Allocation allocation = null;
        while (allocation == null) {
            Allocation oldAllocation = allocations.get(serviceType);
            Allocation dbAllocation = allocationFromDB(serviceType);
            if (dbAllocation.isValid()) {
                allocation = dbAllocation;
                if (!dbAllocation.equals(oldAllocation)) {
                    // This could be because either the DB has newer allocation or we're force-refreshing allocation
                    //  for DEFAULT_VERSION allocation fetch
                    if (oldAllocation == null) {
                        logger.info("Fetched allocation from database")
                                .attr("serviceType", serviceType)
                                .attr("systemVersion", dbAllocation.getSystemVersion()).log();
                    } else {
                        logger.info("Updating allocation from database")
                                .attr("serviceType", dbAllocation.getServiceType())
                                .attr("systemVersion", dbAllocation.getSystemVersion()).log();
                    }
                } else {
                    logger.info("no change in allocation")
                            .attr("serviceType", serviceType)
                            .attr("systemVersion", oldAllocation.getSystemVersion()).log();
                    return; // No need to notify non-change
                }
            } else {
                allocation = reAllocate(dbAllocation);
            }
            if (null != allocation) {
                notifyAllocation(allocation);
            } else {
                try {
                    // backoff to protect Database from busy-loop. All Sparta instances would be competing to write valid Allocation
                    Thread.sleep(PropertyHandler.getInstance().getIntValue("sparta.allocator.db.breather.millis", 100));
                } catch (InterruptedException ignored) {

                }
            }

            //If strategy consistently fails to a valid allocation
            //this could cause an infinite loop!
        }
    }

    protected Allocation reAllocate(Allocation allocation) {
        try {
            strategy.reAllocate(allocation);
            if (!allocation.isValid()) {
                logger.error("CRITICAL: Strategy failed to make a valid allocation")
                        .attr("serviceType", allocation.getServiceType())
                        .attr("allocation", allocation).log();
                return null;
            }
            if (persistToDB(allocation)) {
                logger.info("Persisted new allocation")
                        .attr("serviceType", allocation.getServiceType())
                        .attr("allocation", allocation).log();
                allocationCounter.increment();
                return allocation;
            }
            logger.info("Another Sparta instance might have persisted this or higher version of allocation")
                    .attr("serviceType", allocation.getServiceType())
                    .attr("systemVersion", allocation.getSystemVersion()).log();
            //Force to read allocation from DB
            return null;
        } catch (Exception e) {
            logger.warn("Failed to persistToDB allocation", e)
                    .attr("serviceType", allocation.getServiceType())
                    .attr("allocation", allocation).log();
            return null;
        }
    }

    /**
     * Notify allocation to {@link Allocator} in a worker thread
     * To be called even if no change in allocation is detected because {@link Allocator} may be waiting for it to fulfill Lookup with DEFAULT_VERSION
     *
     * @param allocation
     */
    protected synchronized void notifyAllocation(Allocation allocation) {
        allocations.put(allocation.getServiceType(), allocation);
        logger.debug("Notifying allocation")
                .attr("serviceType", allocation.getServiceType())
                .attr("systemVersion", allocation.getSystemVersion())
                .attr("allocation", allocation).log();
        updateDispatcher.submit(() -> {
            // Do this on a separate thread as there could be listeners waiting for this event.
            // If any of them are doing I/O, the allocator gets blocked.
            // It is also possible that the I/O may fail as the allocationworker thread is interrupted each time
            // a new allocation may need to be made.
            allocator.updateAllocation(allocation);
        });
        publisher.publish(new PubSubEvent.Builder()
                .topicScope(TopicScope.SYSTEM)
                .tenant("0")
                .objectType("allocation")
                .objectID(allocation.getServiceType())
                .sourceObjectType("cluster")
                .data(allocation.toBucketRangesJson())
                .operationType(OperationType.UPDATED)
                .stateMachineState("ALLOCATION_CHANGE")
                .tags(new ArrayList<>()));
    }

    protected boolean persistToDB(Allocation allocation) {
        AllocationQuery query = new AllocationQuery(db);
        return query.persist(allocation);
    }

    protected Allocation allocationFromDB(String serviceType) {
        ServiceInstanceQuery query = new ServiceInstanceQuery(db);
        int version = query.getLatestVersion(serviceType);
        // The version returned by getLatestVersion and data returned by getRegistered
        //  could be in-consistent. We pick max of getLatestVersion() and version of
        //  registered instances.
        List<CompleteInstanceData> result = query.getRegistered(serviceType);

        int versionFromRegistered = result.stream()
                .map(completeInstanceData -> completeInstanceData.registrationEvent)
                .max(Integer::compareTo)
                .orElse(0);
        int maxVersion = Math.max(version, versionFromRegistered);

        ArrayList<AllocatedInstance> instances = new ArrayList<>();
        for (CompleteInstanceData instanceData : result) {
            instances.add(new AllocatedInstance(instanceData));
        }
        if (instances.size() == 0) {
            logger.info("Service has no registered instances. Using NullAllocation")
                    .attr("serviceType", serviceType).log();
            return new NullAllocation(serviceType, maxVersion);
        }
        return new Allocation(serviceType, maxVersion, instances);
    }

    private class DbAllocationWatcherTask extends TimerTask {
        @Override
        public void run() {
            allocator.getServicesInterested().forEach(s -> {
                try {
                    allocationRequests.put(s);
                } catch (InterruptedException e) {
                    logger.error("Exception reading interested services", e).log();
                }
            });
        }

    }
}
