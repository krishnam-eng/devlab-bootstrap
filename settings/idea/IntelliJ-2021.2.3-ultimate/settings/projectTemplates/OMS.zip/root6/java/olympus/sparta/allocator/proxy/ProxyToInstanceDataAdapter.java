package olympus.sparta.allocator.proxy;

import olympus.sparta.base.db.model.CompleteInstanceData;
import org.apache.http.client.utils.URIBuilder;

import java.util.stream.IntStream;

import static olympus.sparta.allocator.allocation.Allocator.BUCKET_COUNT;
import static olympus.spartan.proxy.ProxyAwareSpartaManager.TOKEN_KEY;
import static olympus.spartan.proxy.ProxyConstants.LISTENING_ADDRESS_SCHEME;

public class ProxyToInstanceDataAdapter {

    private static final int[] ALL_BUCKETS = IntStream.range(0, BUCKET_COUNT).toArray();

    public static CompleteInstanceData getCompleteInstanceData(ProxyRemoteInstance proxyRemoteInstance, int version) {
        return new CompleteInstanceData(version,    // IMP: keeping this same as version of the proxy because there is a check at client,
                // that if the instance id is same then the address should also be same.
                proxyRemoteInstance.getDestination(),
                getEndpoint(proxyRemoteInstance),
                proxyRemoteInstance.getInfoJson(),
                System.currentTimeMillis(),
                System.currentTimeMillis(),
                ALL_BUCKETS);
    }

    private static String getEndpoint(ProxyRemoteInstance proxy) {
        try {
            URIBuilder uriBuilder = new URIBuilder(proxy.getProxy());
            if (proxy.getToken() != null) {
                uriBuilder.addParameter(TOKEN_KEY, proxy.getToken());
            }
            return LISTENING_ADDRESS_SCHEME + uriBuilder.build().toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
