package olympus.sparta.mysql.mixins;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.base.db.Host;
import olympus.sparta.base.db.mysql.MySQLConstants;
import olympus.sparta.mysql.MySQLAgentDBConnection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class UnRegisterMixin {
  private final MySQLAgentDBConnection mySQLConnection;

  public UnRegisterMixin(MySQLAgentDBConnection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }

  public Statement setUnRegisteredIfStale(int unRegistrationEvent, int instanceId, long staleHbInterval) throws SQLException {
    String sql = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES +
        " SET unRegistrationEvent = ?, spartaId = ? " +
        " WHERE unRegistrationEvent IS NULL AND instanceId = ? " +
        " AND lastHbInTime < TIMESTAMPADD(MICROSECOND, - (?)*1000 , CURRENT_TIMESTAMP)";
    PreparedStatement statement = mySQLConnection.prepareStatement(sql);
    statement.setInt(1, unRegistrationEvent);
    statement.setString(2, "db-sanity-checker:" + Host.getHostName());
    statement.setInt(3, instanceId);
    statement.setLong(4, staleHbInterval);
    statement.execute();
    return statement;
  }

  public int unRegisterIfStale(int instanceId, long staleHbInterval)
      throws SQLException {
    int eventId = mySQLConnection.insertAndGetEventId();
    Statement statement = setUnRegisteredIfStale(eventId, instanceId, staleHbInterval);
    int updateCount = statement.getUpdateCount();
    if (updateCount == 1) {
      mySQLConnection.updateEvent(AgentDBConnection.EventType.UNREGISTER, eventId, instanceId);
    }
    return updateCount;
  }

  public int unRegisterIfLocal(int instanceId)
      throws SQLException {
    int eventId = mySQLConnection.insertAndGetEventId();
    Statement statement = setUnRegisteredIfLocal(eventId, instanceId, Host.getHostName());
    int updateCount = statement.getUpdateCount();
    if (updateCount == 1) {
      mySQLConnection.updateEvent(AgentDBConnection.EventType.UNREGISTER, eventId, instanceId);
    }
    return updateCount;
  }

  private Statement setUnRegisteredIfLocal(int unRegistrationEvent, int instanceId, String spartaId) throws SQLException {
    String SQL_UPDATE_UN_REGISTER_IF_LOCAL = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES +
        " SET unRegistrationEvent = ? " +
        "WHERE instanceId = ? AND spartaId = ? AND unRegistrationEvent IS NULL";
    PreparedStatement statement = mySQLConnection.prepareStatement(SQL_UPDATE_UN_REGISTER_IF_LOCAL);
    statement.setInt(1, unRegistrationEvent);
    statement.setInt(2, instanceId);
    statement.setString(3, spartaId);
    statement.execute();
    return statement;
  }

}
