package olympus.sparta.agent.controller.db.queries;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import in.zeta.commons.gson.ZetaGsonBuilder;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.ControllerConfig;
import olympus.sparta.agent.controller.requests.RegisterRequest;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkState;
import static olympus.sparta.agent.controller.PublicKeyCertIssuer.makeServiceInstancePublicKeyCertificate;
import static olympus.sparta.base.db.Host.getHostName;

public class RegisterQuery {
    private static final Logger log = LoggerFactory.getLogger(RegisterQuery.class);
    private static final Gson gson = new ZetaGsonBuilder().build();

    private final DBAdapter<AgentDBConnection> db;
    private final ControllerConfig controllerConfig;
    private final RegisterRequest registerRequest;
    private String sessionId;

    public static class Result {
        private final int instanceId;
        private final int registrationEvent;
        private String infoJson;

        private Result(int instanceId, int ts) {
            this.instanceId = instanceId;
            this.registrationEvent = ts;
        }

        //region Getter Methods
        public int getInstanceId() {
            return instanceId;
        }

        public int getRegistrationEvent() {
            return registrationEvent;
        }

        public String getInfoJson() {
            return infoJson;
        }
        //endregion

        public void setInfoJson(String infoJson) {
            this.infoJson = infoJson;
        }
    }

    public RegisterQuery(DBAdapter<AgentDBConnection> db, ControllerConfig controllerConfig, RegisterRequest registerRequest, String sessionId) {
        this.db = db;
        this.registerRequest = registerRequest;
        this.sessionId = sessionId;
        this.controllerConfig = controllerConfig;
    }

    public Result register() {
        return db.executeTransaction(connection -> {
          Result result;
          try {
              Optional<Result> existingInstance = findExistingInstance(connection);
              if (existingInstance.isPresent()) {
                  return existingInstance.get();
              } else {
                  register(connection);
                  result = prepareResult(connection);
                  updateInfoJsonWithPublicKeyCert(connection, result);
                  updateEvent(connection, result);
              }
          } catch (Exception ex) {
              log.error("Failed to register", ex);
              throw new RuntimeException(ex);
          }
          return result;
        });
    }

    private void updateEvent(AgentDBConnection connection, Result result) throws SQLException{
        connection.updateEvent(AgentDBConnection.EventType.REGISTER,
            result.registrationEvent, result.instanceId);
    }

    private void updateInfoJsonWithPublicKeyCert(AgentDBConnection connection, Result result) throws IOException, SQLException {
        int instanceId = result.getInstanceId();
        String base64EncodedCertificate = makeServiceInstancePublicKeyCertificate(registerRequest.getServiceType(), registerRequest.getInfoJson(), instanceId);
        if(base64EncodedCertificate != null){
            JsonObject infoJson = new JsonParser().parse(registerRequest.getInfoJson()).getAsJsonObject();
            infoJson.addProperty("base64EncodedPublicKeyCertificate", base64EncodedCertificate);
            String infoJsonStr = gson.toJson(infoJson);
            result.setInfoJson(infoJsonStr);
            updateInfoJson(instanceId, infoJsonStr, connection);
        }
    }

    private Optional<Result> findExistingInstance(AgentDBConnection connection) throws SQLException {
        ResultSet resultSet = connection.selectRegisteredInstanceByAddress(registerRequest.getServiceType(), registerRequest.getAddress());
        if (resultSet.next()) {
            int instanceId = resultSet.getInt("instanceId");
            int registrationEvent = resultSet.getInt("registrationEvent");
            return Optional.of(new Result(instanceId, registrationEvent));
        }
        return Optional.empty();
    }

    private void register(AgentDBConnection connection) throws SQLException {
        Statement statement = connection.insertRegisteredInstance(sessionId, registerRequest.getServiceType(), registerRequest.getAddress(),
                registerRequest.getInfoJson(), connection.insertAndGetEventId(), getHostName());
        checkState(statement.getUpdateCount() == 1, "Shouldn't have inserted more than one row");
    }

    private void updateInfoJson(int instanceId, String infoJson, AgentDBConnection connection) throws SQLException {
        Statement statement = connection.updateInfoJson(instanceId, infoJson);
        checkState(statement.getUpdateCount() == 1, "Exactly one row should have been updated");
    }

    private Result prepareResult(AgentDBConnection connection) throws SQLException {
        ResultSet resultSet = connection.selectRegisteredInstanceByAddress(registerRequest.getServiceType(), registerRequest.getAddress());
        int instanceId = 0, registrationEvent = 0, rows = 0;
        while (resultSet.next()) {
            instanceId = resultSet.getInt("instanceId");
            registrationEvent = resultSet.getInt("registrationEvent");
            log.info("Registered instances of type: {} instanceId: {}", registerRequest.getServiceType(), instanceId);
            rows++;
        }
        checkState(rows == 1, "Cannot have more than one instance with same listening address");
        return new Result(instanceId, registrationEvent);
    }
    //endregion
}
