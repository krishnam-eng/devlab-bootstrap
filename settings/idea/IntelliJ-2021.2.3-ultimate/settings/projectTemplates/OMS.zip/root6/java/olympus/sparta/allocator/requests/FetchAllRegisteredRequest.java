package olympus.sparta.allocator.requests;

import com.google.common.base.Preconditions;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import in.zeta.commons.concurrency.CompletableFutures;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.session.ErrorResponse;
import olympus.sparta.base.session.Request;
import olympus.sparta.base.session.SessionAgnosticRequest;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.allocator.util.InstanceCache;
import olympus.trace.OlympusSpectra;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletionStage;

import static olympus.sparta.base.session.Request.RequestType.FETCH_ALL_REGISTERED;

public class FetchAllRegisteredRequest extends Request<AllocatorModule> implements SessionAgnosticRequest {
  private static SpectraLogger log = OlympusSpectra.getLogger(FetchAllRegisteredRequest.class);

  public class Response extends olympus.sparta.base.session.Response {
    public final List<CompleteInstanceData> instances = new ArrayList<>();
    public final long snapshotTime;

    Response(List<CompleteInstanceData> input, long snapshotTime) {
      super(FetchAllRegisteredRequest.this.getRequestId());
      instances.addAll(input);
      this.snapshotTime = snapshotTime;
    }

    @Override
    public String toString() {
      return String.format("%s/%s: %s", FETCH_ALL_REGISTERED, requestId, toPrettyJson());
    }

    public String toPrettyJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      obj.addProperty("body", instances.toString());
      return obj.toString();
    }

    @Override
    public String toJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      JsonObject body = new JsonObject();
      JsonArray array = new JsonArray();
      for (CompleteInstanceData data : instances) {
        array.add(data.toJson());
      }
      body.add("serviceInstances", array);
      body.addProperty("snapshotTime", snapshotTime);
      obj.add("body", body);
      return obj.toString();
    }
  }



  private transient InstanceCache cache;

  public FetchAllRegisteredRequest(String requestId, AllocatorModule module) {
    super(FETCH_ALL_REGISTERED);
    this.requestId = requestId;
  }

  @Override
  public FetchAllRegisteredRequest afterDeserialization(AllocatorModule module) {
    this.cache = module.getInstanceCache();
    return this;
  }

  @Override
  public void handleRequest(ClientSession clientSession) {
    Preconditions.checkNotNull(clientSession);
    try {
      clientSession.decorateMarker(log.info(FETCH_ALL_REGISTERED.toString())).log();
      clientSession.send(new Response(cache.fetchInstances().get(), cache.getLastUpdateTime()));
    } catch (Throwable t) {
      clientSession.send(errorResponse(ErrorResponse.ErrorCode.UNKNOWN_ERROR));
    }
  }

  @Override
  public CompletionStage<Response> complete() {
    return CompletableFutures.toCompletionStage(cache.fetchInstances())
        .thenApply(instances -> new Response(instances, cache.getLastUpdateTime()));
  }


  @Override
  public String toString() {
    return String.format("%s/%s", FETCH_ALL_REGISTERED, requestId);
  }
}

