package olympus.sparta.allocator.util;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * A simple wrapper on top of {@link Semaphore} which tries to limit its state to either of 0 available permits or one
 * available permit
 */
public class BinarySemaphore {
    private final Semaphore semaphore = new Semaphore(0);

    public boolean tryAcquire(long timeout, TimeUnit unit) throws InterruptedException {
        boolean acquired = semaphore.tryAcquire(timeout, unit);
        semaphore.drainPermits();
        return acquired;
    }

    public void release() {
        semaphore.drainPermits();
        semaphore.release();
    }
}
