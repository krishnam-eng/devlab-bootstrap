package olympus.sparta.allocator.db.queries;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;

public class CustomerServicesQuery {

  private final DBAdapter<AllocationDBConnection> db;

  public CustomerServicesQuery(DBAdapter<AllocationDBConnection> db) {
    this.db = db;
  }

  public List<String> getCustomerServicesByApp(String app) {
    return db.select(connection -> {
      try {
        ResultSet rs = connection.getCustomerServicesByApp(app);
        List<String> customerServices = new ArrayList<>();
        while (rs.next()) {
          customerServices.add(rs.getString("customer_service"));
        }

        return customerServices;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }
}
