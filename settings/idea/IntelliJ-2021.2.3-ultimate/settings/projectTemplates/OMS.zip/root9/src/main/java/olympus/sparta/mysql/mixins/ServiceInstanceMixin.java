package olympus.sparta.mysql.mixins;

import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.db.model.CompleteInstanceData.InstanceView;
import olympus.sparta.mysql.MySQLAllocationDBConnection;
import olympus.sparta.base.db.mysql.MySQLConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class ServiceInstanceMixin {

  public static final String SIMPLE_INSTANCE_DATA_COLUMNS = "s.instanceId, s.serviceType, s.registrationEvent, " +
      "unRegistrationEvent, allocationEvent, address, " +
      selectUnixTimeInMillis("lastHbInTime", "lastHbInTime") + ", " +
      selectUnixTimeInMillis("CURRENT_TIMESTAMP", "spartaCurrentTime") + ", " +
      "clientAckedVersion, sessionId, spartaId, infoJson  ";

  private static final String FULL_INSTANCE_DATA_COLUMNS = SIMPLE_INSTANCE_DATA_COLUMNS +
      ", allocatedBuckets, " +
      selectUnixTimeInMillis("e1.createdAt", "registrationTime") + ", " +
      selectUnixTimeInMillis("e2.createdAt", "allocationTime");

  public static final String SQL_ALL_SIMPLE_VIEW = "SELECT " + SIMPLE_INSTANCE_DATA_COLUMNS +
      " FROM " + MySQLConstants.TABLE_SERVICE_INSTANCES + " s ";

  private static final String SQL_ALL_FULL_VIEW = " SELECT " + FULL_INSTANCE_DATA_COLUMNS +
      " FROM " + MySQLConstants.TABLE_SERVICE_INSTANCES + " s " +
      "   LEFT JOIN `" + MySQLConstants.TABLE_EVENTS + "` e1 ON e1.eventId = s.registrationEvent " +
      "   LEFT JOIN `" + MySQLConstants.TABLE_EVENTS + "` e2 ON e2.eventId = s.allocationEvent ";

  private static final String SQL_REGISTERED_FULL_VIEW = SQL_ALL_FULL_VIEW +
      "   JOIN " + MySQLConstants.TABLE_REGISTERED_INSTANCES + " ri ON s.instanceId = ri.instanceId ";


  public static final String SQL_REGISTERED_SIMPLE_VIEW = "SELECT " + SIMPLE_INSTANCE_DATA_COLUMNS +
      " FROM " + MySQLConstants.TABLE_SERVICE_INSTANCES + " s JOIN " + MySQLConstants.TABLE_REGISTERED_INSTANCES + " ri " +
      " ON s.instanceId = ri.instanceId ";


  private final Connection mySQLConnection;

  public ServiceInstanceMixin(Connection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }

  public ResultSet selectRegistered(String serviceType, InstanceView view) throws SQLException {
    String sql = (view.equals(InstanceView.FULL) ? SQL_REGISTERED_FULL_VIEW : SQL_REGISTERED_SIMPLE_VIEW)
        + " WHERE serviceType = ?";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setString(1, serviceType);
    return stmt.executeQuery();
  }

  public ResultSet fetchRegisteredInstancesGreaterThan(int leastInstanceId, InstanceView view) throws SQLException {
    String sql = (view.equals(InstanceView.FULL) ? SQL_REGISTERED_FULL_VIEW : SQL_REGISTERED_SIMPLE_VIEW)
        + " WHERE s.unRegistrationEvent IS NULL AND s.instanceId > ?";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setInt(1, leastInstanceId);
    return stmt.executeQuery();
  }

  public ResultSet selectByInstanceId(int instanceId) throws SQLException {
    String sql = SQL_ALL_FULL_VIEW + " WHERE s.instanceId = ?";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setInt(1, instanceId);
    return stmt.executeQuery();
  }

  public ResultSet selectRegisteredInstanceByAddress(String serviceType, String address, InstanceView view)
      throws SQLException {
    String sql = (view.equals(InstanceView.SIMPLE) ? SQL_REGISTERED_SIMPLE_VIEW : SQL_REGISTERED_FULL_VIEW)
        + " WHERE serviceType = ? AND  address = ? ";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setString(1, serviceType);
    stmt.setString(2, address);
    return stmt.executeQuery();
  }

  public static String selectUnixTimeInMillis(String value, String fieldName) {
    return String.format("UNIX_TIMESTAMP(%s) * 1000 as %s", value, fieldName);
  }

  public ResultSet getRegisteredOrUnRegisteredAfter(int eventId) throws SQLException {
    String sql = SQL_ALL_SIMPLE_VIEW +
        " WHERE instanceId IN ( SELECT instanceId FROM " + MySQLConstants.TABLE_EVENTS + " WHERE eventId > ?)";
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql);
    stmt.setInt(1, eventId);
    return stmt.executeQuery();
  }


  public ResultSet selectAllInstances(List<String> sessionIds) throws SQLException {
    StringBuilder sql = new StringBuilder(SQL_ALL_SIMPLE_VIEW + " WHERE sessionId IN ");
    sql.append(sessionIds.stream().map(s -> String.format("'%s'", s))
        .collect(Collectors.toList())
        .toString()
        .replace("[", "(")
        .replace("]", ")")
    );
    PreparedStatement stmt = mySQLConnection.prepareStatement(sql.toString());
    return stmt.executeQuery();
  }

}
