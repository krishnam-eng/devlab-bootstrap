package olympus.sparta.base.pubsub;

import in.zeta.commons.zms.service.ZMSDelegatingWrapper;
import in.zeta.commons.zms.service.ZetaHostMessagingService;
import in.zeta.oms.atropos.client.AtroposPublisherClient;
import olympus.common.JID;
import olympus.pubsub.PubSubMessagingService;
import olympus.pubsub.model.PubSubEvent;
import olympus.sparta.base.PropertyHandler;
import olympus.spartan.ImmutableMessage;
import olympus.spartan.NodeDrainHandler;
import olympus.spartan.RegistrationHandler;
import olympus.spartan.lookup.BucketDrainHandler;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.concurrent.CompletionStage;

/**
 * Has capability to only publish via logs. Publishing to activeMQ or Kafka(directly) is not supported.
 */
public class AtroposPublisher {

    private final PubSubMessagingService pubSubMessagingService;
    private final AtroposPublisherClient publisherClient;
    private final PropertyHandler propertyHandler;

    public AtroposPublisher(JID publisherInstanceJID) {
        this.pubSubMessagingService = new ZMSDelegatingWrapper() {
            @Override
            public ZetaHostMessagingService getDelegated() {
                return null;
            }

            @Override
            public void register(ImmutableMessage.Listener messageListener, NodeDrainHandler nodeDrainHandler, BucketDrainHandler bucketDrainHandler, RegistrationHandler registrationHandler) {
            }

            @Override
            public String getServiceName() {
                return publisherInstanceJID.getServiceName();
            }

            @Override
            public JID getInstanceJID() {
                return publisherInstanceJID;
            }
        };
        this.publisherClient = new AtroposPublisherClient(pubSubMessagingService);
        this.propertyHandler = PropertyHandler.getInstance();
    }

    public CompletionStage<Void> publish(PubSubEvent.Builder pubSubEventBuilder) {
        NameValuePair[] sourceAttrs = new NameValuePair[] {
                new BasicNameValuePair("clusterName", propertyHandler.getStringValue("clusterName", "default"))
        };
        pubSubEventBuilder.sourceAttributes(sourceAttrs);
        return publisherClient.publish(pubSubEventBuilder);
    }
}
