package functional.olympus.sparta.db;

import com.google.common.collect.ImmutableList;
import functional.olympus.sparta.utils.DatabaseUtils;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.CustomerServicesQuery;
import olympus.sparta.base.db.DBAdapter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

@RunWith(JUnit4.class)
public class CustomerServicesQueryTest {

  private DBAdapter<AllocationDBConnection> db;

  @Before
  public void setup() throws SQLException {
    DatabaseUtils utils = new DatabaseUtils();
    db = utils.getProvider().getAllocationDB();
    db.getConnection()
        .prepareStatement("truncate customer_service_by_app")
        .execute();
  }

  @Test
  public void getCustomerServices_noServices() {
    CustomerServicesQuery query = new CustomerServicesQuery(db);
    List<String> services = query.getCustomerServicesByApp("random_app");
    assertEquals(ImmutableList.of(), services);
  }

  @Test
  public void getCustomerServices_oneService() throws SQLException {
    String testApp = "test_app";
    String testCustomerService = "test_customer_service";
    addToCustomerServiceByAppTable(testApp, testCustomerService);

    CustomerServicesQuery query = new CustomerServicesQuery(db);

    List<String> services = query.getCustomerServicesByApp(testApp);
    assertEquals(ImmutableList.of(testCustomerService), services);
  }

  @Test
  public void getCustomerServices_multipleServices() throws SQLException {
    String testApp = "test_app";
    String testCustomerService1 = "test_customer_service_1";
    String testCustomerService2 = "test_customer_service_2";
    addToCustomerServiceByAppTable(testApp, testCustomerService1);
    addToCustomerServiceByAppTable(testApp, testCustomerService2);

    CustomerServicesQuery query = new CustomerServicesQuery(db);

    List<String> services = query.getCustomerServicesByApp(testApp);
    assertEquals(2, services.size());
    assertTrue(services.contains(testCustomerService1));
    assertTrue(services.contains(testCustomerService2));
  }


  private void addToCustomerServiceByAppTable(String app, String customerService) throws SQLException {
    PreparedStatement preparedStatement = db.getConnection()
        .prepareStatement("INSERT INTO customer_service_by_app(app, customer_service) VALUES (?, ?)");
    preparedStatement.setString(1, app);
    preparedStatement.setString(2, customerService);
    preparedStatement.execute();
  }
}
