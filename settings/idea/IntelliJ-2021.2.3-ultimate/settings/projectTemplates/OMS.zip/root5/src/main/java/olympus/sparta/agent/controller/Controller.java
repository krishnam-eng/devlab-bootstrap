package olympus.sparta.agent.controller;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.ControllerConfig;
import olympus.sparta.agent.controller.hearbeat.ClientHBDBUpdater;
import olympus.sparta.agent.controller.hearbeat.ClientHBTracker;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.ClientSessionStore;

public class Controller {
  private final ClientHBDBUpdater clientHBDBUpdater;
  private final DBSanityChecker dbSanityChecker;
  private final ClientHBTracker clientHBTracker;
  private final ClientSessionStore sessionStore;
  private final ControllerConfig config;
  private final AtroposPublisher atroposPublisher;

  private final DBAdapter<AgentDBConnection> db;

  public Controller(DBAdapter<AgentDBConnection> db, ClientSessionStore sessionStore, AtroposPublisher atroposPublisher) {
    this.db = db;
    this.sessionStore = sessionStore;
    this.config = new ControllerConfig();
    this.atroposPublisher = atroposPublisher;
    clientHBDBUpdater = new ClientHBDBUpdater(db, sessionStore);
    dbSanityChecker = new DBSanityChecker(db, config);
    clientHBTracker = new ClientHBTracker(sessionStore);
  }

  public ClientHBDBUpdater getClientHBDBUpdater() {
    return clientHBDBUpdater;
  }

  public DBSanityChecker getDbSanityChecker() {
    return dbSanityChecker;
  }

  public DBAdapter<AgentDBConnection> getDb() {
    return db;
  }

  public ClientHBTracker getClientHBTracker() {
    return clientHBTracker;
  }

  public ClientSessionStore getSessionStore() {
    return sessionStore;
  }

  public ControllerConfig getConfig() {
    return config;
  }

  public AtroposPublisher getAtroposPublisher() {
    return atroposPublisher;
  }
}
