package olympus.sparta.base;

import javax.management.MXBean;
import java.util.List;
import java.util.Map;
import java.util.Set;

@MXBean
public interface PropertiesMXBean {
  List<String> getPropertiesAndValues();

  String getStringValue(String key);

  void setProperty(String key, String value);
}
