package olympus.sparta.transport.jetty.servlets;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.base.session.ClientConnection;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.transport.ClientSessionImpl;
import olympus.trace.OlympusSpectra;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.WebSocketAdapter;

import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;

public class JettyWSClientConnection extends WebSocketAdapter implements ClientConnection {
  private static final SpectraLogger log = OlympusSpectra.getLogger(JettyWSClientConnection.class);

  private final RequestHandler spartaRequestHandler;
  private Session jettySession;
  private boolean isClosing = false;
  private final ClientSessionStore sessionStore;
  private final Controller agentController;
  private final AllocatorModule allocatorModule;

  private ClientSession clientSession;

  public JettyWSClientConnection(RequestHandler spartaRequestHandler,
                                 ClientSessionStore sessionStore,
                                 Controller agentController, AllocatorModule allocatorModule) {
    this.spartaRequestHandler = spartaRequestHandler;
    this.sessionStore = sessionStore;
    this.agentController = agentController;
    this.allocatorModule = allocatorModule;
  }


  @Override
  public void onWebSocketConnect(Session session) {
    super.onWebSocketConnect(session);
    this.jettySession = session;
    session.getPolicy().setMaxTextMessageSize(WebSocketServlet.MAX_SIZE);
    session.getPolicy().setIdleTimeout(TimeUnit.SECONDS.toMillis(15));
    session.getPolicy().setAsyncWriteTimeout(TimeUnit.SECONDS.toMillis(3));
    this.clientSession = new ClientSessionImpl(this, spartaRequestHandler, agentController, allocatorModule);
    sessionStore.add(clientSession);
  }

  @Override
  public void onWebSocketClose(int statusCode, String reason) {
    close(statusCode, true, reason);
    clientSession.disconnect();
    super.onWebSocketClose(statusCode, reason);
  }

  @Override
  public void onWebSocketText(String message) {
    super.onWebSocketText(message);
    clientSession.decorateMarker(log.debug("RECEIVED MESSAGE"))
        .attr("message", message)
        .log();
    clientSession.onClientMessage(message);
  }

  @Override
  public void send(String msg) {
    if (!jettySession.isOpen()) {
      clientSession.decorateMarker(log.debug("Attempting to write on closed remote"))
          .attr("msg", msg)
          .log();
      return;
    }
    try {
      clientSession.decorateMarker(log.debug("SENDING")).attr("msg", msg).log();
      jettySession.getRemote().sendStringByFuture(msg);
    } catch (Exception e) {
      clientSession.decorateMarker(log.warn("Could not write to remote: " + e.getMessage(), e))
          .attr("msg", msg)
          .log();
      if (!isClosing) {
        close(999, true, "error while writing to remote");
      }
    }
  }

  @Override
  public void close() {
    close(0, false, "triggered locally");
  }

  private void close(int statusCode, boolean byRemote, String reason) {
    if (isClosing) return;
    isClosing = true;
    clientSession.decorateMarker(log.warn("Remote Connection Close"))
        .attr("statusCode", statusCode)
        .attr("byRemote", byRemote)
        .attr("reason", reason)
        .log();
    if (jettySession.isOpen()) {
      try {
        jettySession.close();
      } catch (Exception e) {
        //ignore
      }
    }
  }

  @Override
  public void onWebSocketError(Throwable cause)
  {
    clientSession.decorateMarker(log.error("Error: " + cause.getMessage(), cause)).log();
  }

  @Override
  public InetSocketAddress getRemoteSocketAddress() {
    return jettySession.getRemoteAddress();
  }

  @Override
  public ClientSession getClientSession() {
    return clientSession;
  }

  @Override
  public Object getBaseConnection() {
    return jettySession;
  }
}
