package olympus.sparta.allocator;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.allocation.ProxyAwareAllocatorDecorator;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.EventsQuery;
import olympus.sparta.allocator.db.queries.ServiceInstanceQuery;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.db.model.SimpleInstanceData;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.trace.OlympusSpectra;

import java.util.Collection;
import java.util.List;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

import static java.lang.System.currentTimeMillis;

//should be singleton service, loaded eagerly 
public class ServerHBSender {
  public static final long DB_POLL_INTERVAL = 200;
  private static final long BUFFER = 500;
  public static final long HB_SEND_PERIOD = PropertyHandler.getInstance().getLongValue("heartbeat.millis") - BUFFER;
  private static final long INITIAL_DELAY = 0;

  private static final SpectraLogger log = OlympusSpectra.getLogger(ServerHBSender.class);
  private final DBAdapter<AllocationDBConnection> db;
  private final EventsQuery eventsQuery;
  private final ClientSessionStore clientSessionStore;
  private final Timer dbChecker = new Timer("db_change_checker", true);
  private final Timer serveHBTimer = new Timer("server_hb_timer", true);
  private final Object sendLock = new Object();
  private final ProxyAwareAllocatorDecorator proxyAwareAllocatorDecorator;
  private long lastHBSendAt = currentTimeMillis();
  private volatile int lastSentEventId;
  private volatile int maxEventIdInDatabase;
  private volatile int lastSentProxyVersion;

  public ServerHBSender(ClientSessionStore clientSessionStore,
                        DBAdapter<AllocationDBConnection> db,
                        ProxyAwareAllocatorDecorator proxyAwareAllocatorDecorator) {
    this.clientSessionStore = clientSessionStore;
    this.db = db;
    this.proxyAwareAllocatorDecorator = proxyAwareAllocatorDecorator;
    eventsQuery = new EventsQuery(db);
    lastSentEventId = eventsQuery.getMaxEventId();

    dbChecker.schedule(new DBChecker(), INITIAL_DELAY, DB_POLL_INTERVAL);
    serveHBTimer.schedule(new HBSender(), INITIAL_DELAY, HB_SEND_PERIOD - BUFFER);
  }

  private class DBChecker extends TimerTask {
    @Override
    public void run() {
      sendDBEvents();
      sendProxyAllocatorUpdate();
    }
  }

  private void sendDBEvents() {
    try {
      if (!dbHasNewEvents()) return;
      SortedMap<Integer, SimpleInstanceData> sortedEvents = getEvents();
      if (sortedEvents.size() > 0) {
        //There may be no entries corresponding to events table row in serviceInstances table
        synchronized (sendLock) {
          log.INFO("System version changed: {}", sortedEvents);
          send(sortedEvents);
          lastHBSendAt = currentTimeMillis();
          lastSentEventId = maxEventIdInDatabase; // to skip over eventIds without corresponding registrations and unregistrations
        }
      } else {
        log.WARN("Noticed holes in the event id sequence [{} to {}]", lastSentEventId, maxEventIdInDatabase);
        lastSentEventId = maxEventIdInDatabase;
      }
    } catch (Throwable e) {
      log.ERROR("Error in server hb sender: ", e);
    }
  }

  private class HBSender extends TimerTask {
    @Override
    public void run() {
      try {
        synchronized (sendLock) {
          send(lastSentEventId);
          long delay = currentTimeMillis() - lastHBSendAt;
          if (delay > HB_SEND_PERIOD) {
            log.WARN("Could not send server HB in time, delay: {}ms", delay - HB_SEND_PERIOD);
          }
          lastHBSendAt = currentTimeMillis();
        }
      } catch (Throwable e) {
        log.ERROR("Error in server hb sender: ", e);
      }
    }
  }

  private boolean dbHasNewEvents() {
    maxEventIdInDatabase = eventsQuery.getMaxEventId();
    return maxEventIdInDatabase > lastSentEventId;
  }

  private SortedMap<Integer, SimpleInstanceData> getEvents() {
    ServiceInstanceQuery query = new ServiceInstanceQuery(db);
    List<SimpleInstanceData> result = query.getRegisteredOrUnRegisteredAfter(lastSentEventId);
    SortedMap<Integer, SimpleInstanceData> sortedEvents = new TreeMap<>();
    for (SimpleInstanceData instance : result) {
      if (instance.registrationEvent > lastSentEventId)
        sortedEvents.put(instance.registrationEvent, instance);
      if (instance.unRegistrationEvent > lastSentEventId)
        sortedEvents.put(instance.unRegistrationEvent, instance);
    }
    return sortedEvents;
  }

  private void send(int lastSentEventId) {
    send(new Response(lastSentEventId));
  }

  private void send(SortedMap<Integer, SimpleInstanceData> events) {
    for (Integer eventId : events.keySet()) {
      lastSentEventId = eventId;
      SimpleInstanceData data = events.get(eventId);
      log.info("SystemVersionChanged")
          .attr("eventId", eventId)
          .attr("serviceName", data.serviceType)
          .attr("change", data.unRegistrationEvent > 0 ? "UNREGISTERED" : "REGISTERED")
          .log();
      send(new Response(eventId, events.get(eventId)));
    }
  }

  private void send(Response response) {
    Collection<ClientSession> clientSessions = clientSessionStore.getAllClientSessions();
    for (ClientSession clientSession : clientSessions) {
      try {
        clientSession.send(response);
      } catch (Exception e) {
        log.WARN("Could not send server hb to remote instance: {}", clientSession);
      }
    }
  }

  public static class Response extends olympus.sparta.base.session.Response {
    private String serviceType;
    private List<String> subscribedTopics;
    private int systemVersion;

    private Response(int systemVersion, SimpleInstanceData instance) {
      super(null, "hb");
      this.systemVersion = systemVersion;
      if (instance != null) {
        this.serviceType = instance.serviceType;
        this.subscribedTopics = instance.getSubscribedTopics();
      }
    }

    public Response(int systemVersion, CompleteInstanceData instance) {
      super(null, "hb");
      this.systemVersion = systemVersion;
      if (instance != null) {
        this.serviceType = instance.serviceType;
        this.subscribedTopics = instance.getSubscribedTopics();
      }
    }

    public Response(int systemVersion) {
      super(null, "hb");
      this.systemVersion = systemVersion;
    }
  }

  private void sendProxyAllocatorUpdate() {
    try {
      int currentVersion = proxyAwareAllocatorDecorator.getVersion();
      if (currentVersion > lastSentProxyVersion) {
        Collection<ClientSession> clientSessions = clientSessionStore.getAllClientSessions();
        for (ClientSession clientSession : clientSessions) {
          RemoteServiceInstance primaryServiceInstance = clientSession.getPrimaryServiceInstance();
          List<CompleteInstanceData> changedInstances = proxyAwareAllocatorDecorator.getChangedInstances(primaryServiceInstance);

          for (CompleteInstanceData instance: changedInstances) {
            try {
              Response response = new Response(lastSentEventId, instance);
              clientSession.send(response);
            } catch (Exception e) {
              log.WARN("Could not send server hb to remote instance: {}", clientSession);
            }
          }
        }
        lastSentProxyVersion = currentVersion;
      }
    } catch (Throwable e) {
      log.ERROR("Error in server proxy hb sender: ", e);
    }
  }
}
