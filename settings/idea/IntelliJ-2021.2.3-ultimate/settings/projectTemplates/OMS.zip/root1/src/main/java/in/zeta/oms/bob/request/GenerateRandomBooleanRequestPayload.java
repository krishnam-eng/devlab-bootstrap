package in.zeta.oms.bob.request;

public class GenerateRandomBooleanRequestPayload {
}
