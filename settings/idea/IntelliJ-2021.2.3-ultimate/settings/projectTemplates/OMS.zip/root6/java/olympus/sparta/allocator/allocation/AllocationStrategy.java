package olympus.sparta.allocator.allocation;

public interface AllocationStrategy {

    void reAllocate(Allocation currentAllocation);
}
