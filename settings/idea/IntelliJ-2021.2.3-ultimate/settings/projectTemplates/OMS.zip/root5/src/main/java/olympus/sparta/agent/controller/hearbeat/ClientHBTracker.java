package olympus.sparta.agent.controller.hearbeat;

import in.zeta.spectra.capture.SpectraLogger;
import java.util.Optional;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.trace.OlympusSpectra;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import static java.lang.System.currentTimeMillis;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

public class ClientHBTracker {
  private static final SpectraLogger log = OlympusSpectra.getLogger(ClientHBTracker.class);
  public static final long CLIENT_HEART_BEAT_INTERVAL = PropertyHandler.getInstance().getLongValue("heartbeat.millis");
  public static final long CLIENT_HB_TRACKING_INTERVAL = 1000;
  private static final int BUFFER = 100;
  private static final long INITIAL_DELAY = 9000;
  private final ClientSessionStore clientSessionStore;
  private TimerTask currentTask;
  private Timer hbTimer = new Timer("client_hb_tracker", true);
  private long lastHBCheckTime = currentTimeMillis() + INITIAL_DELAY;

  public ClientHBTracker(ClientSessionStore clientSessionStore) {
    this.clientSessionStore = clientSessionStore;
    initTimerTask();
    hbTimer.schedule(currentTask, INITIAL_DELAY, CLIENT_HB_TRACKING_INTERVAL - BUFFER);
  }

  private void initTimerTask() {
    currentTask = new TimerTask() {
      @Override
      public void run() {
        trackDelay();
        getHBFailures().forEach(ClientHBTracker.this::closeSession);
        lastHBCheckTime = currentTimeMillis();
      }
    };
  }

  private void closeSession(ClientSession s) {
    Optional<RemoteServiceInstance> remoteServiceInstanceOptional = s.getInstances().stream().findFirst();
    s.decorateMarker(log.warn("CLIENT_HB_FAILURE"))
        .attr("timeSinceLastHBSeconds",
            MILLISECONDS.toSeconds(currentTimeMillis() - s.getLastHbInTime()))
        .attr("serviceType",  remoteServiceInstanceOptional.isPresent() ? remoteServiceInstanceOptional.get().getServiceType() : "")
        .log();
    try {
      s.close();
    } catch (Exception e) {
      s.decorateMarker(log.error("Failed to close client session", e)).log();
    }
  }

  private List<ClientSession> getHBFailures() {
    return clientSessionStore.getAllClientSessions().stream().filter(s -> {
      long diff = currentTimeMillis() - s.getLastHbInTime();
      return diff > 3 * CLIENT_HEART_BEAT_INTERVAL;
    }).collect(Collectors.toList());
  }

  private void trackDelay() {
    long delay = currentTimeMillis() - lastHBCheckTime;
    if (delay > CLIENT_HB_TRACKING_INTERVAL) {
      log.WARN("Client HB check delayed by : {}ms", delay - CLIENT_HB_TRACKING_INTERVAL);
    }
  }
}
