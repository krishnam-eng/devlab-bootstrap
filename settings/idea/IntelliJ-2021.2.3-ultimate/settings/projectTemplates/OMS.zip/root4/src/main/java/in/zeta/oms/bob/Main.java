package in.zeta.oms.bob;

import static in.zeta.commons.zms.service.ZetaModuleCollection.CONVENTIONS_MODULE;
import static in.zeta.commons.zms.service.ZetaModuleCollection.EAGER_SINGLETON_BINDER_MODULE;
import static in.zeta.commons.zms.service.ZetaModuleCollection.ZMS_MODULE;

import com.google.inject.Guice;
import com.google.inject.Injector;
import in.zeta.commons.zms.service.ZMSBootstrap;
import olympus.transport.network.TCPObjectPipe;

public class Main {
  public static void main(String[] args) {
    TCPObjectPipe.MAX_OBJECT_SIZE = 100 * 1024;

    Injector injector = Guice.createInjector(
        CONVENTIONS_MODULE.getModule(),
        ZMS_MODULE.getModule(),
        EAGER_SINGLETON_BINDER_MODULE.getModule(),
        new BobModule()
    );

    ZMSBootstrap bootstrap = injector.getInstance(ZMSBootstrap.class);
    bootstrap.registerFirstTime();
  }
}
