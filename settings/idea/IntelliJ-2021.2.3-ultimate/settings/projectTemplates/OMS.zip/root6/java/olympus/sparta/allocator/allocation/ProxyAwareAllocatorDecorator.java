package olympus.sparta.allocator.allocation;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.db.queries.GetProxyAllocationsQuery;
import olympus.sparta.allocator.proxy.ProxyAllocatorMXBean;
import olympus.sparta.allocator.proxy.ProxyRemoteInstance;
import olympus.sparta.allocator.requests.GetProxiesResponse;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.session.RemoteServiceInstance;
import olympus.trace.OlympusSpectra;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import static olympus.sparta.allocator.proxy.ProxyToInstanceDataAdapter.getCompleteInstanceData;

public class ProxyAwareAllocatorDecorator implements Allocator, ProxyAllocatorMXBean {
    private static final SpectraLogger logger = OlympusSpectra.getLogger(ProxyAwareAllocatorDecorator.class);

    private static final String ALL_SERVICES = "*";

    private final Allocator delegate;
    private final Timer proxyUpdater = new Timer("proxy_updater", true);
    private final DBAdapter<AllocationDBConnection> db;

    private volatile int version;
    private List<ProxyRemoteInstance> proxyRemoteInstances;
    private List<ProxyRemoteInstance> diffOfProxyInstancesWithLastVersion;

    public ProxyAwareAllocatorDecorator(Allocator delegate, DBAdapter<AllocationDBConnection> db) {
        this.delegate = delegate;
        this.db = db;
        this.diffOfProxyInstancesWithLastVersion = new ArrayList<>();
        this.proxyRemoteInstances = new ArrayList<>();
        this.version = 0;
        int proxyUpdatePeriod = PropertyHandler.getInstance().getIntValue("proxies.updater.period", 60 * 60 * 1000);
        proxyUpdater.schedule(new ProxyUpdater(), 1000 * 60, proxyUpdatePeriod);
        registerInJMX();
        loadLatestProxies();
    }

    @Override
    public ListenableFuture<Allocation> getAllocation(String serviceType, int version) {
        return getAllocation(serviceType, version, null);
    }

    @Override
    public ListenableFuture<Allocation> getAllocation(String serviceType, int version, RemoteServiceInstance primaryServiceInstance) {
        String sourceServiceType = primaryServiceInstance == null ? null : primaryServiceInstance.getServiceType();
        Optional<Allocation> proxyAllocation = getProxyAllocation(sourceServiceType, serviceType, version);

        if (proxyAllocation.isPresent()) {
            logger.info("proxy found").attr("serviceType", serviceType).log();
            return Futures.immediateFuture(proxyAllocation.get());
        }
        return delegate.getAllocation(serviceType, version, primaryServiceInstance);
    }

    @Override
    public ListenableFuture<Allocation> refreshAllocation(String serviceType, int requiredSystemVersion) {
        return delegate.refreshAllocation(serviceType, requiredSystemVersion);
    }

    @Override
    public Set<String> getServicesInterested() {
        return delegate.getServicesInterested();
    }

    @Override
    public void updateAllocation(Allocation allocation) {
        delegate.updateAllocation(allocation);
    }

    @Override
    public void shutdown() {
        delegate.shutdown();
    }

    public int getVersion() {
        return version;
    }

    public List<CompleteInstanceData> getChangedInstances(RemoteServiceInstance primaryServiceInstance) {
        String sourceServiceType = primaryServiceInstance == null ? null : primaryServiceInstance.getServiceType();
        return getChangedInstances(sourceServiceType);
    }

    private synchronized List<CompleteInstanceData> getChangedInstances(String sourceServiceName) {
        List<CompleteInstanceData> changedInstances = diffOfProxyInstancesWithLastVersion
                .stream()
                .filter(p -> p.getSource().equals(ALL_SERVICES) ||
                        (p.getSource().equals(sourceServiceName)))
                .distinct()
                .map(p -> getCompleteInstanceData(p, version))
                .collect(Collectors.toList());
        logger.info("CHANGED_INSTANCES")
                .attr("sourceService", sourceServiceName)
                .attr("proxies", changedInstances)
                .attr("version", version)
                .log();
        return changedInstances;
    }

    private synchronized Optional<Allocation> getProxyAllocation(String source, String destination, int version) {
        Optional<ProxyRemoteInstance> proxyAllocation = findExactMatch(source, destination);
        if (!proxyAllocation.isPresent())
            proxyAllocation = findWildCardMatch(source, destination);

        return proxyAllocation
                .map(proxyRemoteInstance -> {
                    CompleteInstanceData completeInstanceData = getCompleteInstanceData(proxyRemoteInstance, this.version);
                    AllocatedInstance allocatedInstance = new AllocatedInstance(completeInstanceData);
                    List<AllocatedInstance> allocatedInstances = new ArrayList<>();
                    allocatedInstances.add(allocatedInstance);
                    return new Allocation(destination, version, allocatedInstances);
                });
    }

    private Optional<ProxyRemoteInstance> findExactMatch(String source, String destination) {
        return proxyRemoteInstances.stream()
                .filter(p -> (p.getDestination().equals(destination) && p.getSource().equals(source)))
                .findFirst();
    }

    private Optional<ProxyRemoteInstance> findWildCardMatch(String source, String destination) {
        return proxyRemoteInstances.stream()
                .filter(p -> (p.getDestination().equals(destination) && p.getSource().equals(ALL_SERVICES)))
                .findFirst();
    }

    @Override
    public void reloadProxyAllocations() {
        logger.info("RELOAD_PROXY_ALLOCATIONS_TRIGGER")
                .log();
        loadLatestProxies();
    }

    private class ProxyUpdater extends TimerTask {
        @Override
        public void run() {
            try {
                loadLatestProxies();
            } catch (Exception e) {
                logger.warn("Failed to update proxy", e).log();
            }
        }
    }

    private void loadLatestProxies() {
        GetProxiesResponse response = getLatestProxyRemoteInstances();
        List<ProxyRemoteInstance> latest = response.getProxyRemoteInstances();
        List<ProxyRemoteInstance> diff = getDiff(proxyRemoteInstances, latest);
        if (!diff.isEmpty()) {
            logger.info("Diff in proxy found")
                    .attr("newProxiesListSize", latest.size())
                    .attr("diffSize", diff.size())
                    .attr("oldProxiesListSize", proxyRemoteInstances.size())
                    .log();
            update(latest, diff, response.getVersion());
        }
    }

    /**
     * If an instance is deleted from before, added in after it will be a part of the returned list.
     * The check is done based on {@link ProxyRemoteInstance\#equals(Object)}
     *
     * @param before
     * @param after
     * @return Diff of services for which proxy has changed
     */
    private List<ProxyRemoteInstance> getDiff(List<ProxyRemoteInstance> before, List<ProxyRemoteInstance> after) {
        List<ProxyRemoteInstance> diff = before.stream()
                .filter(proxy -> !after.contains(proxy))
                .distinct()
                .collect(Collectors.toList());
        diff.addAll(after.stream()
                .filter(proxy -> !before.contains(proxy))
                .filter(proxy -> !diff.contains(proxy))
                .distinct()
                .collect(Collectors.toList()));
        return diff;
    }

    private synchronized void update(List<ProxyRemoteInstance> latest, List<ProxyRemoteInstance> diff, int version) {
        diffOfProxyInstancesWithLastVersion = diff;
        proxyRemoteInstances = latest;
        this.version = version;
    }

    private GetProxiesResponse getLatestProxyRemoteInstances() {
        GetProxyAllocationsQuery query = new GetProxyAllocationsQuery(db);
        GetProxiesResponse latestAllocation = query.getLatestProxyAllocations();
        logger.info("LATEST_PROXIES")
                .attr("version", latestAllocation)
                .attr("size", latestAllocation.getProxyRemoteInstances().size());
        return latestAllocation;
    }

    private void registerInJMX() {
        String name = "olympus.sparta.allocator.proxy:ProxyAllocatorMXBean=ProxyReload";
        try {
            MBeanServer server = ManagementFactory.getPlatformMBeanServer();
            ObjectName mxBeanName = new ObjectName(name);
            server.registerMBean(this, mxBeanName);
        } catch (MalformedObjectNameException | MBeanRegistrationException
                | NotCompliantMBeanException ex) {
            logger.error("Failed to register JMX bean", ex).log();
            throw new RuntimeException(ex);
        }  catch (InstanceAlreadyExistsException ex) {
        //Ignore
        }
    }
}
