package olympus.sparta.allocator.proxy;

import java.util.Objects;

public class ProxyRemoteInstance {
    private String source;
    private String destination;
    private String proxy;
    private String token;
    private String infoJson;

    public ProxyRemoteInstance(String source, String destination, String proxy, String token, String infoJson) {
        this.source = source;
        this.destination = destination;
        this.proxy = proxy;
        this.token = token;
        this.infoJson = infoJson;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getProxy() {
        return proxy;
    }

    public String getToken() {
        return token;
    }

    public String getInfoJson() {
        return infoJson == null ? "{}" : infoJson;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProxyRemoteInstance that = (ProxyRemoteInstance) o;
        return source.equals(that.source) &&
                destination.equals(that.destination) &&
                proxy.equals(that.proxy) &&
                Objects.equals(token, that.token) &&
                Objects.equals(infoJson, that.infoJson);
    }

    @Override
    public int hashCode() {
        return Objects.hash(source, destination, proxy, token, infoJson);
    }

    @Override
    public String toString() {
        return "ProxyRemoteInstance{" +
                "source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", proxy='" + proxy + '\'' +
                ", token='" + token + '\'' +
                ", infoJson='" + infoJson + '\'' +
                '}';
    }
}
