package olympus.sparta.transport.jetty.servlets;

import com.google.gson.JsonObject;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.allocator.allocation.Allocator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.CompletionStage;

/***
 * Provides a simple GET API to fetch allocation of a service
 */
public class FetchAllocationServlet extends BaseServlet {
  private final Allocator allocator;

  public FetchAllocationServlet(Allocator allocator) {
    this.allocator = allocator;
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    String serviceName = req.getParameter("serviceName");
    int expectedAllocationVersion = Integer.parseInt(req.getParameter("version"));

    CompletionStage<JsonObject> result = toCompletionStage(
        allocator.getAllocation(serviceName, expectedAllocationVersion)
    ).thenApply(Allocation::toBucketRangesJson);

    complete(req, resp, result);
  }
}
