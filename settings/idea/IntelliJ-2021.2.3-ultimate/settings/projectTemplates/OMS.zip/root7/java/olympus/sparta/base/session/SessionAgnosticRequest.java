package olympus.sparta.base.session;

import olympus.sparta.base.session.Response;

import java.util.concurrent.CompletionStage;

/***
 * Introduced to support certain requests on session-less transports like HTTP.
 * Requests that are not bound to any particular Spartan session are expected to implement
 * this method.
 */
public interface SessionAgnosticRequest {
  CompletionStage<? extends Response> complete();
}
