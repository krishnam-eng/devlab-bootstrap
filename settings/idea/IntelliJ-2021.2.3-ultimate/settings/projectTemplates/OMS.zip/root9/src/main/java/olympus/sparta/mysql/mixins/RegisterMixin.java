package olympus.sparta.mysql.mixins;

import olympus.sparta.base.db.mysql.MySQLConstants;
import olympus.sparta.mysql.MySQLAgentDBConnection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterMixin {
  private final MySQLAgentDBConnection mySQLConnection;

  public RegisterMixin(MySQLAgentDBConnection mySQLConnection) {
    this.mySQLConnection = mySQLConnection;
  }

  public PreparedStatement updateInfoJson(int instanceId, String infoJson) throws SQLException {
    String SQL_UPDATE_INFO_JSON = "UPDATE " + MySQLConstants.TABLE_SERVICE_INSTANCES + " SET " +
        " infoJson = ?" +
        " WHERE instanceId=?";
    PreparedStatement statement = mySQLConnection.prepareStatement(SQL_UPDATE_INFO_JSON);
    statement.setString(1, infoJson);
    statement.setLong(2, instanceId);
    statement.execute();
    return statement;
  }

  public Statement insertRegisteredInstance(String sessionId, String serviceType, String address, String infoJson,
                                            int registrationEvent, String spartaId) throws SQLException {
    String sql = "" +
        "INSERT INTO " + MySQLConstants.TABLE_SERVICE_INSTANCES +
        " (sessionId, serviceType, address, infoJson, registrationEvent, spartaId, lastHbInTime) " +
        "VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
    PreparedStatement insertStmt = mySQLConnection.prepareStatement(sql);
    insertStmt.setString(1, sessionId);
    insertStmt.setString(2, serviceType);
    insertStmt.setString(3, address);
    insertStmt.setString(4, infoJson);
    insertStmt.setInt(5, registrationEvent);
    insertStmt.setString(6, spartaId);
    insertStmt.execute();
    return insertStmt;
  }
}
