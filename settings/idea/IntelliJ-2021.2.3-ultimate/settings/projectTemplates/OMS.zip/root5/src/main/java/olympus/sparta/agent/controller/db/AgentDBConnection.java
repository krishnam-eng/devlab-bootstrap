package olympus.sparta.agent.controller.db;

import olympus.metrics.MetricLogger;
import olympus.metrics.TimeKeeper;
import olympus.sparta.agent.controller.db.model.SessionHBData;
import olympus.sparta.base.db.ConnectionDelegate;

import java.sql.*;
import java.util.List;
import java.util.concurrent.Callable;

public abstract class AgentDBConnection extends ConnectionDelegate {
  protected static final String METRIC_PREFIX = "sparta.db.agent.statement.";

  public enum EventType {
    REGISTER,
    UNREGISTER
  }

  private static final MetricLogger metricLogger = MetricLogger.getLogger(AgentDBConnection.class);

  public AgentDBConnection(Connection conn) {
    super(conn);
  }

  public abstract int[] batchUpdateHB(String spartaId, List<SessionHBData> sessions) throws SQLException;

  public abstract ResultSet selectStaleHBInstances(long staleHbInterval) throws SQLException;

  public abstract Statement insertIntoEvents() throws SQLException;

  public abstract PreparedStatement updateInfoJson(int instanceId, String infoJson) throws SQLException;

  public abstract Statement updateEvent(EventType eventType, int eventId, int instanceId) throws SQLException;

  public abstract Statement insertRegisteredInstance(String sessionId, String serviceType, String address, String infoJson,
                                                     int registrationEvent, String spartaId) throws SQLException;

  public abstract int unRegisterIfStale(int instanceId, long staleHbInterval)
      throws SQLException;

  public abstract int insertAndGetEventId() throws SQLException;

  public abstract int unRegisterIfLocal(int instanceId)
      throws SQLException;

  public abstract int updateSpartaIdAndClientHb(long hbInTime, int clientVersion, String sessionId)
      throws SQLException;

  public abstract ResultSet selectAllInstances(List<String> sessionIds) throws SQLException;

  public abstract ResultSet selectRegisteredInstanceByAddress(String serviceType, String address)
      throws SQLException;

  public abstract ResultSet selectByInstanceId(int instanceId) throws SQLException;

  public abstract ResultSet selectMaxEventId() throws SQLException;

  protected <T> T time(String metric, Callable<T> callable) throws SQLException {
    try (TimeKeeper.Event timer = metricLogger.timeKeeper(METRIC_PREFIX + metric).start()) {
      return callable.call();
    } catch (SQLException sqlException) {
      metricLogger.counter(METRIC_PREFIX + metric + ".failure").increment();
      throw sqlException;
    } catch (Exception e) {
      metricLogger.counter(METRIC_PREFIX + metric + ".failure").increment();
      throw new RuntimeException(e);
    }
  }

}
