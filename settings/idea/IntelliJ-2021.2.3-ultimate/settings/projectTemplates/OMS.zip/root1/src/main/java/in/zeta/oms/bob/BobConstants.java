package in.zeta.oms.bob;

import in.zeta.commons.util.NodeIDEncoder;
import olympus.common.JID;
import olympus.common.OlympusService;
import org.apache.commons.lang3.RandomStringUtils;

public interface BobConstants {
  String SERVICE_NAME = "bob";
  OlympusService SERVICE = OlympusService.get(SERVICE_NAME);
  String APP_DOMAIN = "zeta.in";

  static JID getRoutingJID(String receiver) {
    String nodeID = NodeIDEncoder.encode(receiver);
    return new JID(APP_DOMAIN, SERVICE_NAME, nodeID);
  }

  static JID getRandomRoutingJID() {
    return new JID(APP_DOMAIN, SERVICE.getPrimaryName(), getRandomNodeId());
  }

  static String getRandomNodeId() {
    return RandomStringUtils.random(5);
  }
}
