package olympus.sparta.mysql;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.model.SessionHBData;
import olympus.sparta.base.db.Host;
import olympus.sparta.base.db.model.CompleteInstanceData.InstanceView;
import olympus.sparta.mysql.mixins.*;

import java.sql.*;
import java.util.List;

public class MySQLAgentDBConnection extends AgentDBConnection {

  private final HeartBeatMixin heartBeatMixin;
  private final UnRegisterMixin unRegisterMixin;
  private final EventMixin eventMixin;
  private final ServiceInstanceMixin serviceInstanceMixin;
  private final RegisterMixin registerMixin;

  public MySQLAgentDBConnection(Connection conn) {
    super(conn);
    heartBeatMixin = new HeartBeatMixin(this);
    unRegisterMixin = new UnRegisterMixin(this);
    eventMixin = new EventMixin(this);
    serviceInstanceMixin = new ServiceInstanceMixin(this);
    registerMixin = new RegisterMixin(this);
  }

  @Override
  public int[] batchUpdateHB(String spartaId, List<SessionHBData> sessions) throws SQLException {
    return time("update_hb", () ->
            heartBeatMixin.batchUpdateHB(spartaId, sessions));
  }

  @Override
  public ResultSet selectStaleHBInstances(long staleHbInterval) throws SQLException {
    return time("get_stale_instances", () ->
            heartBeatMixin.selectStaleHBInstances(staleHbInterval));
  }


  @Override
  public PreparedStatement updateInfoJson(int instanceId, String infoJson) throws SQLException {
    return time("update_info_json", () ->
            registerMixin.updateInfoJson(instanceId, infoJson));
  }

  @Override
  public Statement insertRegisteredInstance(String sessionId, String serviceType, String address, String infoJson,
                                            int registrationEvent, String spartaId) throws SQLException {
    return time("insert_registered", () ->
            registerMixin.insertRegisteredInstance(sessionId, serviceType, address, infoJson, registrationEvent, spartaId));
  }

  @Override
  public int unRegisterIfStale(int instanceId, long staleHbInterval)
      throws SQLException {
    return time("unregister_stale", () ->
            unRegisterMixin.unRegisterIfStale(instanceId, staleHbInterval));
  }

  @Override
  public Statement insertIntoEvents() throws SQLException {
    return time("insert_event", () ->
            eventMixin.insertIntoEvents());
  }


  @Override
  public Statement updateEvent(AgentDBConnection.EventType eventType, int eventId, int instanceId) throws SQLException {
    return time("update_event", () ->
            eventMixin.updateEvent(eventType, eventId, instanceId));
  }


  @Override
  public int insertAndGetEventId() throws SQLException {
    return time("insert_get_event_id", () ->
            eventMixin.insertAndGetEventId());
  }

  @Override
  public ResultSet selectMaxEventId() throws SQLException {
    return time("get_max_event_id", () ->
            eventMixin.selectMaxEventId());
  }


  @Override
  public int unRegisterIfLocal(int instanceId)
      throws SQLException {
    return time("unregister", () ->
            unRegisterMixin.unRegisterIfLocal(instanceId));
  }

  @Override
  public int updateSpartaIdAndClientHb(long hbInTime, int clientVersion, String sessionId)
      throws SQLException {
    return time("update_sparta_id_client_hb", () ->
            heartBeatMixin.updateSpartaIdAndClientHb(Host.getHostName(), hbInTime, clientVersion, sessionId));
  }

  @Override
  public ResultSet selectAllInstances(List<String> sessionIds) throws SQLException {
    return time("select_all_instances", () ->
            serviceInstanceMixin.selectAllInstances(sessionIds));
  }

  @Override
  public ResultSet selectRegisteredInstanceByAddress(String serviceType, String address)
      throws SQLException {
    return time("select_registered_by_address", () ->
            serviceInstanceMixin.selectRegisteredInstanceByAddress(serviceType, address, InstanceView.SIMPLE));
  }


  @Override
  public ResultSet selectByInstanceId(int instanceId) throws SQLException {
    return time("select_by_instance_id", () ->
            serviceInstanceMixin.selectByInstanceId(instanceId));
  }

}
