package olympus.sparta.base.session;

import olympus.sparta.base.session.Response;

public class ErrorResponse extends Response {
    public static enum ErrorCode {
        UNKNOWN_SERVICE(404, "Cannot find any service instances for the requested service type"),
        INSTANCE_NOT_REGISTERED(406, "This instance is not registered."),
        INVALID_SESSION_ID(407, "Invalid sessionId"),
        RECLAIMED_BY_OTHER(408, "Other client is reconnecting with same sessionId, so closing this one"),
        SESSION_WITH_UNREGISTERED_INSTANCES(410, "One or more instances are un-registered while client is disconnected"),
        SESSION_NOT_ESTABLISHED(409, "Session not established"),
        UNKNOWN_REQUEST_TYPE(450, "Unknown Request Type"),

        UNKNOWN_ERROR(500, "Unknown error"),
        DB_REGISTRATION_ERROR(501, "Failed to register due to DB error"),
        DB_UN_REGISTRATION_ERROR(502, "Failed to un-register due to DB error"),
        DB_HB_UPDATE_ERROR(503, "Failed to update heart beat due to DB error"),
        DB_RE_CONNECT_ERROR(504, "Failed to re-connect due to DB error"),
        UN_REGISTRATION_ERROR(505, "Failed to un-register"),
        OUT_OF_SYNC_ERROR(506, "Session is out-of sync with DB");

        public final int code;
        public final String desc;

        private ErrorCode(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }
    }

    int errorCode;
    String description;

    public ErrorResponse(ErrorCode err, Request request) {
        super(request.getRequestId(), "error");
        errorCode = err.code;
        description = err.desc;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "ErrorResponse {" +
            "errorCode=" + errorCode +
            ", description='" + description + '\'' +
            '}';
    }
}
