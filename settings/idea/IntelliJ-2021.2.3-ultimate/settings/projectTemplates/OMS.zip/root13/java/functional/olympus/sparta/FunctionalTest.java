package functional.olympus.sparta;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import functional.olympus.sparta.utils.DatabaseUtils;
import functional.olympus.sparta.utils.Modules;
import olympus.common.executors.KeyedExecutor;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.requests.RequestFactory;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.transport.oldws.OldWSTransport;
import olympus.trace.ConsoleFriendlySerializer;
import olympus.trace.OlympusSpectra;
import org.java_websocket.handshake.ClientHandshake;
import org.junit.After;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class FunctionalTest {
  protected String connectionString = "jdbc:mysql://localhost:3306/sparta_db?user=root&connectionTimeout=2000&socketTimeout=15000";
  protected DatabaseUtils db = new DatabaseUtils(connectionString);
  protected TestRequestFactory testRequestFactory = new TestRequestFactory();
  protected OldWSTransport transport;
  protected WebSocketStub socket;
  protected ClientHandshake clientHandshake = mock(ClientHandshake.class);

  private final int port = 5551;
  private final ClientSessionStore clientSessionStore;

  public static JsonElement json(String str) {
    JsonParser p = new JsonParser();
    return p.parse(str);
  }

  public FunctionalTest() {
    OlympusSpectra.getInstance().setSerializer(new ConsoleFriendlySerializer());
    db.truncateDB();
    PropertyHandler.getInstance().setProperty("heartbeat.millis", "1050");
    Modules modules = new Modules();
    KeyedExecutor executor = new KeyedExecutor(10, "executor");
    RequestFactory factory = new RequestFactory(modules.getAgentController(), modules.getAllocatorModule());
    RequestHandler requestHandler = new RequestHandler(executor, factory);
    clientSessionStore = modules.getClientSessionStore();
    transport = new OldWSTransport(port, requestHandler, clientSessionStore, modules.getAgentController(), modules.getAllocatorModule());
    socket = new WebSocketStub(transport);
    transport.onOpen(socket, mock(ClientHandshake.class));
  }

  protected void sendRequest(String request) {
    transport.onMessage(socket, request);
    try {
      Thread.sleep(1000l);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  protected void assertClientReceived(String response) {
    socket.assertSent(response);
  }

  protected void assertClientReceived(JsonElement response) {
    socket.assertSent(response);
  }

  protected <T> T getResponse(int requestId, Class<T> responseClass) {
    JsonObject response = socket.getResponse(requestId);
    return new Gson().fromJson(response.getAsJsonObject("body"), responseClass);
  }

  protected void assertSocketClosed() {
    assertTrue(socket.isClosed());
  }

  @After
  public void tearDown() throws Exception {
    for (ClientSession clientSession : clientSessionStore.getAllClientSessions()) {
      clientSession.close();
    }
  }
}
