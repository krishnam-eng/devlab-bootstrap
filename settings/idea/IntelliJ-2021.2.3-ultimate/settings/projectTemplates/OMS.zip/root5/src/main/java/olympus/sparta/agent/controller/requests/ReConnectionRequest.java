package olympus.sparta.agent.controller.requests;

import com.google.common.base.Preconditions;
import com.google.gson.JsonObject;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.agent.controller.db.queries.EventsQuery;
import olympus.sparta.agent.controller.db.queries.ReConnectionQuery;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.SimpleInstanceData;
import olympus.sparta.base.session.*;
import olympus.trace.OlympusSpectra;

import java.util.List;
import java.util.Optional;

import static java.lang.System.currentTimeMillis;
import static olympus.sparta.base.session.ErrorResponse.ErrorCode.DB_RE_CONNECT_ERROR;
import static olympus.sparta.base.session.ErrorResponse.ErrorCode.SESSION_WITH_UNREGISTERED_INSTANCES;
import static olympus.sparta.base.session.Request.RequestType.RE_CONNECTION;

public class ReConnectionRequest extends Request<Controller> {
  private static final SpectraLogger log = OlympusSpectra.getLogger(ReConnectionRequest.class);
  private String sessionId;

  private transient DBAdapter<AgentDBConnection> db;
  private transient ClientSessionStore sessionStore;
  private transient ReConnectionQuery reConnectionQuery;
  private transient EventsQuery eventsQuery;

  public class Response extends olympus.sparta.base.session.Response {
    private final int systemVersion;

    Response(Integer systemVersion) {
      super(ReConnectionRequest.this.getRequestId());
      this.systemVersion = systemVersion;
    }

    @Override
    public String toString() {
      return String.format("%s/%s: %s", RE_CONNECTION, requestId, toJson());
    }

    @Override
    public String toJson() {
      JsonObject obj = new JsonObject();
      obj.addProperty("requestId", requestId);
      obj.addProperty("type", type);
      JsonObject body = new JsonObject();
      body.addProperty("systemVersion", systemVersion);
      body.addProperty("sessionId", sessionId);
      obj.add("body", body);
      return obj.toString();
    }
  }

  public ReConnectionRequest(String sessionId) {
    super(RE_CONNECTION);
    this.sessionId = sessionId;
  }

  @Override
  public ReConnectionRequest afterDeserialization(Controller controller) {
    db = controller.getDb();
    sessionStore = controller.getSessionStore();
    reConnectionQuery = new ReConnectionQuery(db, sessionId);
    eventsQuery = new EventsQuery(db);
    return this;
  }

  @Override
  public void handleRequest(ClientSession clientSession) {
    Preconditions.checkNotNull(db);
    Preconditions.checkNotNull(sessionStore);
    Preconditions.checkNotNull(reConnectionQuery);
    Preconditions.checkNotNull(eventsQuery);
    clientSession.decorateMarker(log.info(RE_CONNECTION.toString())).log();
    if (isInvalid()) {
      clientSession.send(errorResponse(ErrorResponse.ErrorCode.INVALID_SESSION_ID));
      clientSession.close();
      return;
    }
    closeOldSessionIfThereIsAny(clientSession);
    reconnect(clientSession);
  }

  private void closeOldSessionIfThereIsAny(ClientSession reclaimingSession) {
    final Optional<ClientSession> optional = sessionStore.getClientSession(sessionId);
    optional.ifPresent(session -> {
      session.send(errorResponse(ErrorResponse.ErrorCode.RECLAIMED_BY_OTHER));
      session.setReclaimedByOther(reclaimingSession);
    });
  }

  private void reconnect(ClientSession clientSession) {
    try {
      claimSession(clientSession);
      updateSessionFromDB(clientSession);
      // TODO: SPARTA_2 Remove this check; Allow reclaim of sessions with unregistered instances
      if (clientSession.hasUnRegisteredInstances()) {
        clientSession.decorateMarker(log.warn(RE_CONNECTION.toString() + " REJECTED"))
            .attr("reason", "there are un-registered instances in the session")
            .log();
        clientSession.send(new UnRegisteredInstancesError(this));
        clientSession.close();
        return;
      }
      sendSuccess(clientSession);
      clientSession.setLastHbInTime(currentTimeMillis());
      clientSession.onRegistered();
    } catch (Throwable t) {
      log.warn(RE_CONNECTION.toString() + " FAILED", t).log();
      clientSession.decorateMarker(log.warn(RE_CONNECTION.toString() + " FAILED", t))
          .attr("reason", "there un-registered instances in the session")
          .log();
      clientSession.send(new DBError(this));
      clientSession.close();
    }
  }

  private int claimSession(ClientSession clientSession) {
    return reConnectionQuery.updateSpartaIdAndClientHb(currentTimeMillis(), clientSession.getClientAckedVersion());
  }

  private void updateSessionFromDB(ClientSession clientSession) {
    List<SimpleInstanceData> instanceList;
    instanceList = reConnectionQuery.getAllInstancesForCurrentSession();
    for (SimpleInstanceData instance : instanceList) {
      addInstance(clientSession, instance);
    }
  }

  private RemoteServiceInstance addInstance(ClientSession clientSession, SimpleInstanceData instanceInfo) {
    RemoteServiceInstance remoteServiceInstance = clientSession.createOrGet(instanceInfo.getInstanceId());
    remoteServiceInstance.setRegistered(instanceInfo.getInstanceId(),
        instanceInfo.getServiceType(),
        instanceInfo.getAddress(),
        instanceInfo.getRegistrationEvent(),
        instanceInfo.getInfoJson());
    if (isUnRegistered(instanceInfo)) {
      remoteServiceInstance.setUnRegistered(instanceInfo.getUnRegistrationEvent());
      log.WARN("Instance un-registered before reclaimed by client: {}@{}/{}",
          instanceInfo.getInstanceId(), instanceInfo.getServiceType(), sessionId);
    }
    return remoteServiceInstance;
  }

  private boolean isUnRegistered(SimpleInstanceData result) {
    return result.getUnRegistrationEvent() != 0;
  }

  private void sendSuccess(ClientSession clientSession) {
    clientSession.setSessionId(sessionId);
    clientSession.decorateMarker(log.info(RE_CONNECTION.toString() + " SUCCESS")).log();
    clientSession.send(new Response(eventsQuery.getMaxEventId()));
  }

  private boolean isInvalid() {
    return sessionId == null || "".equals(sessionId) || !sessionId.matches("[a-zA-Z0-9-]+");
  }

  public String getSessionId() {
    return sessionId;
  }

  @Override
  public String toString() {
    return String.format("%s/%s/%s", RE_CONNECTION, sessionId, requestId);
  }

  public static class UnRegisteredInstancesError extends ErrorResponse {
    public UnRegisteredInstancesError(ReConnectionRequest request) {
      super(SESSION_WITH_UNREGISTERED_INSTANCES, request);
    }
  }

  public static class DBError extends ErrorResponse {
    String requestedSessionId;

    public DBError(ReConnectionRequest request) {
      super(DB_RE_CONNECT_ERROR, request);
      requestedSessionId = request.sessionId;
    }
  }
}
