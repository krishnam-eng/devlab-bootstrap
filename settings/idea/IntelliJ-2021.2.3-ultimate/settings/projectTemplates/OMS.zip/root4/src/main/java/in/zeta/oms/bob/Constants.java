package in.zeta.oms.bob;

public class Constants {

}
