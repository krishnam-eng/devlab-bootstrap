package olympus.sparta.base;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.trace.OlympusSpectra;

import javax.management.*;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public class PropertyHandler implements PropertiesMXBean {
  private static final SpectraLogger logger = OlympusSpectra.getLogger(PropertyHandler.class);
  private static PropertyHandler instance = null;
  private final Properties properties = new Properties();

  public static synchronized PropertyHandler getInstance() {
    if (instance == null) {
      instance = new PropertyHandler();
    }
    return instance;
  }

  private PropertyHandler() {
    registerInJMX();
  }


  public void load(InputStream inputStream) throws Exception {
    properties.load(inputStream);
  }

  public void loadFromEnv() {
    Properties p = new Properties();
    System.getenv().forEach(p::setProperty);
    properties.putAll(p);
  }

  public void loadFromSystem() {
    properties.putAll(System.getProperties());
  }

  @Override
  public String getStringValue(String key) {
    return properties.getProperty(key);
  }

  public long getLongValue(String key) {
    return Long.parseLong(getStringValue(key));
  }

  public int getIntValue(String key) {
    return Integer.parseInt(getStringValue(key));
  }

  public int getIntValue(String key, int defaultValue) {
    return Integer.parseInt(getStringValue(key, String.valueOf(defaultValue)));
  }

  @Override
  public List<String> getPropertiesAndValues() {
    return getSortedNames().stream()
        .map(k -> String.format("%s=%s", k, properties.getProperty(k))).collect(Collectors.toList());
  }

  private List<String> getSortedNames() {
    List<String> list = new ArrayList<>(properties.stringPropertyNames());
    list.sort(String::compareTo);
    return list;
  }

  @Override
  public void setProperty(String key, String value) {
    logger.info("PropertyHandler.setProperty").attr("key", key).attr("value", value).log();
    properties.setProperty(key, value);
  }

  public String getStringValue(String key, String defaultValue) {
    return properties.getProperty(key, defaultValue);
  }

  private void registerInJMX() {
    String name = "olympus.sparta.base:PropertyHandler=LiveProperties";
    try {
      MBeanServer server = ManagementFactory.getPlatformMBeanServer();
      ObjectName mxBeanName = new ObjectName(name);
      server.registerMBean(this, mxBeanName);
    } catch (MalformedObjectNameException | InstanceAlreadyExistsException | MBeanRegistrationException
        | NotCompliantMBeanException ex) {
      throw new RuntimeException(ex);
    }
  }

  public boolean getBooleanValue(String key) {
    return Boolean.parseBoolean(getStringValue(key));
  }
}
