package olympus.sparta.base.db.model;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class CompleteInstanceDataTest {

    @Test
    public void getRangeStrings() {
        List<String> rangeStrings = CompleteInstanceData.getRangeStrings(Arrays.asList(0, 1, 2, 3, 4, 10, 11, 12, 13, 97, 98, 99, 102, 104));
        Assert.assertEquals(Arrays.asList("[0-4]", "[10-13]", "[97-99]", "[102]", "[104]"), rangeStrings);
    }
}