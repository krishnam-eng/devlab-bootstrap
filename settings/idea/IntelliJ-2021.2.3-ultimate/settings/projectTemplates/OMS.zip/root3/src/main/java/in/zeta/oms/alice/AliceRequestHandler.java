package in.zeta.oms.alice;

import static in.zeta.commons.concurrency.CompletableFutures.unwrapCompletionStateException;

import in.zeta.commons.zms.api.ZetaPayload;
import in.zeta.commons.zms.service.ZetaHostMessagingService;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.message.types.Payload;
import olympus.message.types.Request;
import olympus.trace.OlympusSpectra;

public abstract class AliceRequestHandler {
  private static final SpectraLogger logger = OlympusSpectra.getLogger(AliceRequestHandler.class);
  private final ZetaHostMessagingService zhms;

  public AliceRequestHandler(ZetaHostMessagingService emitterMessagingService) {
    this.zhms = emitterMessagingService;
  }

  public <T extends ZetaPayload> void on(T payload, Request<T> request) {
    logger.info(payload.getClass().getSimpleName() + ".request")
        .attr("from", request.from())
        .fill(payload)
        .log();
  }

  protected Void sendResponse(Request<? extends Payload> request, Payload payload) {
    logger.info(request.payload().getClass().getSimpleName() + ".response")
        .fill("response", payload.getClass().getSimpleName())
        .log();
    zhms.sendResponse(request, payload);
    return null;
  }

  protected Void sendError(Request<? extends Payload> request,
      Throwable throwable) {
    throwable = unwrapCompletionStateException(throwable);
    logger.error(request.payload().getClass().getSimpleName() + ".error", throwable)
        .attr("oid", request.oid())
        .attr("message", throwable.getMessage())
        .log();
    zhms.sendError(request, throwable);
    return null;
  }
}
