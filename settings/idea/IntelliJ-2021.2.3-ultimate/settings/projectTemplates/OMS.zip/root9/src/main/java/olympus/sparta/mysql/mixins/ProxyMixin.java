package olympus.sparta.mysql.mixins;

import olympus.sparta.base.db.mysql.MySQLConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProxyMixin {
    private final Connection mySQLConnection;

    public ProxyMixin(Connection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    public ResultSet getLatestVersion() throws SQLException {
        String SQL_SELECT_LATEST_VERSION = "SELECT proxies, version from " + MySQLConstants.TABLE_PROXY_ALLOCATIONS + " order by version desc limit 1;";
        PreparedStatement statement = mySQLConnection.prepareStatement(SQL_SELECT_LATEST_VERSION);
        return statement.executeQuery();
    }

    public int insertProxy(String proxies) throws SQLException {
        String sql = "" +
                "INSERT INTO " + MySQLConstants.TABLE_PROXY_ALLOCATIONS +
                " (proxies) " +
                "VALUES (?)";
        PreparedStatement statement = mySQLConnection.prepareStatement(sql);
        statement.setString(1, proxies);
        return statement.executeUpdate();
    }
}
