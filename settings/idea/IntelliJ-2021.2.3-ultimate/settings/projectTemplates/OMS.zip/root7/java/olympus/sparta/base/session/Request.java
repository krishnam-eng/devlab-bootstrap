package olympus.sparta.base.session;

import com.google.gson.Gson;

public abstract class Request<T> {

  public enum RequestType {
    REGISTER,
    UN_REGISTER,
    LOOKUP,
    HEARTBEAT,
    RE_CONNECTION,
    FETCH_ALL_REGISTERED,
    FETCH_SERVICES,
    FETCH_CUSTOMER_SERVICES_BY_APP,
    PING,
    UNKNOWN
  }

  public static final Gson gson = new Gson();

  public final RequestType type;
  protected String requestId;

  protected Request(RequestType type) {
    this.type = type;
  }

  public String getRequestId() {
    return requestId;
  }

  public ErrorResponse errorResponse(ErrorResponse.ErrorCode code) {
    return new ErrorResponse(code, this);
  }

  abstract public Request<T> afterDeserialization(T o);

  abstract public void handleRequest(ClientSession clientSession);

  @Override
  public String toString() {
    return "Request{" +
        "type=" + type +
        ", requestId='" + requestId + '\'' +
        '}';
  }
}
