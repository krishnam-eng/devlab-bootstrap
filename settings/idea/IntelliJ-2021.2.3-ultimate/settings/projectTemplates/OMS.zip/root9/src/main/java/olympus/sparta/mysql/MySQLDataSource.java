package olympus.sparta.mysql;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.base.PropertyHandler;
import olympus.trace.OlympusSpectra;
import org.apache.commons.dbcp2.*;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Supplier;

public class MySQLDataSource implements Supplier<Connection>, MySQLDataSourceMXBean {
  private static final SpectraLogger logger = OlympusSpectra.getLogger(MySQLDataSource.class);

  public static final long MAX_WAIT = PropertyHandler.getInstance().getLongValue("mysql.max.wait.millis");
  public static final int MAX_ACTIVE = PropertyHandler.getInstance().getIntValue("mysql.max.active");
  public static final int PRE_LOADED_CONNECTION_COUNT = PropertyHandler.getInstance().getIntValue("mysql.pre.loaded.connection.count");
  private static final String VALIDATION_QUERY = PropertyHandler.getInstance().getStringValue("mysql.validation.query");
  private static final boolean TEST_ON_BORROW = PropertyHandler.getInstance().getBooleanValue("mysql.test.on.borrow");

  private String connectionString;
  private BasicDataSource dataSource;

  /***
   *
   *
   * @param connectionString
   * @throws Exception
   */
  public MySQLDataSource(String connectionString) throws Exception {
    setupDataSource(connectionString);

    registerOnJMX();
  }

  private void registerOnJMX() {
    try {
      ObjectName objectName = new ObjectName(MySQLDataSource.class.getPackage().getName(),"name",
              MySQLDataSource.class.getSimpleName());
      MBeanServer platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
      platformMBeanServer.registerMBean(this, objectName);
    } catch (MalformedObjectNameException | InstanceAlreadyExistsException | MBeanRegistrationException |
            NotCompliantMBeanException e) {
      logger.warn("Failed registering DataSource on JMX", e).log();
    }
  }

  @Override
  public Connection get() {
    try {
      return dataSource.getConnection();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  synchronized protected void setupDataSource(String connectURI) {
    this.connectionString = connectURI;

    BasicDataSource ds = new BasicDataSource();
    ds.setDriverClassName("com.mysql.jdbc.Driver");
    ds.setUrl(connectURI);
    ds.setValidationQuery(VALIDATION_QUERY);
    ds.setMaxTotal(MAX_ACTIVE);
    ds.setMaxWaitMillis(MAX_WAIT);
    ds.setMinIdle(PRE_LOADED_CONNECTION_COUNT);
    ds.setTestOnBorrow(TEST_ON_BORROW);
    String name = "org.apache.commons.DBCP:Datasource=SpartaDB";
    ds.setJmxName(name);

    this.dataSource = ds;
  }

  @Override
  public String getConnectionString() {
    return connectionString;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setConnectionString(String newConnectionString) {
    try {
      logger.info("Closing older dataSource for connectionString update").log();
      dataSource.close();
    } catch (SQLException e) {
      logger.warn("Datasource not closed cleanly", e).log();
    }
    setupDataSource(newConnectionString);
    logger.info("Updated connectionString").log();
    // Not printing connectionString to prevent DB credentials from leaking via logs
  }
}
