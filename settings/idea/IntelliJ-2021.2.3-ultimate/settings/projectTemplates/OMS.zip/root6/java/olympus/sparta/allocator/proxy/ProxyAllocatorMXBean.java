package olympus.sparta.allocator.proxy;

import javax.management.MXBean;

@MXBean
public interface ProxyAllocatorMXBean {
    void reloadProxyAllocations();
}
