package olympus.sparta.allocator.db.queries;

import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EventsQuery {
  private final DBAdapter<AllocationDBConnection> db;

  public EventsQuery(DBAdapter<AllocationDBConnection> db) {
    this.db = db;
  }

  public Integer getMaxEventId() {
    return db.select(connection -> {
      try {
        ResultSet rs = connection.selectMaxEventId();
        rs.next();
        return rs.getInt("eventId");
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }
}


