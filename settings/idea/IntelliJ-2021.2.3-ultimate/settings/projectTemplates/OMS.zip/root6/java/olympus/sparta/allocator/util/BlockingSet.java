package olympus.sparta.allocator.util;

import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

// Based on https://stackoverflow.com/a/34265218/833133
public class BlockingSet<T> {
    private final BlockingQueue<T> blockingQueue = new LinkedBlockingQueue<>();
    private final Set<T> set = ConcurrentHashMap.newKeySet();

    // Will contend with other threads also calling put, but never contend with take
    public synchronized void put(T t) throws InterruptedException {
        if (set.add(t)) {
            blockingQueue.put(t);
        }
    }

    /**
     * Takes the element from the queue.
     * Note that no synchronization with {@link \#put(Object)} is here, as we don't care about the element staying in the set longer needed.
     * @return taken element
     * @throws InterruptedException
     */
    public T take() throws InterruptedException {
        T t = blockingQueue.take();
        set.remove(t);
        return t;
    }
}
