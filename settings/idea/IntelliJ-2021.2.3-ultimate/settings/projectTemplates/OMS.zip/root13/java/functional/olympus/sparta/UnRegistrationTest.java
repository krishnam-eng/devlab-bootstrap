package functional.olympus.sparta;

import olympus.sparta.agent.controller.requests.RegisterRequest;
import org.junit.Test;

public class UnRegistrationTest extends FunctionalTest {

    @Test
    public void testUnRegister() {
        sendRequest(testRequestFactory.createReConnectRequest(1,"pqr"));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        RegisterRequest.Response response = getResponse(2, RegisterRequest.Response.class);
        sendRequest(testRequestFactory.createUnRegisterRequest(3, response.getJid()));
        assertClientReceived("{\"requestId\":\"3\",\"type\":\"response\",\"body\":{\"instanceId\":1,\"systemVersion\":2}}");
    }
}
