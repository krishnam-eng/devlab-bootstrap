package olympus.sparta.base.db;

import com.mysql.cj.jdbc.exceptions.MySQLTransactionRollbackException;
import olympus.sparta.base.PropertyHandler;
import org.junit.Test;
import org.mockito.Mockito;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class DBAdapterTest {

    @Test
    public void detectDeadlock() {
        MySQLTransactionRollbackException txnException = new MySQLTransactionRollbackException("Deadlock found when trying to get lock; try restarting transaction");

        BatchUpdateException batchUpdateException = new BatchUpdateException(txnException.getMessage(), txnException.getSQLState(),
                txnException.getErrorCode(), new int[]{});
        batchUpdateException.initCause(txnException);

        DBAdapter.DBException dbException = new DBAdapter.DBException(new RuntimeException(batchUpdateException));
        assertTrue("Should detect deadlock", DBAdapter.isDeadlock(dbException));
    }

    @Test
    public void detectNonDeadlock() {
        DBAdapter.DBException dbException = new DBAdapter.DBException(new RuntimeException("Could not un-register instance: 157673"));
        assertFalse("Should detect non-deadlock", DBAdapter.isDeadlock(dbException));
    }

    @Test
    public void executeTransactionSuccess() {
        AtomicInteger counter = new AtomicInteger(0);

        DBAdapter<Connection> dbAdapter = new DBAdapter<>(() -> Mockito.mock(Connection.class));

        dbAdapter.executeTransaction(input -> {
            counter.incrementAndGet();
            return null;
        });

        assertEquals(1, counter.get());
    }

    @Test
    public void executeTransactionDeadlockFailure() {
        PropertyHandler.getInstance().setProperty("sparta.db.deadlock.retryCount", "3");

        AtomicInteger counter = new AtomicInteger(0);
        boolean exceptionThrown = false;

        DBAdapter<Connection> dbAdapter = new DBAdapter<>(() -> Mockito.mock(Connection.class));

        try {
            dbAdapter.executeTransaction(input -> {
                counter.incrementAndGet();
                throw new RuntimeException("Deadlock");
            });
        } catch (Exception e) {
            assertTrue(e.getCause().getMessage().contains("Deadlock"));
            exceptionThrown = true;
        }

        assertTrue(exceptionThrown);
        assertEquals(3, counter.get());
    }

    @Test
    public void executeTransactionNonDeadlockFailure() throws Exception {
        AtomicInteger counter = new AtomicInteger(0);
        boolean exceptionThrown = false;

        DBAdapter<Connection> dbAdapter = new DBAdapter<>(() -> Mockito.mock(Connection.class));

        try {
            dbAdapter.executeTransaction(input -> {
                counter.incrementAndGet();
                throw new RuntimeException("Not D_eadlock");
            });
        } catch (Exception e) {
            assertFalse(e.getCause().getMessage().contains("Deadlock"));
            exceptionThrown = true;
        }

        assertTrue(exceptionThrown);
        assertEquals(1, counter.get());
    }
}
