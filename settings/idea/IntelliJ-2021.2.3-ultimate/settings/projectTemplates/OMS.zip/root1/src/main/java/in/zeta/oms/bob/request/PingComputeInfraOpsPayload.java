package in.zeta.oms.bob.request;


import com.google.common.base.Strings;
import in.zeta.commons.zms.api.ZetaPayload;
import in.zeta.commons.zms.api.ZetaRequestBuilder;
import in.zeta.oms.bob.BobConstants;
import lombok.Builder;
import lombok.Getter;
import olympus.message.types.Request;

import static com.google.common.base.Preconditions.checkArgument;

@Getter
@Builder(builderClassName = "Builder")
public class PingComputeInfraOpsPayload extends ZetaPayload {
  private String nodeID;

  public PingComputeInfraOpsPayload(PingComputeInfraOpsPayload.Builder builder) {
    this.nodeID = builder.nodeID;
  }

  public static class Builder extends ZetaRequestBuilder<PingComputeInfraOpsPayload, Builder> {
    public Builder() {

    }

    @Override
    public Request<PingComputeInfraOpsPayload> build() {
      PingComputeInfraOpsPayload request = new PingComputeInfraOpsPayload(this);
      payload(request);
      validate(request);
      to(BobConstants.getRoutingJID(nodeID));
      return super.build();
    }

    private void validate(PingComputeInfraOpsPayload request) {
      checkArgument(!Strings.isNullOrEmpty(request.getNodeID()),
          "nodeID should be present & valid");
    }
  }
}
