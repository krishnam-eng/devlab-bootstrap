package olympus.sparta.base.db.model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class HBUpdateInfo {
  public final int instanceId;
  public final long lastHbInTime;
  public final int clientAckedVersion;
  public final String spartaId;
  public final String sessionId;

  public HBUpdateInfo(ResultSet rs) throws SQLException {
    instanceId = rs.getInt("instanceId");
    lastHbInTime = rs.getLong("lastHbInTime");
    clientAckedVersion = rs.getInt("clientAckedVersion");
    spartaId = rs.getString("spartaId");
    sessionId = rs.getString("sessionId");
  }
}
