package in.zeta.oms.bob;

import com.google.gson.Gson;
import in.zeta.commons.annotations.TimeLogger;
import in.zeta.commons.gson.ZetaGsonBuilder;
import in.zeta.commons.interceptors.TimeLoggerInterceptor;
import in.zeta.commons.settings.SettingsModule;

import static com.google.inject.matcher.Matchers.annotatedWith;
import static com.google.inject.matcher.Matchers.any;

public class BobModule extends SettingsModule {

  @Override
  protected void configure() {
    super.configure();
    bind(Gson.class).toInstance(new ZetaGsonBuilder().build());
    bindInterceptor(any(), annotatedWith(TimeLogger.class), new TimeLoggerInterceptor());
  }
}
