package olympus.sparta.bootstrap;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.common.JID;
import olympus.sparta.DBProvider;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.base.PropertyHandler;
import olympus.sparta.base.pubsub.AtroposPublisher;
import olympus.sparta.base.session.ClientSessionStore;
import olympus.sparta.mysql.MySQLDBProvider;
import olympus.sparta.requests.RequestFactory;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.transport.jetty.JettyTransport;
import olympus.sparta.transport.oldws.OldWSTransport;
import olympus.trace.OlympusSpectra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static olympus.sparta.base.db.Host.getHostName;
import static olympus.trace.ConfigurableSerializer.CONSOLE_FRIENDLY_SERIALIZER;
import static to.talk.common.Utils.isWellKnownEnvironment;

public class Bootstrap {
  private static final Logger log = LoggerFactory.getLogger(Bootstrap.class);
  private static final SpectraLogger logger = OlympusSpectra.getLogger(Bootstrap.class);
  private static final String GIT_COMMIT_ID = "git.commit";

  public static void main(String[] args) {
    PropertyHandler propertyHandler = prepareProperties();
    prepareLogging();
    printBanner();
    Bootstrap sparta = new Bootstrap();
    String envName = propertyHandler.getStringValue("environmentName", "local");
    String connectionString = getDBConnectionString(propertyHandler, envName);
    sparta.start(connectionString);
  }

  private static void prepareLogging() {
    // Use console friendly serialization during development.
    if (!isWellKnownEnvironment()) {
      log.warn("Using Console friendly serialization in non-standard environments");
      OlympusSpectra.getInstance().setSerializer(CONSOLE_FRIENDLY_SERIALIZER);
    }
  }

  private static void printBanner() {
    logger.warn("Starting Sparta")
            .attr("commitId", PropertyHandler.getInstance().getStringValue(GIT_COMMIT_ID))
            .attr("version", PropertyHandler.getInstance().getStringValue("sparta.version")).log();
  }

  public void start(String connectionString) {
    try {
      ClientSessionStore clientSessionStore = new ClientSessionStore();
      DBProvider dbProvider = new MySQLDBProvider(connectionString);
      AtroposPublisher atroposPublisher = new AtroposPublisher(new JID("services.olympus", "sparta", getHostName()));
      Controller agentController = new Controller(dbProvider.getAgentDB(), clientSessionStore, atroposPublisher);

      AllocatorModule allocatorModule = new AllocatorModule(dbProvider.getAllocationDB(), clientSessionStore, atroposPublisher);
      RequestHandler requestHandler = new RequestHandler(new RequestFactory(agentController, allocatorModule));

      startOldWebsocketServer(requestHandler, clientSessionStore, agentController, allocatorModule);
      startJetty(requestHandler, clientSessionStore, agentController, allocatorModule, dbProvider);
      logger.warn("Started Sparta successfully")
              .attr("version", PropertyHandler.getInstance().getStringValue("sparta.version")).log();
    } catch (Exception e) {
      logger.error("Couldn't start Sparta successfully", e).log();
      System.exit(1);
    }
  }

  private void startOldWebsocketServer(RequestHandler requestHandler,
                                       ClientSessionStore clientSessionStore,
                                       Controller agentController,
                                       AllocatorModule allocatorModule) {
    int wsPort = PropertyHandler.getInstance().getIntValue("sparta.ws.port");
    OldWSTransport transport = new OldWSTransport(wsPort, requestHandler, clientSessionStore, agentController, allocatorModule);
    transport.start();
  }

  private void startJetty(RequestHandler requestHandler,
                          ClientSessionStore clientSessionStore,
                          Controller agentController,
                          AllocatorModule allocatorModule,
                          DBProvider dbProvider) throws Exception {
    int httpPort = PropertyHandler.getInstance().getIntValue("sparta.jetty.port");
    JettyTransport jettyTransport = new JettyTransport(requestHandler, clientSessionStore, agentController, allocatorModule, dbProvider);
    jettyTransport.start(httpPort);
  }


  private static String getDBConnectionString(PropertyHandler propertyHandler, String envName) {
    String connectionString;
    if (envName.equals("test")) {
      connectionString = System.getProperty("mysql-connection-string");
    } else {
      connectionString = propertyHandler.getStringValue(envName + ".mysql.connection.string");
    }
    return connectionString;
  }

  private static PropertyHandler prepareProperties() {
    try {
      PropertyHandler p = PropertyHandler.getInstance();
      p.load(Bootstrap.class.getResourceAsStream("/sparta.properties"));
      p.loadFromEnv();
      p.loadFromSystem();
      return p;
    } catch (Throwable e) {
      log.error("CRITICAL: Could not load the properties file. Shutting down.", e);
      System.out.println("CRITICAL: Could not load the properties file. Shutting down.");
      e.printStackTrace();
      System.exit(1);
    }
    return null;
  }
}
