package olympus.sparta.allocator.db.queries;

import com.google.gson.Gson;
import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.allocator.proxy.ProxyRemoteInstance;
import olympus.sparta.base.db.DBAdapter;
import olympus.trace.OlympusSpectra;

import java.util.List;

public class PutProxyAllocationQuery {

    private static final SpectraLogger log = OlympusSpectra.getLogger(PutProxyAllocationQuery.class);
    private final DBAdapter<AllocationDBConnection> db;
    private final Gson gson = new Gson();

    public PutProxyAllocationQuery(DBAdapter<AllocationDBConnection> db) {
        this.db = db;
    }

    public boolean putProxyAllocations(List<ProxyRemoteInstance> proxyRemoteInstances) {
        return db.executeTransaction(connection -> {
            try {
                connection.insertProxies(gson.toJson(proxyRemoteInstances));
            } catch (Exception e) {
                log.error("Failed to put proxies", e).log();
                throw new RuntimeException(e);
            }
            return true;
        });
    }
}
