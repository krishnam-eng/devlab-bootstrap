package olympus.sparta.allocator.db.queries;

import com.google.common.base.Preconditions;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;
import olympus.sparta.base.db.model.CompleteInstanceData;
import olympus.sparta.base.db.model.SimpleInstanceData;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

public class ServiceInstanceQuery {

  private DBAdapter<AllocationDBConnection> db;

  public ServiceInstanceQuery(DBAdapter<AllocationDBConnection> db) {
    this.db = db;
  }


  public List<CompleteInstanceData> getRegistered(final String serviceType) {
    return db.select(connection -> {
      try {
        checkNotNull(connection);
        ResultSet rs = connection.selectRegistered(serviceType);
        List<CompleteInstanceData> list = new ArrayList<>();
        while (rs.next()) {
          list.add(new CompleteInstanceData(rs));
        }
        return list;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }

  /**
   * Gives the latest of unregistered and registered events that effected this service.
   *
   * @param serviceType
   * @return
   */
  public int getLatestVersion(final String serviceType) {
    return db.select(connection -> {
      try {
        checkNotNull(connection);
        ResultSet rs = connection.selectLatestVersion(serviceType);
        rs.next();
        return rs.getInt(1);
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }

  public List<SimpleInstanceData> getRegisteredOrUnRegisteredAfter(final int event) {
    return db.select(connection -> {
      try {
        checkNotNull(connection);
        List<SimpleInstanceData> instances = new ArrayList<>();
        ResultSet rs = connection.getRegisteredOrUnRegisteredAfter(event);
        while (rs.next()) {
          instances.add(new SimpleInstanceData(rs));
        }
        return instances;
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }


  public List<CompleteInstanceData> fetchRegisteredInstancesGreaterThan(final int instanceId) {
    return db.select(connection -> {
      try {
        Preconditions.checkNotNull(connection);
        ResultSet rs = connection.fetchRegisteredInstancesGreaterThan(instanceId, CompleteInstanceData.InstanceView.FULL);
        List<CompleteInstanceData> instances = new ArrayList<CompleteInstanceData>();
        while (rs.next()) {
          instances.add(new CompleteInstanceData(rs));
        }
        return instances;

      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }

}
