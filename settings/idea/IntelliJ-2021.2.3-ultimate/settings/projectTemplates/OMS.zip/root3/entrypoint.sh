\#!/usr/bin/env bash

cp #[[\$]]#JAVA_HOME/jre/lib/security/cacerts #[[\$]]#HOME/cacerts.bak

cp #[[\$]]#JAVA_HOME/jre/lib/security/cacerts #[[\$]]#HOME/cacerts
wget -O #[[\$]]#HOME/rds-ca-2019-root.pem https://s3.amazonaws.com/rds-downloads/rds-ca-2019-root.pem
openssl x509 -in #[[\$]]#HOME/rds-ca-2019-root.pem -out #[[\$]]#HOME/rds-ca-2019-root.der -outform der
chmod 644 #[[\$]]#HOME/cacerts
keytool -keystore #[[\$]]#HOME/cacerts -storepass changeit -noprompt -trustcacerts -importcert -alias aws-rds-ssl -file #[[\$]]#HOME/rds-ca-2019-root.der

cp #[[\$]]#HOME/cacerts /cacerts/cacerts

JAR_PATH="/data/releases/#[[\$]]#app/#[[\$]]#app.jar"

JAVA_OPTS=(-XX:+HeapDumpOnOutOfMemoryError
          -XX:HeapDumpPath=/logs/#[[\$]]#app
          -XX:+UseParNewGC
          -XX:+UseConcMarkSweepGC
          -XX:+PrintGCDetails
          -XX:+PrintGCDateStamps
          -XX:+PrintTenuringDistribution
          -Xloggc:/logs/#[[\$]]#app/gc.log
          -XX:+UseGCLogFileRotation
          -XX:NumberOfGCLogFiles=5
          -XX:GCLogFileSize=16M
          -Xms#[[\$]]#javaXms
          -Xmx#[[\$]]#javaXmx
          -XX:MinHeapFreeRatio=10
          -XX:MaxHeapFreeRatio=30
          -DenvironmentName=#[[\$]]#environmentName
          -Duser.name=#[[\$]]#app
          -Djavax.net.ssl.trustStore=/cacerts/cacerts
          -Djavax.net.ssl.trustStorePassword=changeit
          )

JMX_OPTS=(-Dcom.sun.management.jmxremote.port=63106
          -Dcom.sun.management.jmxremote
          -Dcom.sun.management.jmxremote.local.only=false
          -Dcom.sun.management.jmxremote.authenticate=false
          -Dcom.sun.management.jmxremote.ssl=false
          )

java #[[\$]]#{JAVA_OPTS[@]} #[[\$]]#{JMX_OPTS[@]} -jar #[[\$]]#JAR_PATH
