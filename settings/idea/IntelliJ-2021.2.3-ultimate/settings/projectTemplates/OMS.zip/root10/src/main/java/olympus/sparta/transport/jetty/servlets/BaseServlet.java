package olympus.sparta.transport.jetty.servlets;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.gson.Gson;
import in.zeta.commons.concurrency.CompletableFutures;
import olympus.sparta.base.session.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.AsyncContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletionStage;

import static javax.servlet.http.HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
import static javax.servlet.http.HttpServletResponse.SC_OK;

public abstract class BaseServlet extends HttpServlet {
  private static final Logger log = LoggerFactory.getLogger(BaseServlet.class);
  protected static final Gson gson = new Gson();

  protected void setTextResponse(AsyncContext context, String text, int statusCode) {
    String remote = context.getRequest().getRemoteAddr() + ":" + context.getRequest().getRemotePort();
    HttpServletResponse response = (HttpServletResponse) context.getResponse();
    response.setStatus(statusCode);
    response.setContentType("text/plain");
    write(context, response, text, remote);
  }

  protected void setJsonResponse(AsyncContext context, Object toSerialize, int statusCode) {
    String remote = context.getRequest().getRemoteAddr() + ":" + context.getRequest().getRemotePort();
    HttpServletResponse response = (HttpServletResponse) context.getResponse();
    response.setStatus(statusCode);
    response.setContentType("application/json");
    String jsonStr = toSerialize instanceof Response ? ((Response) toSerialize).toJson() : gson.toJson(toSerialize);
    write(context, response, jsonStr, remote);
  }

  private void write(AsyncContext context, HttpServletResponse response, String str, String remote) {
    try {
      log.debug("WRITING DATA to {}: {}", remote, str);
      ServletOutputStream outputStream = response.getOutputStream();
      outputStream.setWriteListener(new AsyncWriter(context, str, remote));
    } catch (IOException e) {
      log.warn("Failed to write response to " + remote, e);
    }
  }

  protected <T> CompletionStage<T> toCompletionStage(ListenableFuture<T> f) {
    return CompletableFutures.toCompletionStage(f);
  }

  protected <T> void complete(HttpServletRequest req, HttpServletResponse resp, CompletionStage<T> stage) {
    complete(req.startAsync(req, resp), stage);
  }

  protected <T> void completeExceptionally(HttpServletRequest req, HttpServletResponse resp, Throwable e) {
    complete(req.startAsync(req, resp), CompletableFutures.exceptionallyCompletedFuture(e));
  }

  protected <T> void complete(AsyncContext asyncContext, CompletionStage<T> stage) {
    stage.thenAccept(value -> {
      try {
        setJsonResponse(asyncContext, value, SC_OK);
      } catch (Exception e) {
        log.warn("Couldn't write response to http client", e);
      }
    }).exceptionally(t -> {
      try {
        setTextResponse(asyncContext, t.getMessage(), SC_INTERNAL_SERVER_ERROR);
      } catch (Exception e) {
        log.warn("Couldn't write response to http client", e);
      }
      return null;
    });
  }

  private static class AsyncWriter implements WriteListener {
    private final AsyncContext context;
    private final String str;
    private final String remote;

    public AsyncWriter(AsyncContext context, String str, String remote) {
      this.context = context;
      this.str = str;
      this.remote = remote;
    }

    @Override
    public void onWritePossible() throws IOException {
      ServletOutputStream outputStream = context.getResponse().getOutputStream();
      outputStream.print(str);
      outputStream.close();
      context.complete();
      log.debug("Successfully written to and CLOSED CONTEXT for {}", remote);
    }

    @Override
    public void onError(Throwable t) {
      context.complete();
      log.error("Error writing HTTP response, closed context for " + remote, t);
    }
  }
}
