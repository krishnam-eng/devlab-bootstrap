package olympus.sparta.transport.oldws;

import in.zeta.spectra.capture.SpectraLogger;
import olympus.sparta.agent.controller.Controller;
import olympus.sparta.allocator.AllocatorModule;
import olympus.sparta.requests.RequestHandler;
import olympus.sparta.base.session.ClientConnection;
import olympus.sparta.base.session.ClientSession;
import olympus.sparta.transport.ClientSessionImpl;
import olympus.trace.OlympusSpectra;
import org.java_websocket.WebSocket;

import java.net.InetSocketAddress;

public class OldWSClientConnection implements ClientConnection {
  private static final SpectraLogger log = OlympusSpectra.getLogger(OldWSClientConnection.class);

  private final ClientSessionImpl clientSession;
  private final WebSocket webSocket;
  private InetSocketAddress remoteAddress;
  private boolean isClosed = false;

  public OldWSClientConnection(WebSocket webSocket, RequestHandler requestHandler, Controller controller, AllocatorModule allocatorModule) {
    this.webSocket = webSocket;
    clientSession = new ClientSessionImpl(this, requestHandler, controller, allocatorModule);
    remoteAddress = webSocket.getRemoteSocketAddress();
  }

  @Override
  public void send(String msg) {
    webSocket.send(msg);
  }

  @Override
  public void close() {
    if(isClosed) return;
    isClosed = true;
    webSocket.close();
  }

  @Override
  public InetSocketAddress getRemoteSocketAddress() {
    return remoteAddress == null ? (remoteAddress = webSocket.getRemoteSocketAddress()) : remoteAddress;
  }

  @Override
  public ClientSession getClientSession() {
    return clientSession;
  }

  @Override
  public Object getBaseConnection() {
    return webSocket;
  }

}
