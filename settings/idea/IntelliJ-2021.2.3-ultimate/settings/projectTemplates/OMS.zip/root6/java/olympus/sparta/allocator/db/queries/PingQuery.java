package olympus.sparta.allocator.db.queries;

import com.google.common.base.Function;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

public class PingQuery {
    private static final Logger log = LoggerFactory.getLogger(PingQuery.class);

    public static class Result {
        public final String response;

        Result() {
            this.response = "pong";
        }
    }

    private final DBAdapter<AllocationDBConnection> db;

    public PingQuery(DBAdapter<AllocationDBConnection> db) {
        this.db = db;
    }

    public Result ping() {
        return db.select(new Function<AllocationDBConnection, Result>() {
            @Override
            public Result apply(AllocationDBConnection connection) {
                try {
                    connection.ping();
                    return new Result();
                } catch (SQLException e) {
                    log.error("Error while tying to access db: ", e);
                    throw new RuntimeException(e);
                }
            }
        });
    }
}

