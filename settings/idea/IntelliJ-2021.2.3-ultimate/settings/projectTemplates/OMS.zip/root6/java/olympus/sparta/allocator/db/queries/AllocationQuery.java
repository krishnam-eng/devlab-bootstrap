package olympus.sparta.allocator.db.queries;

import com.google.common.base.Function;
import olympus.sparta.allocator.allocation.Allocation;
import olympus.sparta.allocator.db.AllocationDBConnection;
import olympus.sparta.base.db.DBAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AllocationQuery {
    private static final Logger log = LoggerFactory.getLogger(AllocationQuery.class);
    private final DBAdapter<AllocationDBConnection> db;

    public AllocationQuery(DBAdapter<AllocationDBConnection> db) {
        this.db = db;
    }

    public boolean persist(final Allocation allocation) {
        return db.executeTransaction(connection -> {
            try {
                int[] updateCounts = connection.batchUpdateAllocation(allocation);
                for (int updateCount : updateCounts) {
                    if (updateCount != 1) {
                        log.warn("Allocation is probably updated by another instance: {}", allocation);

                        // Rollback transaction
                        throw new IllegalStateException("Allocation persistance failed. Allocation is probably updated by another instance:" + allocation);
                    }
                }
                connection.updateAllocationHistory(allocation.getSystemVersion());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return true;
        });
    }

    public int getLatestAllocation() {
        return db.select(connection -> {
            try {
                ResultSet rs = connection.getLatestAllocation();
                if(rs.next()) {
                    return rs.getInt("allocationEvent");
                }
                return -1;
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

}
