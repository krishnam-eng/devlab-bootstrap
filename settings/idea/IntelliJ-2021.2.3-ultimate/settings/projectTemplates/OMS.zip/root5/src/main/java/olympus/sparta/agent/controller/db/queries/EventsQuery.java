package olympus.sparta.agent.controller.db.queries;

import olympus.sparta.agent.controller.db.AgentDBConnection;
import olympus.sparta.base.db.DBAdapter;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EventsQuery {
  private final DBAdapter<AgentDBConnection> db;

  public EventsQuery(DBAdapter<AgentDBConnection> db) {
    this.db = db;
  }

  public Integer getMaxEventId() {
    return db.select(connection -> {
      try {
        ResultSet rs = connection.selectMaxEventId();
        rs.next();
        return rs.getInt("eventId");
      } catch (SQLException e) {
        throw new RuntimeException(e);
      }
    });
  }


}
