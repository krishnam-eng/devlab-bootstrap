package olympus.sparta.base.db.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SimpleInstanceData {
  public final String sessionId;
  public final int instanceId;
  public final String serviceType;
  public final int registrationEvent;
  public final int unRegistrationEvent;
  public final String infoJson;
  public final long lastHbInTime;
  public final String address;
  private ArrayList<String> subscribedTopics;

  public SimpleInstanceData(ResultSet rs) throws SQLException {
    this.sessionId = rs.getString("sessionId");
    this.instanceId = rs.getInt("instanceId");
    this.serviceType = rs.getString("serviceType");
    this.registrationEvent = rs.getInt("registrationEvent");
    this.unRegistrationEvent = rs.getInt("unRegistrationEvent");
    this.address = rs.getString("address");
    this.infoJson = rs.getString("infoJson");
    this.lastHbInTime = rs.getLong("lastHbInTime");
    subscribedTopics = Util.parseSubscribedTopics(infoJson);
  }


  public List<String> getSubscribedTopics() {
    return subscribedTopics;
  }

  public String getSessionId() {
    return sessionId;
  }

  public int getInstanceId() {
    return instanceId;
  }

  public String getServiceType() {
    return serviceType;
  }

  public int getRegistrationEvent() {
    return registrationEvent;
  }

  public int getUnRegistrationEvent() {
    return unRegistrationEvent;
  }

  public String getInfoJson() {
    return infoJson;
  }

  public long getLastHbInTime() {
    return lastHbInTime;
  }

  public String getAddress() {
    return address;
  }
}
