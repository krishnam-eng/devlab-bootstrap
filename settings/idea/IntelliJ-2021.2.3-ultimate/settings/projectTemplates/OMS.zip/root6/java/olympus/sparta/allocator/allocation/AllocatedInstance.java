package olympus.sparta.allocator.allocation;

import com.google.common.collect.Lists;
import com.google.common.reflect.TypeToken;
import com.google.gson.*;
import olympus.sparta.base.db.model.CompleteInstanceData;

import java.lang.reflect.Type;
import java.util.*;

import static olympus.sparta.base.db.model.CompleteInstanceData.getRangeStrings;

public class AllocatedInstance implements Comparable<AllocatedInstance> {
    private static final Gson gson = new Gson();
    private static final JsonParser praser = new JsonParser();
    private final CompleteInstanceData data;

    private HashSet<Integer> bucketSet;
    private boolean bucketsChanged = true;
    private JsonObject fullJson;
    private JsonObject bucketRangesJson;


    public AllocatedInstance(CompleteInstanceData data) {
        this.data = data;
        setBuckets(data.allocatedBuckets);
        changeCachedJsonIfRequired();
    }

    synchronized void setBuckets(int[] buckets) {
        bucketSet = new HashSet<>();
        for (int bucket : buckets) {
            bucketSet.add(bucket);
        }
        bucketsChanged = true;
    }

    synchronized void setBuckets(List<Integer> buckets) {
        bucketSet = new HashSet<>();
        bucketSet.addAll(buckets);
        bucketsChanged = true;
    }

    synchronized void addBucket(int bucket) {
        bucketSet.add(bucket);
        bucketsChanged = true;
    }

    public int getBucketCount() {
        return bucketSet.size();
    }

    public synchronized List<Integer> getBuckets() {
        return Lists.newArrayList(bucketSet);
    }

    public int getInstanceId() {
        return data.instanceId;
    }

    public String getAddress() {
        return data.address;
    }

    @Override
    public int compareTo(AllocatedInstance o) {
        return data.address.compareTo(o.data.address);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof AllocatedInstance)) return false;
        AllocatedInstance that = (AllocatedInstance) o;
        return data.instanceId == that.data.instanceId;
    }

    @Override
    public String toString() {
        return "AllocatedInstance{" +
                "buckets=" + bucketSet.size() +
                ", instanceId=" + data.instanceId +
                ", serviceType=" + data.serviceType +
                '}';
    }

    public JsonObject toJson() {
        changeCachedJsonIfRequired();
        return fullJson;
    }

    public JsonObject toBucketRangesJson() {
        changeCachedJsonIfRequired();
        return bucketRangesJson;
    }

    protected synchronized void changeCachedJsonIfRequired() {
        if(bucketsChanged) {
            fullJson = buildJson(false);
            bucketRangesJson = buildJson(true);
        }
    }

    protected JsonObject buildJson(boolean withBucketRanges) {
        String infoJsonStr = data.infoJson == null ? "{}" : data.infoJson;
        Type type = new TypeToken<Map<String, String>>(){}.getType();

        JsonObject o = new JsonObject();
        o.addProperty("instanceId", data.instanceId);
        o.addProperty("address", data.address);
        o.addProperty("serviceType", data.serviceType);
        o.addProperty("jid", data.getJID());
        o.addProperty("infoJson", infoJsonStr);

        if(withBucketRanges) {
            o.add("bucketRanges", bucketRanges());
        } else  {
            o.add("allocatedBuckets", bucketsAsJsonArray(getBuckets()));
        }
        return o;
    }

    protected JsonElement bucketRanges() {
        ArrayList<Integer> bList = Lists.newArrayList(bucketSet);
        bList.sort(Integer::compareTo);
        int[][] buckets = toBucketRanges(bList);
        Type type = new TypeToken<int[][]>() {
        }.getType();
        return gson.toJsonTree(buckets, type);
    }

    static JsonElement bucketsAsJsonArray(List<Integer> buckets) {
        JsonArray arr = new JsonArray();
        for (int bucket : buckets) {
            arr.add(new JsonPrimitive(bucket));
        }
        return arr;
    }

    public static int[][] toBucketRanges(List<Integer> sortedList) {
        if(0 == sortedList.size()) {
            return new int[][]{};
        }
        ArrayList<int[]> arrayList = new ArrayList<>();
        int s = sortedList.get(0);
        int e = s;
        for (int i = 1; i < sortedList.size(); i++) {
            int x = sortedList.get(i);
            if (x > e + 1) {
                arrayList.add(new int[]{s, e});
                s = x;
            }
            e = x;
        }
        arrayList.add(new int[]{s, e});
        return arrayList.toArray(new int[arrayList.size()][]);
    }

    /*
    protected String minimalInfoJson(String infoJsonStr) {
        JsonObject info = praser.parse(infoJsonStr).getAsJsonObject();
        String[] required = new String[]{"supportPing", "instancePublicKey", "instancePublicKeyIdentifier"};
        HashMap<String, String> minMap = new HashMap<>();
        for (String key : required) {
            JsonPrimitive p = info.getAsJsonPrimitive(key);
            if(null != p) {
                minMap.put(key, p.getAsString());
            }
        }
        return gson.toJson(minMap);
    }
    */
}
