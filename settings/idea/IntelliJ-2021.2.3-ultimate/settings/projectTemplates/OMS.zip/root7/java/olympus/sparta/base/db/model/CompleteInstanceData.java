package olympus.sparta.base.db.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CompleteInstanceData {
  public enum InstanceView {
    SIMPLE,
    FULL
  }

  public final int instanceId;
  public final String serviceType;
  public final String address;
  public final String infoJson;
  public int registrationEvent;
  public int unRegistrationEvent;
  public long lastHbInTime;
  public int clientAckedVersion;
  public int allocationEvent;
  public String sessionId;
  public String spartaId;
  public int[] allocatedBuckets;
  public final long registrationTime;
  public final long allocationTime;
  private ArrayList<String> subscribedTopics;

  public CompleteInstanceData(int instanceId,
                              String serviceType,
                              String address,
                              String infoJson,
                              long registrationTime,
                              long allocationTime,
                              int[] allocatedBuckets) {
    this.instanceId = instanceId;
    this.serviceType = serviceType;
    this.address = address;
    this.infoJson = infoJson;
    this.registrationTime = registrationTime;
    this.allocationTime = allocationTime;
    this.allocatedBuckets = allocatedBuckets;
  }

  public CompleteInstanceData(ResultSet rs) throws SQLException {
    instanceId = rs.getInt("instanceId");
    serviceType = rs.getString("serviceType");
    sessionId = rs.getString("sessionId");
    spartaId = rs.getString("spartaId");
    address = rs.getString("address");
    infoJson = rs.getString("infoJson");
    registrationEvent = rs.getInt("registrationEvent");
    unRegistrationEvent = rs.getInt("unRegistrationEvent");
    lastHbInTime = rs.getLong("lastHbInTime");
    clientAckedVersion = rs.getInt("clientAckedVersion");
    allocationEvent = rs.getInt("allocationEvent");
    registrationTime = rs.getLong("registrationTime");
    allocationTime = rs.getLong("allocationTime");
    allocatedBuckets = bucketsToArray(rs.getString("allocatedBuckets"));
    subscribedTopics = Util.parseSubscribedTopics(infoJson);
  }

  private int[] bucketsToArray(String buckets) {
    if (buckets == null) return new int[0];
    String[] parts = buckets.split(",");
    int[] b = new int[parts.length];
    for (int i = 0; i < parts.length; i++) {
      b[i] = Integer.parseInt(parts[i]);
    }
    return b;
  }

  @Override
  public String toString() {
    return "CompleteInstanceData{" +
        "instanceId=" + instanceId +
        ", serviceType='" + serviceType + '\'' +
        ", address='" + address + '\'' +
        ", infoJson='" + infoJson + '\'' +
        ", registrationEvent=" + registrationEvent +
        ", unRegistrationEvent=" + unRegistrationEvent +
        ", lastHbInTime=" + lastHbInTime +
        ", clientAckedVersion=" + clientAckedVersion +
        ", allocationEvent=" + allocationEvent +
        ", allocatedBuckets=" + getRangeStrings(getListFromIntArray(allocatedBuckets)) +
        '}';
  }

  public JsonObject toJson() {
    JsonObject o = new JsonObject();
    o.addProperty("instanceId", instanceId);
    o.addProperty("sessionId", sessionId);
    o.addProperty("spartaId", spartaId);
    o.addProperty("serviceType", serviceType);
    o.addProperty("address", address);
    o.addProperty("infoJson", infoJson == null ? "{}" : infoJson);
    o.addProperty("registrationEvent", registrationEvent);
    o.addProperty("unRegistrationEvent", unRegistrationEvent);
    o.addProperty("lastHbInTime", lastHbInTime);
    o.addProperty("clientAckedVersion", clientAckedVersion);
    o.addProperty("allocationEvent", allocationEvent);
    JsonArray array = new JsonArray();
    for (int i : allocatedBuckets) {
      array.add(new JsonPrimitive(i));
    }
    o.add("allocatedBuckets", array);
    o.addProperty("registrationTime", registrationTime);
    o.addProperty("allocationTime", allocationTime);
    //Retaining this for backward compatibility with tooling
    o.addProperty("spartaCurrentTime", System.currentTimeMillis());
    return o;
  }


  private ArrayList<Integer> getListFromIntArray(int[] buckets) {
    ArrayList<Integer> list = new ArrayList<>();
    for (int bucket : buckets) {
      list.add(bucket);
    }
    return list;
  }

  public static List<String> getRangeStrings(List<Integer> list) {
    Collections.sort(list);
    ArrayList<String> ranges = new ArrayList<>();
    if (list.isEmpty()) return ranges;
    int start = list.get(0);
    int end = list.get(0);
    for (int e : list.subList(1, list.size())) {
      if (e == end + 1) {
        end = e;
      } else {
        ranges.add("[" + start + (start == end ? "" : "-" + end) + "]");
        start = e;
        end = e;
      }
    }
    ranges.add("[" + start + (start == end ? "" : "-" + end) + "]");
    return ranges;
  }

  public String getJID() {
    return instanceId + "@" + serviceType + ".services.olympus";
  }

  public List<String> getSubscribedTopics() {
    return subscribedTopics;
  }

}
