package functional.olympus.sparta;

import olympus.sparta.allocator.ServerHBSender;
import olympus.sparta.agent.controller.requests.RegisterRequest;
import org.junit.After;
import org.junit.Test;

public class ServerHBTest extends FunctionalTest {
    final String sessionId = "abc";

    @Test
    public void shouldStartReceivingHbOnConnection() throws InterruptedException {
        waitForServerHB();
        assertClientReceived(json("{\"requestId\":\"undefined\",\"type\":\"hb\",\"systemVersion\":0}"));
    }

    @Test
    public void shouldReceiveHbOnRegistration() throws InterruptedException {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        //waitForNextEventPoll();
        waitForServerHB();
        assertClientReceived(json("{\"requestId\":\"undefined\",\"type\":\"hb\",\"systemVersion\":1,\"serviceType\":\"test\", \"subscribedTopics\":[]}"));
    }

    @Test
    public void shouldReceiveHbOnUnRegistration() throws InterruptedException {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        RegisterRequest.Response response = getResponse(2, RegisterRequest.Response.class);
        sendRequest(testRequestFactory.createUnRegisterRequest(3, response.getJid()));
        waitForServerHB();
        assertClientReceived(json("{\"requestId\":\"undefined\",\"type\":\"hb\",\"systemVersion\":2,\"serviceType\":\"test\", \"subscribedTopics\":[]}"));
    }

    private void waitForServerHB() throws InterruptedException {
        final int SOME_BUFFER = 10;
        Thread.sleep(ServerHBSender.HB_SEND_PERIOD + SOME_BUFFER);
    }

    private void waitForNextEventPoll() throws InterruptedException {
        Thread.sleep(ServerHBSender.DB_POLL_INTERVAL);
    }
}
