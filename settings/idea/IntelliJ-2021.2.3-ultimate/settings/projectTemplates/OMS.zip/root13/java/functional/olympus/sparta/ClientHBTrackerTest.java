package functional.olympus.sparta;

import org.junit.Test;

import static olympus.sparta.agent.controller.hearbeat.ClientHBTracker.CLIENT_HB_TRACKING_INTERVAL;
import static olympus.sparta.agent.controller.hearbeat.ClientHBTracker.CLIENT_HEART_BEAT_INTERVAL;

public class ClientHBTrackerTest extends FunctionalTest {
    final String sessionId = "qwerty";

    @Test
    public void shouldUnregisterAndCloseSocketOnClientHbTimeout() throws InterruptedException {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        waitForClientHbTimeout();
        assertClientReceived(json("{\"requestId\":\"undefined\",\"type\":\"response\",\"body\":{\"instanceId\":1,\"systemVersion\":2}}"));
        assertSocketClosed();
    }

    @Test
    public void shouldUnRegisterAllInstancesOnClientHbTimeout() throws InterruptedException {
        sendRequest(testRequestFactory.createReConnectRequest(1, sessionId));
        sendRequest(testRequestFactory.createRegisterRequest(2));
        sendRequest(testRequestFactory.createRegisterRequest(3, "tcp://192.168.55.1:8041"));
        waitForClientHbTimeout();
        assertClientReceived("{\"requestId\":\"undefined\",\"type\":\"response\",\"body\":{\"instanceId\":1,\"systemVersion\":3}}");
        assertClientReceived("{\"requestId\":\"undefined\",\"type\":\"response\",\"body\":{\"instanceId\":2,\"systemVersion\":4}}");
        assertSocketClosed();
    }

    private void waitForClientHbTimeout() throws InterruptedException {
//        final int SOME_BUFFER = 100;
        final int SOME_BUFFER = 3000;
        Thread.sleep(3 * CLIENT_HEART_BEAT_INTERVAL + CLIENT_HB_TRACKING_INTERVAL + SOME_BUFFER);
    }
}
