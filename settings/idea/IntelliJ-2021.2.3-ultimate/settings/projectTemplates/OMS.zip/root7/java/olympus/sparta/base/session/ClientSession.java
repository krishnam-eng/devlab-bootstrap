package olympus.sparta.base.session;

import in.zeta.spectra.capture.SpectraLogger;

import javax.annotation.Nullable;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.Optional;

/**
 * Represents one Spartan session which hosts multiple service instances of different OMS services
 */
public interface ClientSession {
  RemoteServiceInstance create();

  RemoteServiceInstance createOrGet(int instanceId);

  @Nullable
  RemoteServiceInstance getServiceInstance(int instanceId);

  @Nullable
  RemoteServiceInstance getRegisteredServiceInstance(String serviceType, String address);

  /**
   * @return List of OMS instances on this client session
   */
  List<RemoteServiceInstance> getInstances(); // multiple service type wont be present

  RemoteServiceInstance getPrimaryServiceInstance();

  void remove(RemoteServiceInstance remoteServiceInstance);

  int getRegisteredInstanceCount();

  void send(Response response);


  /***
   * Disconnect this session from the associated transport connection.
   * The session will remain available to be reclaimed through another connection.
   */
  void disconnect();

  /***
   * Destroys the session. Cannot be reclaimed further by providing same session id.
   */
  void close();

  void setOnCloseListener(Runnable r);


  void onClientDisconnect();

  void onClientMessage(String msg);

  void onConnected();

  SpectraLogger.Marker decorateMarker(SpectraLogger.Marker m);


  long getLastHbInTime();

  void setLastHbInTime(long lastHbInTime);

  int getClientAckedVersion();

  void setClientAckedVersion(int clientAckedVersion);


  void setSessionId(String sessionId);

  String getSessionId();

  int getServerGeneratedId();

  InetSocketAddress getRemoteAddress();

  /***
   * Make this session defunct when this session is reclaimed using another connection.
   * @param reclaimingSession
   */
  void setReclaimedByOther(ClientSession reclaimingSession);

  Optional<ClientConnection> getConnection();

  boolean hasUnRegisteredInstances();

  int executorKey();

  void onRegistered();
}
